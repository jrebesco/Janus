function finalTestWeights = genPortWeights(data,filter,longInd,shortInd,dateIndex,mode,total,finalSubPdiff)

%%%%%%% genPortWeights(data,filter,dateIndex,mode,total) generates a set of weights given
%%%% data structure
%%%% filter = set of tick indices to be pulled out of data structure
%%%% dateIndex = relevant date index
%%%% mode = type of weighting:
%%%%   'uniform' : equal share weight : weight_i = total / sum (prices)
%%%%   'uniformCap' : equal $ weight : weight_i = total / number of elements in filter / prices_i

if nargin<8
    finalSubPdiff= ones(size(filter));
end

if isequal(mode,'uniform')
    finalTestWeights = repmat(total / sum(data.prices(dateIndex,filter)),size(filter));
elseif isequal(mode,'uniformCap')
    finalTestWeights = total ./ size(filter,1) ./ data.prices(dateIndex,filter);
elseif isequal(mode,'uniformCapBeta')
    if size(data.prices,2)>size(data.beta,2)
        data.beta(:,end+1) = ones(size(data.beta(:,1)));
    end
    longBetas = data.beta(dateIndex,longInd);
    %     for j = 1:numel(shortInd)
    %         shortBetas(j) = calcBetas(data.tickers{1,shortInd(j)},datestr(datenum(date)-120,'mm/dd/yyyy'),data.dates{end},'SPY',0,data);
    %     end
    shortBetas = data.beta(dateIndex,shortInd);
    if ~isempty(find(longBetas==0))
        zbs = find(longBetas==0);
        if numel(zbs)<numel(longBetas)
        longBetas(zbs) = mean(longBetas);
        else
            longBetas(zbs) = 1;
        end
    end
    if ~isempty(find(shortBetas==0))
        disp('short betas = 0')
        zbs = find(longBetas==0);
        shortBetas(zbs) = mean(shortBetas);
    end
    
    longTestWeights = total ./ numel(longInd) ./ data.prices(dateIndex,longInd);
    shortTestWeights = -total ./ numel(shortInd) ./ data.prices(dateIndex,shortInd);
    longGain = -(shortTestWeights*shortBetas') ./ (longTestWeights * longBetas');
    
    finalTestWeights = [longTestWeights.*longGain shortTestWeights];
elseif isequal(mode,'uniformCapBetaConf')
    
    for j = 1:numel(longInd)
        longBetas(j) = calcBetas(data.tickers{1,longInd(j)},datestr(datenum(date)-120,'mm/dd/yyyy'),data.dates{end},'SPY',0,data);
    end
    for j = 1:numel(shortInd)
        shortBetas(j) = calcBetas(data.tickers{1,shortInd(j)},datestr(datenum(date)-120,'mm/dd/yyyy'),data.dates{end},'SPY',0,data);
    end
    
    
    longTestWeights = total ./ numel(longInd) ./ data.prices(dateIndex,longInd);
    shortTestWeights = -total ./ numel(shortInd) ./ data.prices(dateIndex,shortInd);
    longGain = -(shortTestWeights*shortBetas') ./ (longTestWeights * longBetas');
    
    finalSubPdiff(find(finalSubPdiff==0))=1;
    NNConfGain = abs(finalSubPdiff) ./ mean(abs(finalSubPdiff));
    
    finalTestWeights = [longTestWeights.*longGain shortTestWeights].*NNConfGain;
elseif isequal(mode,'uniformCapBetaConfMacro')
    disp('Not supported ATM')
    %% NOT SUPPORTED ATM
    %     lc = data.lb(startIndex);
    %     gc = data.gc(startIndex);
    %     lpast = data.lb(startIndex-options.test.lbgcLookback);
    %     gpast = data.gc(startIndex-options.test.lbgcLookback);
    %     lperf = (lc-lpast)/lpast;
    %     gperf = (gc-gpast)/gpast;
    %     relPerf = lperf-gperf;
    %     modelMarketGain = 1+relPerf;
    %     modelMarketGain = 1;
    
else
    disp('No matching filter type found!')
end