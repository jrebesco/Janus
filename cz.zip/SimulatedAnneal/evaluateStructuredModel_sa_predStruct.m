function [sharpe,finSharpe,garchSharpe,finModel, garchModel, meanSz, nullMarker] = evaluateStructuredModel_sa_predStruct(options,data,timeIndexVector,fund,dateVect,predStruct,useDynamicBeta)
%%%%%%%%%%%%%%%%%%
%% FUNCTION evaluateStructuredModel_sa_predStruct
%%%

if ~exist('useDynamicBeta','var')
    useDynamicBeta = 0;
end
    nullMarker = [1 1];
    data.prices(:,end+1) = data.spy;
for t = 1:numel(timeIndexVector)
    dataIndex  = timeIndexVector(t);
    %% find equivalent date
    [eligLongs eligShorts] = getEligibleIndicesFromStructMod(data,dataIndex,dateVect,fund,options,predStruct);
% % function [eligLongs, eligShorts] = getEligibleIndicesFromStructMod(data,dateIndex,dateVect,fund,options,pdiffStr)    
    %% doublecheck validity
    eligLongs = eligLongs(find(data.validity(dataIndex,eligLongs)));
    eligShorts = eligShorts(find(data.validity(dataIndex,eligShorts)));

    
    if isempty(eligLongs) && isempty(eligShorts)
       disp('emptyLongShort') 
       nullMarker = [0 0];
    end
    if isempty(eligLongs)
        disp('emptyLong')
        eligLongs = size(data.prices,2);
        nullMarker(1) = 0;
    end
    if isempty(eligShorts)
        disp('emptyShort')
        eligShorts = size(data.prices,2);
        nullMarker(2) = 0;
    end
    if ~isempty(eligShorts)
        if ~isempty(eligLongs)
            %% weights
            finalWeights = genPortWeights(data,[eligLongs eligShorts],eligLongs,eligShorts,dataIndex,'uniformCapBeta',100);
            if isfield(options,'finalDeltaAdj')
                if options.finalBetaAdj==1
                    finalWeights(find(finalWeights>0))= options.finalBetaAdjCoef.*finalWeights(find(finalWeights>0));
                end
            end
            %% performance
            [ model ] = evaluateGeneralFeedbackModel_v3(data,[eligLongs eligShorts], finalWeights,options,dataIndex,options.test.runLength);
            
            perf(t) = model.finalPnl./model.initialNetLiq;
            allTimePnl = model.pnl./model.initialNetLiq;
            model.tickers = [eligLongs eligShorts];
            model.weights = finalWeights;
            modelArray{t} = model;
        else
            perf(t)=0;
            modelArray{t}.finalPnl=0;
            modelArray{t}.initialNetLiq=1;
            modelArray{t}.tickers = 'XXX';
            allTimePnl=0;
            modelArray{t}.timeIndex = dataIndex:1:dataIndex+options.test.runLength-1;
        end
    else
        perf(t)=0;
        modelArray{t}.finalPnl=0;
        modelArray{t}.initialNetLiq=1;
        modelArray{t}.tickers = 'XXX';
        allTimePnl = 0;
        modelArray{t}.timeIndex = dataIndex:1:dataIndex+options.test.runLength-1;
    end
    
    clear screen
    portSize(:,t) = [numel(eligLongs) numel(eligShorts)];
    spyPerf(:,t) = (data.spy(dataIndex:dataIndex+options.test.runLength)-data.spy(dataIndex))./data.spy(dataIndex);
end

sharpe = mean(perf)./std(perf)
if useDynamicBeta
    [finSharpe, garchSharpe, finModel, garchModel] = generateDynamicBetaHedging(data,options,modelArray);
else
    finSharpe = sharpe;
    garchSharpe = sharpe;
    finModel = [];
    garchModel = [];
end
meanSz = mean(sum(portSize));
