%% explore acorr
ccc
options.global.file = 'filt_dataVI_v8';
load(options.global.file)
dV = [5:5:120];
for di = 1:1:numel(dV)
    delta = dV(di);
    
    
    for tick = 10 %:size(data.tickers,2)
        px = data.prices(find(data.validity(:,tick)),tick);
        pxd = px(1+delta:delta:end)-px(1:delta:end-delta);
        pmf = zeros(2,2);
        pmb = zeros(2,2);
        
        for p = 1:numel(pxd)-1
            if pxd(p)>=0 && pxd(p+1)>=0
                ind = 1;
                ts(p) = 1;
            elseif pxd(p)>=0 && pxd(p+1)<0
                ind = 2;
                ts(p) = 0;
            elseif pxd(p)<0 && pxd(p+1)>=0
                ind = 3;
                ts(p) = 0;
            elseif pxd(p)<0 && pxd(p+1)<0
                ind = 4;
                ts(p) = 1;
            end
            %%%%% pmf(1) = 1;pmf(2) = 2;pmf(3) = 3;pmf(4) = 4;pmf = [1 3;2 4]
            if p < numel(pxd)/2
                pmf(ind) = pmf(ind)+1;
            else
                pmb(ind) = pmb(ind)+1;
            end
        end
        probF = (pmf(1)+pmf(4))./sum(sum(pmf));
        
        
        [pAll(tick,1) sig] = binofit((pmf(1)+pmf(4)),sum(sum(pmf)));
        momAll(tick,1) = sig(1)>0.5;
        revAll(tick,1) = sig(2)<0.5;
        [pAll(tick,2) sig] = binofit((pmb(1)+pmb(4)),sum(sum(pmb)));
        momAll(tick,2) = sig(1)>0.5;
        revAll(tick,2) = sig(2)<0.5;
    end
    
    
    momC(di) = numel(find(momAll(:,1).*momAll(:,2)));
    momNames{di} = find(momAll(:,1).*momAll(:,2));
    revC(di) = numel(find(revAll(:,1).*revAll(:,2)));
    revNames{di} = find(revAll(:,1).*revAll(:,2));
end

