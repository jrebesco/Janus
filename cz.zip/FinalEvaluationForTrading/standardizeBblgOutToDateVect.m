function shell = standardizeBblgOutToDateVect(dateVect,earn)


shell = zeros(numel(dateVect),numel(earn))./0;
for i = 1:numel(earn)
    if size(earn{i},1)<2
        shell(:,i) = NaN;
    else
        [bool loc] = ismember(earn{i}(:,1),dateVect);
        shell(loc(find(loc>0)),i)=earn{i}(find(loc>0),2);
        
        missingVals = find(isnan(shell(:,i)));
        goodVals = find(~isnan(shell(:,i)));
        frontNans = missingVals(find(missingVals<goodVals(1)));
        backNans = missingVals(find(missingVals>goodVals(end)));
        
        if ~isempty(frontNans)
            shell(frontNans,i)=shell(goodVals(1),i);
        end
        if ~isempty(backNans)
            shell(backNans,i)=shell(goodVals(end),i);
        end
        
        rmgMiss = find(isnan(shell(:,i)));
        
        if ~isempty(rmgMiss)
            goodVals = find(~isnan(shell(:,i)));
            disp('nan gaps found, basic unit tests OK, please verify')
            for z = 1:numel(rmgMiss)
                pvsGood = find(goodVals<rmgMiss(z));
                shell(rmgMiss(z),i) = shell(pvsGood(end),i);
            end
        end
    end
end