function options = loadOptionsSet(options,featSet)

featureLibrary;

options.nn.data = featureLib(featSet,:);

options.nn.fit.numFeaturesL1 = min(24,round(size(options.nn.data,1)/2));
options.nn.fit.numFeaturesL2 = min(12,round(options.nn.fit.numFeaturesL1./2));
