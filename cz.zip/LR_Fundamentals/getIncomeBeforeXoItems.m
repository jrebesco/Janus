function [outMat] = getIncomeBeforeXoAvailForComm(tickers,dateVect)

% ref paper http://papers.ssrn.com/sol3/papers.cfm?abstract_id=2670839
% from http://web.utk.edu/~prdaves/Computerhelp/COMPUSTAT/Compustat_manuals/user_05r.pdf

c = blp([],[],10000);

startDate = datestr(dateVect(1),'mm/dd/yyyy');
endDate = datestr(dateVect(end),'mm/dd/yyyy');


[outCell] = history(c,tickers,'EARN_FOR_COMMON',startDate,endDate,'daily');  
ebfMat = standardizeBblgOutToDateVect(dateVect,outCell);

[outCell] = history(c,tickers,'IS_NET_ABNORMAL_ITEMS',startDate,endDate,'daily');  
isnetAbMat = standardizeBblgOutToDateVect(dateVect,outCell);

[outCell] = history(c,tickers,'XO_GL_NET_OF_TAX',startDate,endDate,'daily');  
xoglMat = standardizeBblgOutToDateVect(dateVect,outCell);

outMat = ebfMat + isnetAbMat + xoglMat;

close(c)


