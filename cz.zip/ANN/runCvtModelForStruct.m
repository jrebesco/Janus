function [net,pctCorrect,pcaFilter] = runCvtModelForStruct(data,fund,options)

testLength = options.test.runLength;
startVect = options.nn.fit.startVect;
neurons = options.nn.fit.numNeurons;
runBayes = options.nn.fit.doBayesReg;
isEvaluation = 0;
pctileGranularity = options.nn.fit.percentileGranularity;
useZscore = options.nn.fit.useZscore
makeDiscrete = options.nn.fit.discrete;

makeNormalized =  options.nn.fit.normalize;

[datam,result,okInd] = assembleData(data,options.nn.data,startVect,testLength,isEvaluation,pctileGranularity,useZscore,makeDiscrete,makeNormalized,1);


%%

result_bin = sign(result);
% result_bin(find(result>options.nn.fit.pxDeltaBinThresh))=2;
% result_bin(find(result<-options.nn.fit.pxDeltaBinThresh))=-2;
result_bin(find(result==0))=1;
% result_binM=[result_bin==-2;result_bin==-1;result_bin==1;result_bin==2];
result_binM=[result_bin==-1;result_bin==1];


clear beta bv* fittedData i indices mcap* meanRes* pxmom* q results st* testL* vix*

[pcaFilter, score,latent] = pca(datam');
q = cumsum(latent)./sum(latent);
tCut = find(q>options.test.pcaThresh);
if ~isempty(tCut)
    pcaCutoff = tCut(1);
end
datamPCA = score(:,1:pcaCutoff)';

if options.nn.useDeep ==1
    hiddenSize1 = options.nn.fit.numFeaturesL1;
    hiddenSize2 = options.nn.fit.numFeaturesL2;
    autoenc1 = trainAutoencoder(datam,hiddenSize1, ...
        'MaxEpochs',10000,'DecoderTransferFunction','purelin');
    
    feat1 = encode(autoenc1,datam);
    
    autoenc2 = trainAutoencoder(feat1,hiddenSize2, ...
        'MaxEpochs',10000,'DecoderTransferFunction','purelin');
    
    feat2 = encode(autoenc2,feat1);
    
    softnet = trainSoftmaxLayer(feat2,result_binM,'MaxEpochs',10000);
    
    deepnet = stack(autoenc1,autoenc2,softnet);
    deepnet.trainParam.min_grad = 5e-6
    deepnet2 = train(deepnet,datam,result_binM);
    
    y = deepnet2(datam);
    %     [~, maxInd] = max(y);
    %     res = maxInd-2;
    %     pctCct2 = sum(sign(res)==sign(result_bin))./numel(result_bin);
    %     pctCct = sum(res==result_bin)./numel(result_bin);
    %     net = deepnet2;
    [~, maxInd] = max(y);
    %     res = maxInd-2;
    res = (maxInd-1.5).*2;
    %     pctCct2 = sum(sign(res)==sign(result_bin))./numel(result_bin);
    pctCorrect = sum(res==result_bin)./numel(result_bin);
    net = deepnet2;
    
    
% % % elseif options.nn.useDeep == 2
% % %     hiddenSize1 = options.nn.fit.numFeaturesL1;
% % %     hiddenSize2 = options.nn.fit.numFeaturesL2;
% % %     
% % %     autoenc1 = trainAutoencoder(datamPCA,hiddenSize1, ...
% % %         'MaxEpochs',12000,'DecoderTransferFunction','purelin');
% % %     
% % %     %     autoenc1 = trainAutoencoder(datamPCA,hiddenSize1, ...
% % %     %         'MaxEpochs',24000, ...
% % %     %         'L2WeightRegularization',0.5, ...
% % %     %         'SparsityRegularization',1, ...
% % %     %         'SparsityProportion',0.5, ...
% % %     %         'ScaleData', false);
% % %     
% % %     feat1 = encode(autoenc1,datamPCA);
% % %     %
% % %     %     autoenc2 = trainAutoencoder(feat1,hiddenSize2, ...
% % %     %         'MaxEpochs',24000,'EncoderTransferFunction','satlin','DecoderTransferFunction','purelin');
% % %     %
% % %     %     feat2 = encode(autoenc2,feat1);
% % %     
% % %     softnet = trainSoftmaxLayer(feat1,result_binM,'MaxEpochs',100000);
% % %     
% % %     %     deepnet = stack(autoenc1,autoenc2,softnet);
% % %     deepnet = stack(autoenc1,softnet);
% % %     
% % %     deepnet2 = train(deepnet,datamPCA,result_binM);
% % %     
% % %     y = deepnet2(datamPCA);
% % %     [~, maxInd] = max(y);
% % %     %     res = maxInd-2;
% % %     res = (maxInd-1.5).*2;
% % %     %     pctCct2 = sum(sign(res)==sign(result_bin))./numel(result_bin);
% % %     pctCorrect = sum(res==result_bin)./numel(result_bin);
% % %     net = deepnet2;
else
    
    net = patternnet(neurons);
    net.trainParam.max_fail = options.nn.fit.validationStops;
    net.trainParam.epochs = 2000;
    net.trainParam.showWindow = false;
    net.trainParam.showCommandLine = true;
    % view(net)
    if runBayes
        [net,tr] = trainbr(net,datam,result_binM);
    else
        [net,tr] = train(net,datam,result_binM);
    end
    
    clear c cm cm2 pRight result* testIndices test* vix*
    
end