function [pd, pdxv, pscore,pctCorr] = evaluateMultiNetSingleForStruct(data,options,netC,isEvaluation)
if ~exist('isEvaluation','var')
    isEvaluation = 0;
end
for i = 1:numel(netC)
    i
    [pd{i} pdxv{i} pscore{i}, pctCorr{i}] = evaluateSingleNetForStruct(data,options,netC{i},isEvaluation);
    
end
