function [datam,result,okInd] = assembleData_backup(data,fieldsToAssemble,startVect,testLength,isEvaluation,pctileGranularity,useZscore,makeDiscrete,makeNormalized)
% if nargin <= 4;
% pctileGranularity = 10;
% end
% fieldsToAssemble is a nx3 cell array, containing field name,timeDelta, and
% usePct.  timeDelta of 0 defaults to snapshot, negative timeDelta looks
% backward, positive delta for eval only but supported.  usePct valid only
% if timeDelta ~=0,

datam = [];
for i = 1:size(fieldsToAssemble,1)
    field = fieldsToAssemble(i,:);
    [datam(i,:), okInd] = processSingleElementForDataM(data,field,startVect,pctileGranularity,useZscore,makeDiscrete,makeNormalized);
end

if isEvaluation
    result = [];
else
    resultC{1} = 'prices';
    resultC{2} = testLength;
    resultC{3} = 1;
    
    [result, okResult] = processSingleElementForDataM(data,resultC,startVect,100,0,0,0);
    
    if ~isequal(okResult,okInd)
        error('Index mismatch')
    end
end