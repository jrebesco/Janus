%% buildFullDataForHistorical
ccc
% startDate = '12/29/2000';
% endDate = '12/28/2005';
% startDate = '12/29/2000';
% endDate = '12/28/2005';
% startDate = '12/29/2005';
% endDate = '12/31/2010';
startDate = '1/1/2011';
endDate = '12/31/2017';
%%
buildFullDataForStrMod;