function screen = genStructuredScreen(data,dataIndex,fund,fundaIndex,options)

    screen.names{1} = 'fundReg';
    [misPx okFunsIndex] = calcMispricing(fund,fundaIndex);
    screen.long.index{1} = getFiltIndices(misPx,options.test.fundReg.longThresh,-1);
    screen.long.value{1} = misPx(screen.long.index{1});
    
    screen.short.index{1} = getFiltIndices(misPx,options.test.fundReg.shortThresh,1);
    screen.short.value{1} = misPx(screen.short.index{1});
    
    screen.names{end+1} = 'beta';
    screen.long.index{end+1} = getFiltIndices(data.beta(dataIndex,:),options.test.beta.longThresh,-1);
    screen.long.value{end+1} = data.beta(dataIndex,screen.long.index{end});
    
    screen.short.index{end+1} = getFiltIndices(data.beta(dataIndex,:),options.test.beta.shortThresh,1);
    screen.short.value{end+1} = data.beta(dataIndex,screen.short.index{end});
    
    screen.names{end+1} = 'shortRevMom';
    shortDelta = (data.prices(dataIndex,:)-data.prices(dataIndex-20,:))./data.prices(dataIndex-20,:);
    screen.long.index{end+1} = getFiltIndices(shortDelta,options.test.pxmShort.longThresh,-1);
    screen.long.value{end+1} = shortDelta(screen.long.index{end});
    
    screen.short.index{end+1} = getFiltIndices(shortDelta,options.test.pxmShort.shortThresh,1);
    screen.short.value{end+1} = shortDelta(screen.short.index{end});
    
    screen.names{end+1} = 'longFollMom';
    shortDelta = (data.prices(dataIndex,:)-data.prices(dataIndex-220,:))./data.prices(dataIndex-220,:);
    screen.long.index{end+1} = getFiltIndices(shortDelta,options.test.pxmLong.longThresh,1);
    screen.long.value{end+1} = shortDelta(screen.long.index{end});
    
    screen.short.index{end+1} = getFiltIndices(shortDelta,options.test.pxmLong.shortThresh,-1);
    screen.short.value{end+1} = shortDelta(screen.short.index{end});
    
    screen.names{end+1} = 'BV/PX rat';
    screen.long.index{end+1} = getFiltIndices(data.bookval(dataIndex,:),abs(options.test.bvpx.longThresh),1);
    screen.long.value{end+1} = data.bookval(dataIndex,screen.long.index{end});
    screen.short.index{end+1} = getFiltIndices(data.bookval(dataIndex,:),abs(options.test.bvpx.shortThresh),-1);
    screen.short.value{end+1} = data.bookval(dataIndex,screen.short.index{end});
    
    screen.names{end+1} = 'PE ratio';
    screen.long.index{end+1} = getFiltIndices(data.pe(dataIndex,:),abs(options.test.per.longThresh),-1);
    screen.long.value{end+1} = data.pe(dataIndex,screen.long.index{end});
    screen.short.index{end+1} = getFiltIndices(data.pe(dataIndex,:),abs(options.test.per.shortThresh),1);
    screen.short.value{end+1} = data.pe(dataIndex,screen.short.index{end});
    
    screen.names{end+1} = 'PE ratio - sector';
    screen.long.index{end+1} = getSectorFiltIndices(data,abs(options.test.perSect.longThresh),-1,'broadSector',data.pe(dataIndex,:));
    screen.long.value{end+1} = data.pe(dataIndex,screen.long.index{end});
    screen.short.index{end+1} = getSectorFiltIndices(data,abs(options.test.perSect.shortThresh),1,'broadSector',data.pe(dataIndex,:));
    screen.short.value{end+1} = data.pe(dataIndex,screen.short.index{end});
    
    screen.names{end+1} = 'mispx - sector';
    screen.long.index{end+1} = getSectorFiltIndices(data,abs(options.test.mispxSect.longThresh),-1,'broadSector',misPx);
    screen.long.value{end+1} = misPx(screen.long.index{end});
    screen.short.index{end+1} = getSectorFiltIndices(data,abs(options.test.mispxSect.shortThresh),1,'broadSector',misPx);
    screen.short.value{end+1} = misPx(screen.short.index{end});
        
    screen.names{end+1} = 'price Threshold';

    screen.long.index{end+1} = getFiltIndices(data.prices(dataIndex,:),abs(options.test.minValidPrice),1);
    screen.short.index{end+1} = getFiltIndices(data.prices(dataIndex,:),abs(options.test.minValidPrice),1);
    
    
    
    
% % % % % % % % % %      SASCREEN %%%%%%%%%%%
% % %     
% % %     screen.names{1} = 'fundReg';
% % %     [misPx okFunsIndex] = calcMispricing(fund,fundaIndex);
% % %     pctMis =  prctile([misPx(find(misPx~=0)) 0],[0:1:100]);
% % %     discMis = (discretize(misPx,pctMis));
% % %     
% % %      screen.long.index{1} = getFiltIndices(discMis,options.test.fundReg.longThresh,-1);
% % %     screen.long.value{1} = misPx(screen.long.index{1});
% % %     
% % %     screen.short.index{1} = getFiltIndices(discMis,options.test.fundReg.shortThresh,1);
% % %     screen.short.value{1} = misPx(screen.short.index{1});
% % %     
% % %     screen.names{end+1} = 'beta';
% % %     screen.long.index{end+1} = getFiltIndices(data.beta(dataIndex,:),options.test.beta.longThresh,-1);
% % %     screen.long.value{end+1} = data.beta(dataIndex,screen.long.index{end});
% % %     
% % %     screen.short.index{end+1} = getFiltIndices(data.beta(dataIndex,:),options.test.beta.shortThresh,1);
% % %     screen.short.value{end+1} = data.beta(dataIndex,screen.short.index{end});
% % %     
% % %     screen.names{end+1} = 'shortRevMom';
% % %     shortDelta = (data.prices(dataIndex,:)-data.prices(dataIndex-20,:))./data.prices(dataIndex-20,:);
% % %     screen.long.index{end+1} = getFiltIndices(shortDelta,options.test.pxmShort.longThresh,-1);
% % %     screen.long.value{end+1} = shortDelta(screen.long.index{end});
% % %     
% % %     screen.short.index{end+1} = getFiltIndices(shortDelta,options.test.pxmShort.shortThresh,1);
% % %     screen.short.value{end+1} = shortDelta(screen.short.index{end});
% % %     
% % %     screen.names{end+1} = 'longFollMom';
% % %     shortDelta = (data.prices(dataIndex,:)-data.prices(dataIndex-220,:))./data.prices(dataIndex-220,:);
% % %     screen.long.index{end+1} = getFiltIndices(shortDelta,options.test.pxmLong.longThresh,1);
% % %     screen.long.value{end+1} = shortDelta(screen.long.index{end});
% % %     
% % %     screen.short.index{end+1} = getFiltIndices(shortDelta,options.test.pxmLong.shortThresh,-1);
% % %     screen.short.value{end+1} = shortDelta(screen.short.index{end});
% % %     
% % %     screen.names{end+1} = 'BV/PX rat';
% % %     screen.long.index{end+1} = getFiltIndices(data.bookval(dataIndex,:),abs(options.test.bvpx.longThresh),1);
% % %     screen.long.value{end+1} = data.bookval(dataIndex,screen.long.index{end});
% % %     screen.short.index{end+1} = getFiltIndices(data.bookval(dataIndex,:),abs(options.test.bvpx.shortThresh),-1);
% % %     screen.short.value{end+1} = data.bookval(dataIndex,screen.short.index{end});
% % %     
% % %     screen.names{end+1} = 'PE ratio';
% % %     screen.long.index{end+1} = getFiltIndices(data.pe(dataIndex,:),abs(options.test.per.longThresh),-1);
% % %     screen.long.value{end+1} = data.pe(dataIndex,screen.long.index{end});
% % %     screen.short.index{end+1} = getFiltIndices(data.pe(dataIndex,:),abs(options.test.per.shortThresh),1);
% % %     screen.short.value{end+1} = data.pe(dataIndex,screen.short.index{end});
% % %     
% % %     screen.names{end+1} = 'PE ratio - sector';
% % %     screen.long.index{end+1} = getSectorFiltIndices(data,abs(options.test.perSect.longThresh),-1,'broadSector',data.pe(dataIndex,:));
% % %     screen.long.value{end+1} = data.pe(dataIndex,screen.long.index{end});
% % %     screen.short.index{end+1} = getSectorFiltIndices(data,abs(options.test.perSect.shortThresh),1,'broadSector',data.pe(dataIndex,:));
% % %     screen.short.value{end+1} = data.pe(dataIndex,screen.short.index{end});
% % %     
% % %     screen.names{end+1} = 'mispx - sector';
% % %     screen.long.index{end+1} = getSectorFiltIndices(data,abs(options.test.mispxSect.longThresh),-1,'broadSector',discMis);
% % %     screen.long.value{end+1} = misPx(screen.long.index{end});
% % %     screen.short.index{end+1} = getSectorFiltIndices(data,abs(options.test.mispxSect.shortThresh),1,'broadSector',discMis);
% % %     screen.short.value{end+1} = misPx(screen.short.index{end});
% % %     
% % %     
% % %     screen.names{end+1} = 'price Threshold';
% % % 
% % %     screen.long.index{end+1} = getFiltIndices(data.prices(dataIndex,:),abs(options.test.price.thresh),1);
% % %     screen.short.index{end+1} = getFiltIndices(data.prices(dataIndex,:),abs(options.test.price.thresh),1);