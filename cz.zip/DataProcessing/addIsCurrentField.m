ccc;
load testTemp

[i j ] = ind2sub(size(data.prices),find(data.prices==0));

tickersToEdit = unique(j);

ipoDateInd(1)

isValidTicker = zeros(size(data.prices));
for i = 1:numel(ipoDateInd) 
    isValidTicker(ipoDateInd(i):end,i)=1;
end
data.isValidTicker = isValidTicker;

startVect = 100;
testLength = 20;
isEvaluation = 0;
pctileGranularity = 10;
fieldsToAssemble{1,1} = 'prices';
fieldsToAssemble{1,2} = 0;

[datam,pct,result,okInd] = assembleData(data,fieldsToAssemble,startVect,testLength,isEvaluation,pctileGranularity)
