function [netC,pctCorrect,pdiffANN,pdiffANNXV,pscore,rawPC] = runANNForStruct(data,fund,options,isEvaluation,netC)

pctCorrect = 0;
if ~exist('isEvaluation','var')
    isEvaluation = 0;
end

if isEvaluation==0
    if options.global.buildNets
        [netC, pctCorrect] = buildNNOnlyForStruct(data,fund,options);
    else
        load(options.global.netFile,'netC','pctCorrect')
    end
end

[pdiffANN,pdiffANNXV,pscore, rawPC] = evaluateMultiNetSingleForStruct(data,options,netC,isEvaluation);