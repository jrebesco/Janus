function [pdiffC, okIndV,pscore] = runSQBModelWrapper(data,options,timeString,SQBmodel,isEvaluation)
if ~exist('isEvaluation','var')
    isEvaluation = 0;
end
text{1} = [];
for i = 1:numel(eval(timeString))
    text{end+1,1} = ['[datamSQB2,result{' num2str(i) '},okIndV{' num2str(i) '}] = assembleData(data,options.bc.dataSQB,' timeString '(' num2str(i) '),options.bc.fit.timeLength,isEvaluation,options.bc.fit.percentileGranularity,options.bc.fit.useZscore,options.bc.fit.discrete,options.bc.fit.normalize,1);'];
    text{end+1,1} = ['testX2 = datamSQB2'';'];
    text{end+1,1} = ['pdiffC{' num2str(i) '} = useSQBPredict(SQBmodel,testX2);'];
end
fileID = fopen('SQBDummyScript.m','w');
[nrows ncols] = size(text);
for row = 1:nrows
    fprintf(fileID,'%s\n',text{row,:});
end
fclose(fileID);
clear text

SQBDummyScript;

if ~isEvaluation
    for i = 1:numel(pdiffC)
        normPD = 2.*((pdiffC{i} - min(pdiffC{i}))./(max(pdiffC{i})-min(pdiffC{i})))-1;
        pq(i,1) = mean(sign(result{i}).*normPD')
        pq(i,2) = numel(normPD);
    end
    pscore = sum(pq(:,1).*pq(:,2))./(size(data.tickers,2).*size(pq,1));
else
    pscore = [];
end