function [pdiff, pdiffXV,pscore,xvpctCorr] = evaluateSingleNetForStruct(data,options,net,isEvaluation)
if ~exist('isEvaluation','var')
    isEvaluation = 0;
end
if isEvaluation ==0
    pdiff = zeros(1,size(data.tickers,2));
    pdiffXV = zeros(1,size(data.tickers,2));
    
    for i = 1:numel(options.test.testVect)
        startIndex = options.test.testVect(i);
        [datam,result,okInd] = assembleData(data,options.nn.data,startIndex,options.test.runLength,isEvaluation,options.nn.fit.percentileGranularity,options.nn.fit.useZscore,options.nn.fit.discrete,options.nn.fit.normalize,1);
        netout = net(datam);
        pd = netout(size(netout,1),:)-netout(1,:);
        
        pscore(i) = mean(sign(result).*pd);
        pdiff(i,okInd)=pd;
        
       
        
    end
    
    for i = 1:numel(options.test.XVVect)
        startIndex = options.test.XVVect(i);
        [datam,result,okInd] = assembleData(data,options.nn.data,startIndex,options.test.runLength,isEvaluation,options.nn.fit.percentileGranularity,options.nn.fit.useZscore,options.nn.fit.discrete,options.nn.fit.normalize,1);
        
        netout = net(datam);
        pd = netout(size(netout,1),:)-netout(1,:);
        pdiffXV(i,okInd)=pd;
        xvpctCorr(i) = sum(sign(result)==sign(pd))./numel(pd);
    end
else
    pdiff = zeros(1,size(data.tickers,2));
    pdiffXV = zeros(1,size(data.tickers,2));
    
    for i = 1:numel(options.test.testVect)
        startIndex = options.test.testVect(i);
        [datam,result,okInd] = assembleData(data,options.nn.data,startIndex,options.test.runLength,isEvaluation,options.nn.fit.percentileGranularity,options.nn.fit.useZscore,options.nn.fit.discrete,options.nn.fit.normalize,1);
        netout = net(datam);
        pd = netout(size(netout,1),:)-netout(1,:);
        
        pscore(i) = 0;
        pdiff(i,okInd)=pd;
        pctCorr = [];
    end
end
