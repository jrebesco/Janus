ccc
%% structured model
%% load data - cell 1
options.global.file = 'C:\Users\jrebesco\Desktop\Janus_v2\mergeAll2000_v3p2';
options.global.buildNets = 1;
options.nn.useDeep = 1;

load(options.global.file)
%% merge and align P/EB R - cell 2
data = addEPR(data,fund);
%% options
structModelOptions;
%% reclean JIC

data = cleanPriceGaps(data);
data = cleanBetaGaps(data);
data = cleanBVGaps(data);
data = cleanEbGaps(data);
[data,fund] = cleanEbitdaDrops(data,fund,1);

%% calc mispx
tic;
for t = 1:numel(fund.dates)
   if mod(t,100)==0
       t
   end
   [msxP(t,:),gnX] = calcMispricing(fund,t);
end
% msxP(2716,:)=msxP(2715,:);
msxP(find(isnan(msxP)))=0;
data.misPx = msxP;toc;
%% add stuff for dyn beta
tic; options.dynamicBeta.lag= 440;
options.dynamicBeta.marketRealVolLookback = 90;
data.bearIndicator = getBearIndicator(data,options.dynamicBeta.lag);
data.marketRealizedVol = getMarketRealizedDailyVol(data,options.dynamicBeta.marketRealVolLookback); toc;
%% run ANN
[annModel,trainPctCorr,pdiffANN,pdiffANNXV,pscore,rawPC] = runANNForStruct(data,fund,options);
XVPctCorr = mean(rawPC{1})
% netQual = getNetQual(pscore);
pdiffNNC = zeros(size(data.prices));
for nann = 1:numel(pdiffANN); for anni = 1:numel(options.test.testVect); pdiffNNC(options.test.testVect(anni),:) = pdiffNNC(options.test.testVect(anni),:) + pdiffANN{nann}(anni,:);end;end
for nann = 1:numel(pdiffANN); for anni = 1:numel(options.test.XVVect); pdiffNNC(options.test.XVVect(anni),:) = pdiffNNC(options.test.XVVect(anni),:) + pdiffANNXV{nann}(anni,:);end;end
pdiffNNC = pdiffNNC./numel(pdiffANN);

pdiffStr.label{1} = 'ANN'; pdiffStr.data{1} = pdiffNNC;
%% run RBC
% [rbcModel,pdiffRBCC,pdiffRBCXV,rbcQual] = runRBCForStruct(options);
% pdiffRBC = zeros(size(data.prices));
% for rbci = 1:size(pdiffRBCC,1); pdiffRBC(options.test.testVect(rbci),:) = pdiffRBCC(rbci,:)'; end
% for rbci = 1:size(pdiffRBCXV,1); pdiffRBC(options.test.XVVect(rbci),:) = pdiffRBCXV(rbci,:)'; end
% clear rbci

%% run SQB
[SQBmodel,pdiffC,okIndV,pdiffCXV,okIndXV,sqbQual] = runSQBForStruct(data,options);

% [SQBmodel,pdiffC,okIndV,pdiffXV,okIndXV,pqual] = runSQBForStruct(data,options)
pdiffSQB = zeros(size(data.prices));
for sqbi = 1:numel(pdiffC); pdiffSQB(options.test.testVect(sqbi),okIndV{sqbi}) = pdiffC{sqbi}'; end
for sqbi = 1:numel(pdiffCXV); pdiffSQB(options.test.XVVect(sqbi),okIndXV{sqbi}) = pdiffCXV{sqbi}'; end
clear sqbi
pdiffStr.label{end+1} = 'SQB'; pdiffStr.data{end+1} = pdiffSQB;

%%
options.dynamicBeta.lag= 440;
options.dynamicBeta.marketRealVolLookback = 90;
options.simulatedAnneal.maxIterations = 80000;
options.simulatedAnneal.initialTemp = 0.5;
options.simulatedAnneal.acceptThresholdTau = 10000;
options.simulatedAnneal.acceptDecP = 0.5;
options.simulatedAnneal.paramVar = 10.*ones(1,20);
options.simulatedAnneal.paramVarTau = 10000;
options.simulatedAnneal.resetGap = 300;
options.simulatedAnneal.bitFlipThresh = 10;
options.simulatedAnneal.bitFlipProb = 0.2;

iterations = 0;
iterationsSinceMax = 0;
stackFlipCounter = 0;
annealIterations = 0;
initialPctiles = 100.*rand(1,18);

initialPctiles  = [ 41     0    92   100    85    18    32    90    84    24    33    24    96    70    87    62    52    86    31    23];
initialSigns    = [  1     1    -1    -1    -1     1     1    -1    -1     1     1     1    -1     1    -1     1     1    -1     1    -1];

% initialPctiles = [30    31    79    98    56    49     0    33   100    31    39    58    46    68    83     0    69    84     8    25];
% initialSigns = [1  1    -1    -1    -1     1     1    -1    -1     1     1     1    -1     1    -1     1     1    -1     1    -1];

% % initialPctiles = [7 76 90 43 92 36 12 52 79 36 18 80 68 31 59 79 83 57 50 50 0 100]; %% 2.2 sharpe
% % initialSigns = [1 1 -1 -1 -1 1 1 -1 -1 1 1 1 -1 1 -1 1 1 -1 1 -1 1 -1]; %% 2.2 sharpe
% % initialPctiles = [0 72 63 100 44 3 7 82 88 83 24 2 90 51 40 27 87 80 19 82];  %% best iter, DL net, 24 Jan 2017
% % initialSigns =   [1  1 -1  -1 -1 1 1 -1 -1  1  1 1 -1  1 -1  1  1 -1  1 -1];
% initialPctiles = [5	75 72 81 35	10 0 96	74 74 22 20	90 16 49 3 84 73 22	57];  %% best iter, DL net, 2 Feb 2017
% initialSigns =   [1	 1 -1 -1 -1	 1 1 -1	-1	1  1  1	-1	1 -1 1	1 -1  1	-1];
% initialPctiles = [0 65 48 99 93 36 36 72 79 52 38 0  88 75 74 55 88 84  0 70];
% initialSigns =   [1  1 -1 -1 -1  1  1 -1 -1  1  1 1  -1  1 -1  1  1 -1  1 -1];
% % 13   93    23    46    96     2    13    42    69    20    94    71    73    15    84    32    94    95     %%4.08
% % 1    -1     1     1    -1     1     1     1    -1     1    -1    -1    -1     1    -1    -1     1    -1
% % initialPctiles = [3    99    93    28    88    70    18    79    67    39    47    30    89    19    79     7    54    10     4]; %% 4.48
% % initialSigns = [     1    -1    -1     1    -1    -1     1    -1    -1     1     1     1    -1     1    -1     1     1    -1]; %% 4.48

while iterations < options.simulatedAnneal.maxIterations
    annealIterations = annealIterations + 1;
    iterations = iterations+1;
    options.test.testVect = [options.test.startOffset:options.test.runLength+1:numel(data.dates)-options.test.endOffset];
    acceptThreshold = options.simulatedAnneal.acceptDecP.*exp(-annealIterations./options.simulatedAnneal.acceptThresholdTau);
    options.test.mispxGran = 20;
    
    if iterations ==1
        paramUpdate = initialPctiles;
        signUpdate = initialSigns;
    end
    
    options.test.fundReg.longThresh = paramUpdate(1);
    options.test.fundReg.shortThresh = paramUpdate(2);
    options.test.fundReg.longSign = signUpdate(1);
    options.test.fundReg.shortSign = signUpdate(2);
    
    options.test.pxmLong.longThresh = paramUpdate(3);
    options.test.pxmLong.shortThresh = paramUpdate(4);
    options.test.pxmLong.longSign = signUpdate(3);
    options.test.pxmLong.shortSign = signUpdate(4);
    
    options.test.beta.longThresh = paramUpdate(5);
    options.test.beta.shortThresh = paramUpdate(6);
    options.test.beta.longSign = signUpdate(5);
    options.test.beta.shortSign = signUpdate(6);
    
    options.test.pxmShort.longThresh = paramUpdate(7);
    options.test.pxmShort.shortThresh = paramUpdate(8);
    options.test.pxmShort.longSign = signUpdate(7);
    options.test.pxmShort.shortSign = signUpdate(8);
    
    options.test.bvpx.longThresh = paramUpdate(9);
    options.test.bvpx.shortThresh = paramUpdate(10);
    options.test.bvpx.longSign = signUpdate(9);
    options.test.bvpx.shortSign = signUpdate(10);
    
    options.test.per.longThresh = paramUpdate(11);
    options.test.per.shortThresh = paramUpdate(12);
    options.test.per.longSign = signUpdate(11);
    options.test.per.shortSign = signUpdate(12);
    
    options.test.perSect.longThresh = paramUpdate(13);
    options.test.perSect.shortThresh = paramUpdate(14);
    options.test.perSect.longSign = signUpdate(13);
    options.test.perSect.shortSign = signUpdate(14);
    
    options.test.mispxSect.longThresh = paramUpdate(15);
    options.test.mispxSect.shortThresh = paramUpdate(16);
    options.test.mispxSect.longSign = signUpdate(15);
    options.test.mispxSect.shortSign = signUpdate(16);
    
    options.test.sqbPdiff.longThresh = paramUpdate(17);
    options.test.sqbPdiff.shortThresh = paramUpdate(18);
    options.test.sqbPdiff.longSign = signUpdate(17);
    options.test.sqbPdiff.shortSign = signUpdate(18);
    
%     options.test.rbcPdiff.longThresh = paramUpdate(19);
%     options.test.rbcPdiff.shortThresh = paramUpdate(20);
%     options.test.rbcPdiff.longSign = signUpdate(19);
%     options.test.rbcPdiff.shortSign = signUpdate(20);
    
    options.test.annPdiff.longThresh = paramUpdate(19);
    options.test.annPdiff.shortThresh = paramUpdate(20);
    options.test.annPdiff.longSign = signUpdate(19);
    options.test.annPdiff.shortSign = signUpdate(20);
    
    options.finalBetaAdjCoef = 1;
    
   [sharpe finSharpe(iterations) garchSharpe(iterations) finModel{iterations} garchModel{iterations} msz nullMarker(iterations,:)] = evaluateStructuredModel_sa_predStruct(options,data,options.test.testVect,fund,fund.dates,pdiffStr,1);
   
    annealData(iterations,:) = [paramUpdate sharpe];
    meanPortSize(iterations) = msz;
    signData(iterations,:) = signUpdate;
    paramTauScale = exp(-iterations./options.simulatedAnneal.paramVarTau);
    
    if iterations == 1
        accept = 1;
    elseif isnan(sharpe)
        accept = 0;
    else
        if annealData(end,end)>annealData(end-1,end)
            deltaSharpe = 1;
        elseif isnan(annealData(end-1,end))
            deltaSharpe = 1;
        else
            acceptTemp = (1-(iterations./options.simulatedAnneal.maxIterations)).*options.simulatedAnneal.initialTemp;
            exp((annealData(end,end)-annealData(end-1,end))/(acceptTemp));
            deltaSharpe = exp((annealData(end,end)-annealData(end-1,end))/(acceptTemp));
        end
        accept = ((deltaSharpe + rand(1)) >= 0);
    end
    if accept
        paramUpdate =  paramUpdate + ( options.simulatedAnneal.paramVar .* rand(size(paramUpdate)).* sign(randn(size(paramUpdate)))  );
        paramUpdate(find(paramUpdate<0))=0;
        paramUpdate(find(paramUpdate>100))=100;
        signUpdate = signUpdate;
    else
        paramUpdate =  annealData(end-1,1:end-1) + ( options.simulatedAnneal.paramVar .* rand(size(paramUpdate)) .* sign(randn(size(paramUpdate))) );
        paramUpdate(find(paramUpdate<0))=0;
        paramUpdate(find(paramUpdate>100))=100;      
    end
    
    [shMax shMaxInd] = max(annealData(:,end));
    if iterationsSinceMax > options.simulatedAnneal.resetGap
        disp('resetresetresetresetresetresetresetresetresetreset')
        paramUpdate = annealData(shMaxInd,1:end-1) + ( options.simulatedAnneal.paramVar .* rand(size(paramUpdate)).* sign(randn(size(paramUpdate))) );
        paramUpdate(find(paramUpdate<0))=0;
        paramUpdate(find(paramUpdate>100))=100;
        iterationsSinceMax = 0;
        stackFlipCounter = stackFlipCounter+1
    end
    
    if stackFlipCounter >= options.simulatedAnneal.bitFlipThresh
        signUpdate = [signData(shMaxInd,:) .* sign(2*(rand(size(signUpdate))>options.simulatedAnneal.bitFlipProb)-1)];
        signUpdate(end-3:end) = [1 -1 1 -1];
        stackFlipCounter = 0;
        annealIterations = annealIterations - 1000;
    end
    
    
    iterationsSinceMax = iterationsSinceMax + 1;
    %% xVal
    options.test.testVect = options.test.XVVect;
% %     [sharpeXV(iterations) finSharpeXV(iterations) mszXV(iterations)] = evaluateStructuredModel_sa_v1(options,data,fund,fund.dates,pdiffSQB,0);
    [sharpeXV(iterations), finSharpeXV(iterations), garchSharpeXV(iterations), ~, ~, mszXV(iterations), ~] = evaluateStructuredModel_sa_predStruct(options,data,options.test.XVVect,fund,fund.dates,pdiffStr,0);
         
   
    
   
    %        [sharpe msz] = evaluateStructuredModel_sa_v1(options,data,fund,fund.dates,pdiffM);
end

fullSets = find(sum(nullMarker')==2);
[maxFullSharpe shMaxIndFS] = max(annealData(fullSets,end))
shMaxIndFull = fullSets(shMaxIndFS)
meanPortSize(shMaxIndFull)

bfitOptions = options;

bfitOptions.test.fundReg.longThresh = annealData(shMaxIndFull,1);
bfitOptions.test.fundReg.shortThresh = annealData(shMaxIndFull,2);
bfitOptions.test.fundReg.longSign = signData(shMaxIndFull,1);
bfitOptions.test.fundReg.shortSign = signData(shMaxIndFull,2);

bfitOptions.test.pxmLong.longThresh = annealData(shMaxIndFull,3);
bfitOptions.test.pxmLong.shortThresh = annealData(shMaxIndFull,4);
bfitOptions.test.pxmLong.longSign = signData(shMaxIndFull,3);
bfitOptions.test.pxmLong.shortSign = signData(shMaxIndFull,4);
    
bfitOptions.test.beta.longThresh = annealData(shMaxIndFull,5);
bfitOptions.test.beta.shortThresh = annealData(shMaxIndFull,6);
bfitOptions.test.beta.longSign = signData(shMaxIndFull,5);
bfitOptions.test.beta.shortSign = signData(shMaxIndFull,6);

bfitOptions.test.pxmShort.longThresh = annealData(shMaxIndFull,7);
bfitOptions.test.pxmShort.shortThresh = annealData(shMaxIndFull,8);
bfitOptions.test.pxmShort.longSign = signData(shMaxIndFull,7);
bfitOptions.test.pxmShort.shortSign = signData(shMaxIndFull,8);

bfitOptions.test.bvpx.longThresh = annealData(shMaxIndFull,9);
bfitOptions.test.bvpx.shortThresh = annealData(shMaxIndFull,10);
bfitOptions.test.bvpx.longSign = signData(shMaxIndFull,9);
bfitOptions.test.bvpx.shortSign = signData(shMaxIndFull,10);

bfitOptions.test.per.longThresh = annealData(shMaxIndFull,11);
bfitOptions.test.per.shortThresh = annealData(shMaxIndFull,12);
bfitOptions.test.per.longSign = signData(shMaxIndFull,11);
bfitOptions.test.per.shortSign = signData(shMaxIndFull,12);

bfitOptions.test.perSect.longThresh = annealData(shMaxIndFull,13);
bfitOptions.test.perSect.shortThresh = annealData(shMaxIndFull,14);
bfitOptions.test.perSect.longSign = signData(shMaxIndFull,13);
bfitOptions.test.perSect.shortSign = signData(shMaxIndFull,14);

bfitOptions.test.mispxSect.longThresh = annealData(shMaxIndFull,15);
bfitOptions.test.mispxSect.shortThresh = annealData(shMaxIndFull,16);
bfitOptions.test.mispxSect.longSign = signData(shMaxIndFull,15); 
bfitOptions.test.mispxSect.shortSign = signData(shMaxIndFull,16);

bfitOptions.test.sqbPdiff.longThresh = annealData(shMaxIndFull,17);
bfitOptions.test.sqbPdiff.shortThresh =annealData(shMaxIndFull,18);
bfitOptions.test.sqbPdiff.longSign = signData(shMaxIndFull,17);
bfitOptions.test.sqbPdiff.shortSign = signData(shMaxIndFull,18);

% bfitOptions.test.rbcPdiff.longThresh = annealData(shMaxIndFull,19);
% bfitOptions.test.rbcPdiff.shortThresh =annealData(shMaxIndFull,20);
% bfitOptions.test.rbcPdiff.longSign = signData(shMaxIndFull,19);
% bfitOptions.test.rbcPdiff.shortSign = signData(shMaxIndFull,20);

bfitOptions.test.annPdiff.longThresh = annealData(shMaxIndFull,19);
bfitOptions.test.annPdiff.shortThresh =annealData(shMaxIndFull,20);
bfitOptions.test.annPdiff.longSign = signData(shMaxIndFull,19);
bfitOptions.test.annPdiff.shortSign = signData(shMaxIndFull,20);

bfitOptions.betaWeighting.finModel = finModel{shMaxIndFull};
bfitOptions.betaWeighting.garchModel = garchModel{shMaxIndFull};
save('simAnnealOptFilt14','bfitOptions','annealData','sharpeXV','mszXV','SQBmodel','options','annModel','signData')


