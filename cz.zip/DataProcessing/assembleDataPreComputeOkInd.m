function [datam,result,okInd] = assembleDataPreComputeOkInd(data,fieldsToAssemble,startVect,testLength,isEvaluation,pctileGranularity,useZscore,makeDiscrete,makeNormalized)
% if nargin <= 4;
% pctileGranularity = 10;
% end
% fieldsToAssemble is a nx3 cell array, containing field name,timeDelta, and
% usePct.  timeDelta of 0 defaults to snapshot, negative timeDelta looks
% backward, positive delta for eval only but supported.  usePct valid only
% if timeDelta ~=0,

okInd = 1:1:size(data.tickers,2);
%% handle all the 0 delta
for i = 1:numel(startVect)
    okInd = intersect(okInd,find(data.validity(startVect(i),:)==1));
end
for i = 1:size(fieldsToAssemble,1)
    field = fieldsToAssemble(i,:);
    if field{2} ~= 0
        for j = 1:numel(startVect)
        okInd = intersect(okInd,find(data.validity(startVect(j)+field{2},:)==1));
        end
    end
end

datam = [];
for i = 1:size(fieldsToAssemble,1)
    field = fieldsToAssemble(i,:);
%     [dmtmp, okInd] = processSingleElementForDataM(data,field,startVect,pctileGranularity,useZscore,makeDiscrete,makeNormalized);
if strcmp(field{1},'spy')||strcmp(field{1},'vix')
    dataField = field{1};
    delta = field{2};
    allDistro = ( eval(['data.' dataField '(1-delta:end)']) - eval(['data.' dataField '(1:end+delta)']) ) ./  eval(['data.' dataField '(1:end+delta)']);
    pctField =  prctile(allDistro,[0:pctileGranularity:100]);
    sv = discretize(allDistro(startVect+delta),pctField);
    normSV = sv./numel(pctField);
    dmtmp = [];
    for zzz = 1:numel(startVect)
       dmtmp = [dmtmp repmat(normSV(zzz),1,numel(okInd))];
    end
else
    dmtmp = processSingleElementForDataMWOkInd(data,field,startVect,pctileGranularity,useZscore,makeDiscrete,makeNormalized,okInd);
end
    datam(i,:) = dmtmp;
end

if isEvaluation
    result = [];
else
    resultC{1} = 'prices';
    resultC{2} = testLength;
    resultC{3} = 1;
    
    [result] = processSingleElementForDataMWOkInd(data,resultC,startVect,100,0,0,0,okInd);

end