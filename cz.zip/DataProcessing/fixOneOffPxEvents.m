function pxmat = fixOneOffPxEvents(pxmat,bblgTickers,d)

%% EGLE
%% bankruptcy reorg + warrants.  currently handling by harmonizing subsequent px based on pvs
tickerIndex = find(strcmp(bblgTickers,'EGLE US Equity'));
pxDates = datenum({'10/15/2014';'10/16/2014'});
pxdata  = d{tickerIndex};
frontInd = find(pxdata(:,1)==pxDates(1));
backInd = find(pxdata(:,1)==pxDates(2));
pvsPx = pxdata(frontInd,2);
newPx = pxdata(backInd,2);
%% fix old data so new pxs congruent
newPxData = pxdata(:,2);
newPxData(1:pvsPx) = newPxData(1:pvsPx).*newPx./pvsPx;
pxmat(:,tickerIndex) = newPxData;