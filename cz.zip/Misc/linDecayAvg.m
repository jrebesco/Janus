function f = linDecayAvg(x,d)

% fuction linDecayAvg computes the linearly (decaying) weighted average of
% x over d timesteps
% INPUTS - x
% - d
% OUTPUTS - filt
% Ex: 
% d = 2
% weights =
%     0.6667    0.3333
%  x = [1 3 4 5 20 21 22]
% f = linDecayAvg(x,d)
% f =
%    0.6667    2.3333    3.6667    4.6667   15.0000   20.6667   21.6667 

weights = [d:-1:1]./sum([1:1:d]);
f = filter(weights,1,x);