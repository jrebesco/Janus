ccc
%% structured model
%% load data - cell 1
options.global.file = 'C:\Users\jrebesco\Desktop\Janus_v2\mergeAll2000_v3p2';
options.global.buildNets = 1;
options.nn.useDeep = 1;

load(options.global.file)
%% merge and align P/EB R - cell 2
data = addEPR(data,fund);
%% options
structModelOptions2_forDLNEval;

%% reclean JIC

data = cleanPriceGaps(data);
data = cleanBetaGaps(data);
data = cleanBVGaps(data);
data = cleanEbGaps(data);
[data,fund] = cleanEbitdaDrops(data,fund,1);

%% calc mispx
tic;
for t = 1:numel(fund.dates)
   if mod(t,100)==0
       t
   end
   [msxP(t,:),gnX] = calcMispricing(fund,t);
end
% msxP(2716,:)=msxP(2715,:);
msxP(find(isnan(msxP)))=0;
data.misPx = msxP;toc;
%% add stuff for dyn beta
tic; options.dynamicBeta.lag= 440;
options.dynamicBeta.marketRealVolLookback = 90;
data.bearIndicator = getBearIndicator(data,options.dynamicBeta.lag);
data.marketRealizedVol = getMarketRealizedDailyVol(data,options.dynamicBeta.marketRealVolLookback); toc;

%% generate feature space
featureLibrary;
baseSet = [1 16 30 44 58:61 65:75];
extras = setdiff(1:1:size(featureLib,1),baseSet);
featCells{1} = baseSet;
for extraC = 1:numel(extras)
featCells{end+1} = [baseSet extras(extraC)];
end

%% run ANN
for fSetInd = 1:numel(featCells)

    options = loadOptionsSet(options,featCells{fSetInd});

    [annModel,trainPctCorr,pdiffANN,pdiffANNXV,pscore,rawPC] = runANNForStruct(data,fund,options);
    XVPctCorr = mean(rawPC{1})

    netCell{fSetInd} = annModel;
    pctCorrectAll(fSetInd) = XVPctCorr;
    
    options.nn = rmfield(options.nn,'data');    
    
end