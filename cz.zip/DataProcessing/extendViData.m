% % extendViData
ccc
refreshPricesFully = 0;
load filt_dataVI_v13
tm = clock;

% mna = [71 196 365 536 643 900 1110 1435 1556 1998 2451 2561 2681 15 54 449 619 640 1773 1781 2616 70 109 160 194 200 207 223 225 236 354 415 426 450 464 498 517 535 580 663 764 824 1029 1095 1107 1139 1198 1239 1252 1307 1371 1382 1397 1415 1444 1502 1505 1620 1639 1746 1756 1788 1815 1903 1923 1935        1953        1979        2032        2038        2054        2110        2162 2266        2294        2310        2393        2471        2544 2573  42 486 668 783         981        1021        1436        1833        1948        1991          263 284         495         540         664         753         839        1051        1147        1726        1752        1836        2044        2096        2247        2325        2435        2443        2557        2625        2817]
mna = [15,42,54,70,71,109,160,194,196,200,207,223,225,236,263,284,354,365,415,426,449,450,464,486,495,498,517,535,536,...
    540,580,619,640,643,663,664,668,753,764,783,824,839,848,900,981,1021,1029,1051,1095,1107,1110,1139,1147,1198,1239,...
    1252,1307,1371,1382,1397,1415,1435,1436,1444,1502,1505,1556,1620,1639,1726,1746,1752,1756,1773,1781,1788,1815,1833,...
    1836,1903,1923,1935,1948,1953,1979,1991,1998,2032,2038,2044,2054,2096,2110,2162,2247,2266,2294,2310,2325,2393,2435,...
    2443,2451,2471,2544,2557,2561,2573,2616,2625,2681,2817,74,190,215,510,1041,1519,1660,1716,1900,1932 2160 2418 2764,...
    27 40 47 127 159 682 1062 1112 1138 1204 1279 1383 1475 1851 1924 2034 2365 2615 2648 199 530 798 1053 1061 1215,...
    1277 1320 1829 1945 2198 2438 2460 2613 2797 282 403 537 857 916 1011 1035 1146 1230 1238 1437 1449 1630 1975,...
    2332 2355 2737 1049 1899 2555 794 849 1902 2167 2371 2627 1007 2101 1653 518 797 1006 1278 1793 2033,...
    2035 2039 2045 2055 2088 2097 2102 2103 2111 2161 2163 2168 2199 2267 2295 2311 2326 2333 2356 2372,...
    2419 2436 2439 2444 2452 2461 2472 2545 2556 2558 2574 2614 2617 2649 2682 2738 2765 2798 2818   605 627 2292 2635];


okI = 5;
if datenum(date)==datenum(data.dates{end})
    disp('files current')
elseif (datenum(date)~= datenum(data.dates{end})+1) && (tm(4) < 2)
    disp('early in the day, skipping update')
else
    %% get bblg connection
    c = blp([],[],10000);
    bblgTickers = data.tickers(3,:);
    globalStartDate = data.dates{1};
    startDate = datestr(datenum(data.dates{end})+1,'mm/dd/yyyy')
    truncStartDate  = [startDate(1:8) num2str(str2num(startDate(9:10))-2)];
    endDate = datestr(datenum(date)-0,'mm/dd/yyyy')
    %     endDate = '03/30/2016'
    
    
    %% do px
    if refreshPricesFully
        [d sec] = history(c,bblgTickers,'PX_LAST',globalStartDate,endDate,'daily');
    else
        [d sec] = history(c,bblgTickers,'PX_LAST',startDate,endDate,'daily');
    end
    
    for i = 1:numel(mna)
        tmp =  d{okI}(:,1);
        tmp2 = repmat(data.prices(end,mna(i)),size(d{okI}(:,2),1),size(d{okI}(:,2),2));
        %         d{mna(i)}(:,1) =  d{okI}(:,1);
        %         d{mna(i)}(:,2) = repmat(data.prices(end,mna(i)),size(d{okI}(:,2),1),size(d{okI}(:,2),2));
        tmp3 = [tmp tmp2];
        d{mna(i)} = tmp3;
    end
    
    for i = 1:numel(d)
        nDays(i) = size(d{i},1);
    end
    
    if sum(abs(diff(nDays)))==0
    else
        error('unequal px days')
    end
    
    for i = 1:numel(d{1}(:,1))
        dateAppend{i} = datestr(d{1}(i,1),'mm/dd/yyyy');
    end
    data.dates(end+1:end+numel(dateAppend)) = dateAppend;
    
    insertIndex = [];
    for i = 1:numel(d)
        insertIndex = [insertIndex find(strcmp(data.tickers(3,:),sec{i}))];
        pxmat(:,find(strcmp(data.tickers(3,:),sec{i}))) = d{i}(:,2);
    end
    data.prices(end+1:end+size(pxmat,1),insertIndex) = pxmat;
    clear nDays dateAppend i insertIndex
    %% do mc
    [d sec] = history(c,bblgTickers,'CUR_MKT_CAP',startDate,endDate,'daily');
    for i = 1:numel(mna)
        tmp =  d{okI}(:,1);
        tmp2 = repmat(data.mcap(end,mna(i)),size(d{okI}(:,2),1),size(d{okI}(:,2),2));
        %         d{mna(i)}(:,1) =  d{okI}(:,1);
        %         d{mna(i)}(:,2) = repmat(data.prices(end,mna(i)),size(d{okI}(:,2),1),size(d{okI}(:,2),2));
        tmp3 = [tmp tmp2];
        d{mna(i)} = tmp3;
    end
    
    for i = 1:numel(d)
        nDays(i) = size(d{i},1);
    end
    
    if sum(abs(diff(nDays)))==0
    else
        error('unequal px days')
    end
    
    for i = 1:numel(d{1}(:,1))
        dateAppend{i} = datestr(d{1}(i,1),'mm/dd/yyyy');
    end
    
    %%% check dates
    for i = 1:numel(dateAppend)
        if ~isequal(data.dates{end-numel(dateAppend)+i},dateAppend{i});
            error('date mismatch')
        end
    end
    
    insertIndex = [];
    for i = 1:numel(d)
        insertIndex = [insertIndex find(strcmp(data.tickers(3,:),sec{i}))];
        mcmat(:,find(strcmp(data.tickers(3,:),sec{i}))) = d{i}(:,2);
    end
    data.mcap(end+1:end+size(pxmat,1),insertIndex) = mcmat;
    clear nDays dateAppend i insertIndex mcmat
    %% do BV/PX
    [d sec] = history(c,bblgTickers,'BOOK_VAL_PER_SH',startDate,endDate,'quarterly');
    for i = 1:numel(d)
        numelD(i) = numel(d{i});
    end
    
    if sum(numelD)==0
        nd = size(data.prices,1)-size(data.bookval,1);
        bvupdate = repmat(data.bookval(end,:),nd,1);
        bvupdate = bvupdate.*data.prices(end-nd+1:end,:);
    else
        okI = find(numelD>0);
        okI = okI(1);
        for i = 1:numel(mna)
            d{mna(i)}(:,1) =  d{okI}(:,1);
            d{mna(i)}(:,2) = repmat(data.bookval(end,mna(i)),size(d{okI}(:,2),1),size(d{okI}(:,2),2));
        end
        
        for i = 1:numel(bblgTickers)
            if ~isempty(d{i})
                %             insertInd{i} = d{1}(:,1);
                bval = d{i}(find(d{i}(:,1)==datenum(endDate)),2);
                
            else
                tickerInd = find(strcmp(data.tickers(3,:),bblgTickers{i}));
                bval = data.bookval(end,tickerInd)* data.prices(size(data.bookval,1),tickerInd);
            end
            bvupdate(:,i) = repmat(bval,size(pxmat,1),1);
        end
        
    end
    bvmat = bvupdate./pxmat;
    data.bookval = [data.bookval;bvmat];
    
    %% do all single-elements:
    %% spy
    [d sec] = history(c,'SPY US Equity','PX_LAST',startDate,endDate,'daily');
    data.spy = [data.spy;d(:,2)];
    %% VIX
    [d sec] = history(c,'VIX Index','PX_LAST',startDate,endDate,'daily');
    data.vix = [data.vix;d(:,2)];
    %% gc
    [d sec] = history(c,'GC1 Comdty','PX_LAST',startDate,endDate,'daily');
    data.gc = [data.gc;d(:,2)];
    %% lb
    [d sec] = history(c,'LB1 Comdty','PX_LAST',startDate,endDate,'daily');
    data.lb = [data.lb;d(:,2)];
    
    %% do beta
    [d sec] = history(c,data.tickers(3,:),'BETA_MINUS',startDate,endDate,'daily');
    
    for i = 1:numel(mna)
        tmp =  d{okI}(:,1);
        tmp2 = repmat(data.beta(end,mna(i)),size(d{okI}(:,2),1),size(d{okI}(:,2),2));
        %         d{mna(i)}(:,1) =  d{okI}(:,1);
        %         d{mna(i)}(:,2) = repmat(data.prices(end,mna(i)),size(d{okI}(:,2),1),size(d{okI}(:,2),2));
        tmp3 = [tmp tmp2];
        d{mna(i)} = tmp3;
    end
    
    for i = 1:numel(d)
        tmp(:,i) = d{i}(:,2);
    end
    %
    q = [data.beta;tmp];
    data.beta = q;
    
    %% PE ratio
    [d sec] = history(c,data.tickers(3,:),'PE_RATIO',startDate,endDate,'daily');
    
    for i = 1:numel(mna)
        tmp =  d{okI}(:,1);
        tmp2 = repmat(data.pe(end,mna(i)),size(d{okI}(:,2),1),size(d{okI}(:,2),2));
        %         d{mna(i)}(:,1) =  d{okI}(:,1);
        %         d{mna(i)}(:,2) = repmat(data.prices(end,mna(i)),size(d{okI}(:,2),1),size(d{okI}(:,2),2));
        tmp3 = [tmp tmp2];
        d{mna(i)} = tmp3;
    end
    
    for i = 1:numel(d)
        if isempty(d{i})
                       
            tmp(:,i) = repmat(data.pe(end,i),size(d{okI}(:,2),1),size(d{okI}(:,2),2));
        else
            tmp(:,i) = d{i}(:,2);
        end
    end
    %
    q = [data.pe;tmp];
    data.pe = q;
    %% vix contango
    [d sec] = history(c,'UX1 Index','PX_LAST',startDate,endDate,'daily');
    [d2 sec] = history(c,'UX6 Index','PX_LAST',startDate,endDate,'daily');
    data.vixCont = [data.vixCont; d2(:,2)-d(:,2)];
    clear d d2 sec
    
    
    %% do sticky non-daily elements
    clear ans b* d e* i p* s*  mna* okI num* q globalStartDate gp
    %% grossPPS FCF divyyld CFOA ROA GPOA
    save('tmp.mat','data')
    clear bblgTickers bval bvmat bvupdate d endDate globalStartDate i mna numelD okI pxmat q sec startDate tickerInd tm tmp tmp2 tmp3
    
    dy = appendNewField('tmp','DIVIDEND_YIELD',truncStartDate);
    data.divyld = dy;
    clear dy
    save('tmp.mat','data')
    
    roa = appendNewField('tmp','ANN_RETURN_ON_ASSET',truncStartDate);
    data.roa = roa;
    clear roa
    
    tso = appendNewField('tmp','EQY_SH_OUT',truncStartDate);
    gp = appendNewField('tmp','TRAIL_12M_GROSS_PROFIT',truncStartDate);
    fcf = appendNewField('tmp','CF_FREE_CASH_FLOW',truncStartDate);
    data.grossPPS = gp./tso;
    data.fcfPS = fcf./tso;
    clear tso
    
    bs_tot_assets=getAssets('tmp');
    data.gpoa = gp./bs_tot_assets;
    data.cfoa = fcf./bs_tot_assets;
    
    clear gp fcf tso
    
    data.fcfPS((isnan(data.fcfPS))) = 0;
    data.roa((isnan(data.roa))) = 0;
    data.cfoa((isnan(data.cfoa))) = 0;
    data.gpoa((isnan(data.gpoa))) = 0;
    data.roa((isnan(data.roa))) = 0;
    data.grossPPS((isnan(data.grossPPS))) = 0;
    save('tmp.mat','data')
    %% volume and insider delta
    data.volume =appendNewField('tmp.mat','VOLUME',truncStartDate);
    data.insOwn = appendNewField('tmp.mat','PCT_INSIDER_SHARES_OUT',truncStartDate);
    %% close connection
    close(c)
end
iv = ones(size(data.dates,2)-size(data.validity,1),size(data.validity,2));
iv(:,data.mnaOuts) = 0;
data.validity = [data.validity;iv];

%