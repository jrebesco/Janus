function bearIndicator = getBearIndicator(data,lag)

c = blp([],[],10000);

startDate = datestr(datenum(data.dates(1)) - round(lag/220*365) - 30,'mm/dd/yyyy');
endDate = data.dates(end);

[d sec] = history(c,'SPXT Index','PX_LAST',startDate,endDate,'daily');

startInd = find(d(:,1)==datenum(data.dates(1)));

if ~isempty(startInd)
    endRet = d(startInd:end,2);
    if numel(endRet)~=numel(data.dates)
        warning('bear indicator and datastructure dates are not aligned on all dates')
        for i = 1:numel(data.dates)
            di(i) = find(d(:,1)==datenum(data.dates(i)));
        end
        endRet = d(di,2);
        startRet = d(di-lag,2);
    else
    startRet = d(startInd-lag:end-lag,2);
    end
    netReturn = endRet-startRet;
    bearIndicator = netReturn<0;
    
else
    error('bear indicator and datastructure dates are not aligned on start')
end