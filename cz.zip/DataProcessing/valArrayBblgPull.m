function [dataMat]  = valArrayBblgPull(d,okInd,data)

dnum = d{okInd}(:,1);
dataMat = zeros(numel(data.dates),size(data.tickers,2));

for i = 1:numel(d)
    if isempty(d{i})
    else
        idate = d{i}(:,1);
        % check that the new entry does not have any additional not in benchmark
        inxtras = find(ismember(idate,dnum));
        dprime = d{i}(inxtras,:);
        [inDate, dateIndx] = ismember(dprime(:,1),dnum);
        dataMat(dateIndx,i) = dprime(find(inDate),2);        
    end
end

% clean 0 entries
for i = 1:numel(d)
    %     i
    nz = find(dataMat(:,i)>0);
    if ~isempty(nz)
        if nz(1) > 1;
            dataMat(1:nz(1)-1,i) = dataMat(nz(1),i);
        end
        if nz(end) < size(dataMat,1)
            dataMat(nz(end)+1:end,i) = dataMat(nz(end),i);
        end
    end
end

