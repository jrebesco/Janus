ccc
%% structured model
%% load data
options.global.file = 'C:\Users\jrebesco\Desktop\refactor2\mergeAll2000_v3';
load(options.global.file)
options.global.buildNets = 1;
options.nn.useDeep = 1;
%% merge and align P/EB R
data = addEPR(data,fund);
%% options
structModelOptions;

%% reclean JIC
data = cleanPriceGaps(data);
data = cleanBetaGaps(data);
data = cleanBVGaps(data);
data = cleanEbGaps(data);
[data,fund] = cleanEbitdaDrops(data,fund,1);
%% calc mispx
for t = 1:numel(fund.dates)
   if mod(t,100)==0
       t
   end
   [msxP(t,:),gnX] = calcMispricing(fund,t);
end
% msxP(2716,:)=msxP(2715,:);
msxP(find(isnan(msxP)))=0;
data.misPx = msxP;
%% run ANN
[annModel,pdiffANN,pdiffANNXV,pscore] = runANNForStruct(data,fund,options);
netQual = getNetQual(pscore);
pdiffNNC = zeros(size(data.prices));
for nann = 1:numel(pdiffANN); for anni = 1:numel(options.test.testVect); pdiffNNC(options.test.testVect(anni),:) = pdiffNNC(options.test.testVect(anni),:) + pdiffANN{nann}(anni,:);end;end
for nann = 1:numel(pdiffANN); for anni = 1:numel(options.test.XVVect); pdiffNNC(options.test.XVVect(anni),:) = pdiffNNC(options.test.XVVect(anni),:) + pdiffANNXV{nann}(anni,:);end;end
pdiffNNC = pdiffNNC./numel(pdiffANN);

pdiffStr.label{1} = 'ANN'; pdiffStr.data{1} = pdiffNNC;
%% run RBC
% [rbcModel,pdiffRBCC,pdiffRBCXV,rbcQual] = runRBCForStruct(options);
% pdiffRBC = zeros(size(data.prices));
% for rbci = 1:size(pdiffRBCC,1); pdiffRBC(options.test.testVect(rbci),:) = pdiffRBCC(rbci,:)'; end
% for rbci = 1:size(pdiffRBCXV,1); pdiffRBC(options.test.XVVect(rbci),:) = pdiffRBCXV(rbci,:)'; end
% clear rbci
%% add stuff for dyn beta
options.dynamicBeta.lag= 440;
options.dynamicBeta.marketRealVolLookback = 90;
data.bearIndicator = getBearIndicator(data,options.dynamicBeta.lag);
data.marketRealizedVol = getMarketRealizedDailyVol(data,options.dynamicBeta.marketRealVolLookback);
%% run SQB
[SQBmodel,pdiffC,okIndV,pdiffCXV,okIndXV,sqbQual] = runSQBForStruct(data,options);
pdiffSQB = zeros(size(data.prices));
for sqbi = 1:numel(pdiffC); pdiffSQB(options.test.testVect(sqbi),okIndV{sqbi}) = pdiffC{sqbi}'; end
for sqbi = 1:numel(pdiffCXV); pdiffSQB(options.test.XVVect(sqbi),okIndXV{sqbi}) = pdiffCXV{sqbi}'; end
clear sqbi
pdiffStr.label{end+1} = 'SQB'; pdiffStr.data{end+1} = pdiffSQB;

%%
options.dynamicBeta.lag= 440;
options.dynamicBeta.marketRealVolLookback = 90;
options.simulatedAnneal.maxIterations = 80;
options.simulatedAnneal.initialTemp = 0.5;
options.simulatedAnneal.acceptThresholdTau = 10000;
options.simulatedAnneal.acceptDecP = 0.5;
options.simulatedAnneal.paramVar = 10.*ones(1,20);
options.simulatedAnneal.paramVarTau = 10000;
options.simulatedAnneal.resetGap = 300;
options.simulatedAnneal.bitFlipThresh = 10;
options.simulatedAnneal.bitFlipProb = 0.2;

iterations = 0;
iterationsSinceMax = 0;
stackFlipCounter = 0;
annealIterations = 0;
initialPctiles = 100.*rand(1,18);

% initialPctiles = [5	75 72 81 35	10 0 96	74 74 22 20	90 16 49 3 84 73 22	57];  %% best iter, DL net, 2 Feb 2017
% initialSigns =   [1	 1 -1 -1 -1	 1 1 -1	-1	1  1  1	-1	1 -1 1	1 -1  1	-1];

initialPctiles = [0 100 0 100 0 100 0 100 0 100 0 100 0 100 0 100 0 100 0 100];  %% best iter, DL net, 2 Feb 2017
initialSigns =   [1 -1 1 -1 1 -1 1 -1 1 -1 1 -1 1 -1 1 -1 1 -1 1 -1];
%%
while iterations < options.simulatedAnneal.maxIterations
    annealIterations = annealIterations + 1;
    iterations = iterations+1;
    options.test.testVect = [options.test.startOffset:options.test.runLength+1:numel(data.dates)-options.test.endOffset];
    acceptThreshold = options.simulatedAnneal.acceptDecP.*exp(-annealIterations./options.simulatedAnneal.acceptThresholdTau);
    options.test.mispxGran = 20;
    
    if iterations ==1
        paramUpdate = initialPctiles;
        signUpdate = initialSigns;
    end
    
    options.test.fundReg.longThresh = paramUpdate(1);
    options.test.fundReg.shortThresh = paramUpdate(2);
    options.test.fundReg.longSign = signUpdate(1);
    options.test.fundReg.shortSign = signUpdate(2);
    
    options.test.pxmLong.longThresh = paramUpdate(3);
    options.test.pxmLong.shortThresh = paramUpdate(4);
    options.test.pxmLong.longSign = signUpdate(3);
    options.test.pxmLong.shortSign = signUpdate(4);
    
    options.test.beta.longThresh = paramUpdate(5);
    options.test.beta.shortThresh = paramUpdate(6);
    options.test.beta.longSign = signUpdate(5);
    options.test.beta.shortSign = signUpdate(6);
    
    options.test.pxmShort.longThresh = paramUpdate(7);
    options.test.pxmShort.shortThresh = paramUpdate(8);
    options.test.pxmShort.longSign = signUpdate(7);
    options.test.pxmShort.shortSign = signUpdate(8);
    
    options.test.bvpx.longThresh = paramUpdate(9);
    options.test.bvpx.shortThresh = paramUpdate(10);
    options.test.bvpx.longSign = signUpdate(9);
    options.test.bvpx.shortSign = signUpdate(10);
    
    options.test.per.longThresh = paramUpdate(11);
    options.test.per.shortThresh = paramUpdate(12);
    options.test.per.longSign = signUpdate(11);
    options.test.per.shortSign = signUpdate(12);
    
    options.test.perSect.longThresh = paramUpdate(13);
    options.test.perSect.shortThresh = paramUpdate(14);
    options.test.perSect.longSign = signUpdate(13);
    options.test.perSect.shortSign = signUpdate(14);
    
    options.test.mispxSect.longThresh = paramUpdate(15);
    options.test.mispxSect.shortThresh = paramUpdate(16);
    options.test.mispxSect.longSign = signUpdate(15);
    options.test.mispxSect.shortSign = signUpdate(16);
    
    options.test.sqbPdiff.longThresh = paramUpdate(17);
    options.test.sqbPdiff.shortThresh = paramUpdate(18);
    options.test.sqbPdiff.longSign = signUpdate(17);
    options.test.sqbPdiff.shortSign = signUpdate(18);    
  
    options.test.annPdiff.longThresh = paramUpdate(19);
    options.test.annPdiff.shortThresh = paramUpdate(20);
    options.test.annPdiff.longSign = signUpdate(19);
    options.test.annPdiff.shortSign = signUpdate(20);
    
    options.finalBetaAdjCoef = 1;
    
   [sharpe finSharpe(iterations) garchSharpe(iterations) msz nullMarker(iterations,:)] = evaluateStructuredModel_sa_predStruct(options,data,options.test.XVVect,fund,fund.dates,pdiffStr,1);
   
    annealData(iterations,:) = [paramUpdate sharpe];
    meanPortSize(iterations) = msz;
    signData(iterations,:) = signUpdate;
    paramTauScale = exp(-iterations./options.simulatedAnneal.paramVarTau);
    
    if iterations == 1
        accept = 1;
    elseif isnan(sharpe)
        accept = 0;
    else
        if annealData(end,end)>annealData(end-1,end)
            deltaSharpe = 1;
        elseif isnan(annealData(end-1,end))
            deltaSharpe = 1;
        else
            acceptTemp = (1-(iterations./options.simulatedAnneal.maxIterations)).*options.simulatedAnneal.initialTemp;
            exp((annealData(end,end)-annealData(end-1,end))/(acceptTemp));
            deltaSharpe = exp((annealData(end,end)-annealData(end-1,end))/(acceptTemp));
        end
        accept = ((deltaSharpe + rand(1)) >= 0);
    end
    if accept
        paramUpdate =  paramUpdate + ( options.simulatedAnneal.paramVar .* rand(size(paramUpdate)).* sign(randn(size(paramUpdate)))  );
        paramUpdate(find(paramUpdate<0))=0;
        paramUpdate(find(paramUpdate>100))=100;
        signUpdate = signUpdate;
    else
        paramUpdate =  annealData(end-1,1:end-1) + ( options.simulatedAnneal.paramVar .* rand(size(paramUpdate)) .* sign(randn(size(paramUpdate))) );
        paramUpdate(find(paramUpdate<0))=0;
        paramUpdate(find(paramUpdate>100))=100;      
    end
    
    [shMax shMaxInd] = max(annealData(:,end));
    if iterationsSinceMax > options.simulatedAnneal.resetGap
        disp('resetresetresetresetresetresetresetresetresetreset')
        paramUpdate = annealData(shMaxInd,1:end-1) + ( options.simulatedAnneal.paramVar .* rand(size(paramUpdate)).* sign(randn(size(paramUpdate))) );
        paramUpdate(find(paramUpdate<0))=0;
        paramUpdate(find(paramUpdate>100))=100;
        iterationsSinceMax = 0;
        stackFlipCounter = stackFlipCounter+1
    end
    
    if stackFlipCounter >= options.simulatedAnneal.bitFlipThresh
        signUpdate = [signData(shMaxInd,:) .* sign(2*(rand(size(signUpdate))>options.simulatedAnneal.bitFlipProb)-1)];
        signUpdate(end-3:end) = [1 -1 1 -1];
        stackFlipCounter = 0;
        annealIterations = annealIterations - 1000;
    end
    
    
    iterationsSinceMax = iterationsSinceMax + 1;
    %%% xVal
    options.test.testVect = options.test.XVVect;
    [sharpeXV(iterations), finSharpeXV(iterations), ~, mszXV(iterations), ~] = evaluateStructuredModel_sa_predStruct(options,data,options.test.XVVect,fund,fund.dates,pdiffStr,0);
  
end

%%
fullSets = find(sum(nullMarker')==2);
[maxFullSharpe shMaxIndFull] = max(annealData(fullSets,end))
meanPortSize(shMaxIndFull)

bfitOptions = options;

bfitOptions.test.fundReg.longThresh = annealData(fullSets(shMaxIndFull),1);
bfitOptions.test.fundReg.shortThresh = annealData(fullSets(shMaxIndFull),2);
bfitOptions.test.fundReg.longSign = signData(fullSets(shMaxIndFull),1);
bfitOptions.test.fundReg.shortSign = signData(fullSets(shMaxIndFull),2);

bfitOptions.test.pxmLong.longThresh = annealData(fullSets(shMaxIndFull),3);
bfitOptions.test.pxmLong.shortThresh = annealData(fullSets(shMaxIndFull),4);
bfitOptions.test.pxmLong.longSign = signData(fullSets(shMaxIndFull),3);
bfitOptions.test.pxmLong.shortSign = signData(fullSets(shMaxIndFull),4);
    
bfitOptions.test.beta.longThresh = annealData(fullSets(shMaxIndFull),5);
bfitOptions.test.beta.shortThresh = annealData(fullSets(shMaxIndFull),6);
bfitOptions.test.beta.longSign = signData(fullSets(shMaxIndFull),5);
bfitOptions.test.beta.shortSign = signData(fullSets(shMaxIndFull),6);

bfitOptions.test.pxmShort.longThresh = annealData(fullSets(shMaxIndFull),7);
bfitOptions.test.pxmShort.shortThresh = annealData(fullSets(shMaxIndFull),8);
bfitOptions.test.pxmShort.longSign = signData(fullSets(shMaxIndFull),7);
bfitOptions.test.pxmShort.shortSign = signData(fullSets(shMaxIndFull),8);

bfitOptions.test.bvpx.longThresh = annealData(fullSets(shMaxIndFull),9);
bfitOptions.test.bvpx.shortThresh = annealData(fullSets(shMaxIndFull),10);
bfitOptions.test.bvpx.longSign = signData(fullSets(shMaxIndFull),9);
bfitOptions.test.bvpx.shortSign = signData(fullSets(shMaxIndFull),10);

bfitOptions.test.per.longThresh = annealData(fullSets(shMaxIndFull),11);
bfitOptions.test.per.shortThresh = annealData(fullSets(shMaxIndFull),12);
bfitOptions.test.per.longSign = signData(fullSets(shMaxIndFull),11);
bfitOptions.test.per.shortSign = signData(fullSets(shMaxIndFull),12);

bfitOptions.test.perSect.longThresh = annealData(fullSets(shMaxIndFull),13);
bfitOptions.test.perSect.shortThresh = annealData(fullSets(shMaxIndFull),14);
bfitOptions.test.perSect.longSign = signData(fullSets(shMaxIndFull),13);
bfitOptions.test.perSect.shortSign = signData(fullSets(shMaxIndFull),14);

bfitOptions.test.mispxSect.longThresh = annealData(fullSets(shMaxIndFull),15);
bfitOptions.test.mispxSect.shortThresh = annealData(fullSets(shMaxIndFull),16);
bfitOptions.test.mispxSect.longSign = signData(fullSets(shMaxIndFull),15);
bfitOptions.test.mispxSect.shortSign = signData(fullSets(shMaxIndFull),16);

bfitOptions.test.sqbPdiff.longThresh = annealData(fullSets(shMaxIndFull),17);
bfitOptions.test.sqbPdiff.shortThresh =annealData(fullSets(shMaxIndFull),18);
bfitOptions.test.sqbPdiff.longSign = signData(fullSets(shMaxIndFull),17);
bfitOptions.test.sqbPdiff.shortSign = signData(fullSets(shMaxIndFull),18);

% bfitOptions.test.rbcPdiff.longThresh = annealData(fullSets(shMaxIndFull),19);
% bfitOptions.test.rbcPdiff.shortThresh =annealData(fullSets(shMaxIndFull),20);
% bfitOptions.test.rbcPdiff.longSign = signData(fullSets(shMaxIndFull),19);
% bfitOptions.test.rbcPdiff.shortSign = signData(fullSets(shMaxIndFull),20);

bfitOptions.test.annPdiff.longThresh = annealData(fullSets(shMaxIndFull),19);
bfitOptions.test.annPdiff.shortThresh =annealData(fullSets(shMaxIndFull),20);
bfitOptions.test.annPdiff.longSign = signData(fullSets(shMaxIndFull),19);
bfitOptions.test.annPdiff.shortSign = signData(fullSets(shMaxIndFull),20);

save('xxx','bfitOptions','annealData','sharpeXV','mszXV','SQBmodel','options','annModel','signData')


