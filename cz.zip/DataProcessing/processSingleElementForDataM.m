function [fill, okInd] = processSingleElementForDataM(data,field,startVect,pctileGranularity,useZscore,makeDiscrete,makeNormalized)


dataField = field{1};
delta = field{2};
usePct = field{3};
useAC = 0;
useDeltaTick = 0;
if strcmp(dataField(end-min(numel(dataField)-1,4):end),'acorr')
    useAC = 1;
    dataField = dataField(1:end-5);
    [fill, okInd] = baseEvalSingleElementForDataM(data,dataField,delta,usePct,startVect,pctileGranularity,useZscore,makeDiscrete,makeNormalized,useAC,useDeltaTick);
elseif strcmp(dataField(end-min(numel(dataField)-1,8):end),'deltatick')
    useDeltaTick = 1;
    dataField = dataField(1:end-9);
    [fill, okInd] = baseEvalSingleElementForDataM(data,dataField,delta,usePct,startVect,5,0,1,0,useAC,useDeltaTick);
    
elseif strcmp(dataField(end-min(numel(dataField)-1,2):end),'dma')
    useDMA = 1;
    dataField = dataField(1:end-3);
    [fill, okInd] = baseEvalSingleElementForDataM(data,dataField,delta,usePct,startVect,5,0,1,0,useAC,useDeltaTick,useDMA);
    
    
elseif strcmp(dataField(end-min(numel(dataField)-1,8):end),'broadSect')
    fill = [];
    dataField = dataField(1:end-9);
    for i = 1:numel(startVect)
        [initFill, okInd] = baseEvalSingleElementForDataM(data,dataField,delta,usePct,startVect(i),0,0,0,0,useAC,useDeltaTick);
        for j = 1:numel(okInd)
            ticker = okInd(j);
            result = initFill(j);
            comps = data.tickers{6,ticker};
            [isOk, okComps] = ismember(comps,okInd);
            if isempty(okComps)
                compDelta = 0;
            elseif okComps==0
                compDelta = 0;
            else
                compResults = initFill(okComps(find(isOk)));
                compResults(isinf(compResults))=0;
                mnCompResults = mean(compResults);
                if isinf(mnCompResults)
                    j
                end
                compDelta = result-mnCompResults;
            end
            timeFill(j) = compDelta;
        end
        fill = [fill timeFill];
        clear timeFill
        
    end
    
    if useZscore
        fill = (fill-zscore.mu)./ zscore.sigma;
    else
        if makeDiscrete
            pctField =  prctile(fill,[0:pctileGranularity:100]);
            fill = (discretize(fill,pctField));
        end
        
        if makeNormalized
            fill = (fill - min(fill))./(max(fill)-min(fill));
            
        end
    end
    
elseif  strcmp(dataField(end-min(numel(dataField)-1,3):end),'sect')
    fill = [];
    dataField = dataField(1:end-4);
    for i = 1:numel(startVect)
        [initFill, okInd] = baseEvalSingleElementForDataM(data,dataField,delta,usePct,startVect(i),0,0,0,0,useAC,useDeltaTick);
        for j = 1:numel(okInd)
            ticker = okInd(j);
            result = initFill(j);
            comps = data.tickers{6,ticker};
            [isOk, okComps] = ismember(comps,okInd);
            if isempty(okComps)
                compDelta = 0;
            elseif okComps==0
                compDelta = 0;
            else
                compResults = initFill(okComps(find(isOk)));
                compResults(isinf(compResults))=0;
                mnCompResults = mean(compResults);
                if isinf(mnCompResults)
                    j
                end
                compDelta = result-mnCompResults;
            end
            timeFill(j) = compDelta;
        end
        fill = [fill timeFill];
        clear timeFill
        
    end
    
    if useZscore
        fill = (fill-zscore.mu)./ zscore.sigma;
    else
        if makeDiscrete
            pctField =  prctile(fill,[0:pctileGranularity:100]);
            fill = (discretize(fill,pctField));
        end
        
        if makeNormalized
            fill = (fill - min(fill))./(max(fill)-min(fill));
            
        end
    end
    
    
elseif ~isfield(data,dataField)
    error([dataField ' is not a valid data structure field'])
else
%     dataField
    [fill, okInd] = baseEvalSingleElementForDataM(data,dataField,delta,usePct,startVect,pctileGranularity,useZscore,makeDiscrete,makeNormalized,useAC,useDeltaTick);
end

