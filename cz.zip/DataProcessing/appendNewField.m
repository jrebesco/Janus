function valMat = appendNewField(nameFilename,newField,truncStartDate)


load(nameFilename)

% newField = 'TRAIL_12M_GROSS_PROFIT';
isWeekly = 0;
c = blp([],[],10000);
bblgTickers = data.tickers(3,:);
if nargin==3
    startDate = truncStartDate
else
    startDate = data.dates{1}
end
endDate =  data.dates{end}

if strcmp(newField,'PCT_INSIDER_SHARES_OUT')
    timeScale = 'weekly';
else
    timeScale = 'daily';
end
[d sec] = history(c,bblgTickers,newField,startDate,endDate,timeScale);
clear valMat i j z dimatch matchValue
numEntries = numel(data.dates);
dateNums = datenum(data.dates);
dateThresh = dateNums(1);
% if strcmp(timeScale,'daily')

for i = 1:numel(d)
    
    if ~isempty(d{i})
        if size(d{i}(:,2),1)==numEntries
            valMat(:,i) = d{i}(:,2);
        else
            for j = 1:numel(dateNums)
                z = 0;
                dimatch = [];
                while isempty(dimatch)
                    if d{i}(1,1)>dateNums(j)
                        dimatch = 1;
                        matchValue = d{i}(dimatch,2);
                    elseif dateNums(j)-z >= dateThresh
                        dimatch = find(d{i}(:,1)==(dateNums(j)-z));
                        matchValue = d{i}(dimatch,2);
                        z = z + 1;
                        
                    else
                        dimatch = 1;
                        matchValue = 0;
                    end
                end
                valMat(j,i) = matchValue;
            end
        end
    else
        valMat(:,i) = zeros(numEntries,1);
    end
    
end
% elseif strcmp(timeScale,'weekly')
%     for i = 1:numel(d)
%         if ~isempty(d{i})
%                 for j = 1:numel(dateNums)
%                 z = 0;
%                 dimatch = [];
%                 while isempty(dimatch)
%                     if d{i}(1,1)>dateNums(j)
%                         dimatch = 1;
%                         matchValue = d{i}(dimatch,2);
%                     elseif dateNums(j)-z >= dateThresh
%                         dimatch = find(d{i}(:,1)==(dateNums(j)-z));
%                         matchValue = d{i}(dimatch,2);
%                         z = z + 1;
%
%                     else
%                         dimatch = 1;
%                         matchValue = 0;
%                     end
%                 end
%                 valMat(j,i) = matchValue;
%             end
%     end
%
% end