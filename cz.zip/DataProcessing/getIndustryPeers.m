% ccc

%% load datafile
load('filt_dataVI_v103')

%% get comps
% [d sec] = getbulkdata(c,data.tickers(3,:),'BLOOMBERG_PEERS')

for i = 1:numel(d.BLOOMBERG_PEERS)
    compStrings = d.BLOOMBERG_PEERS{i};
    peerArray = [];
    for j = 1:numel(compStrings)
        finder = [compStrings{j} ' Equity'];
        [a b] = ismember(finder,data.tickers(3,:));
        if a
            peerArray = [peerArray b];
        end
    end
    peerCell{i}=peerArray;
end
