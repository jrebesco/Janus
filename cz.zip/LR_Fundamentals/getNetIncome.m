function [nicMat] = getNetIncome(tickers,dateVect)

% ref paper http://papers.ssrn.com/sol3/papers.cfm?abstract_id=2670839
% from http://web.utk.edu/~prdaves/Computerhelp/COMPUSTAT/Compustat_manuals/user_05r.pdf
% Net Income (Loss)
% Annual data item number 172
% Quarterly data item number 69
% Variable data item (Business
% Information � Segment Item Value
% File)
% NI
% Units (companies) Millions of dollars
% Annual data availability 1950
% Quarterly data availability First quarter, 1962
% Position number for annual data in
% Daily Fundamental File
% 13
% Position number for quarterly data in
% Daily Fundamental File
% 36
% Position number in Business
% Information � Segment Item Value File
% 39
% This item represents the fiscal period income or loss reported by a company after subtracting expenses
% and losses from all revenues and gains.
% This item includes the effects of:
% 1. Discontinued Operations
% 2. Extraordinary Items
% 3. Income Taxes � Total
% 4. Minority Interest
% This item excludes the effects of common and preferred stock dividends and dollar savings due to
% common stock equivalents.
% This item includes securities gains and losses for banks.
% Annual footnote codes
% AC Reflects an accounting change
% GI Combination of AC and GP
% GP Some or all data is pro forma
% (Continued on following page.)
% 5/2000 Chapter 5 � Data Definitions 163
% Net Income (Loss) (cont.)
% Quarterly footnote codes
% AC Reflects an accounting change
% GI Combination of AC and GP
% GP Some or all data is pro forma

c = blp([],[],10000);

startDate = datestr(dateVect(1),'mm/dd/yyyy');
endDate = datestr(dateVect(end),'mm/dd/yyyy');

[nic sec] = history(c,tickers,'NET_INCOME',startDate,endDate,'daily');
nicMat = standardizeBblgOutToDateVect(dateVect,nic);

close(c)


