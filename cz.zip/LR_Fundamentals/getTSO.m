function [tso, validity] = getTSO(tickers,dateVect)

% ref paper http://papers.ssrn.com/sol3/papers.cfm?abstract_id=2670839
% from http://web.utk.edu/~prdaves/Computerhelp/COMPUSTAT/Compustat_manuals/user_05r.pdf

c = blp([],[],10000);

startDate = datestr(dateVect(1),'mm/dd/yyyy');
endDate = datestr(dateVect(end),'mm/dd/yyyy');

[outCell sec] = history(c,tickers,'EQY_SH_OUT',startDate,endDate,'daily');


% outMat = standardizeBblgOutToDateVect(dateVect,outCell);

shell = zeros(numel(dateVect),numel(outCell))./0;
validity = ones(numel(dateVect),numel(outCell));
for i = 1:numel(outCell)
    if ~isempty(outCell{i})
        [bool loc] = ismember(outCell{i}(:,1),dateVect);
        shell(loc(find(loc>0)),i)=outCell{i}(find(loc>0),2);
        
        missingVals = find(isnan(shell(:,i)));
        goodVals = find(~isnan(shell(:,i)));
        if isempty(goodVals)
            shell(:,i) = shell(:,i-1);
        else
            
            try
                frontNans = missingVals(find(missingVals<goodVals(1)));
            catch
                i
                missingVals
                goodVals
            end
            backNans = missingVals(find(missingVals>goodVals(end)));
            
            if ~isempty(frontNans)
                validity(frontNans,i)=0;
            end
            if ~isempty(backNans)
                validity(backNans,i)=0;
            end
            
            rmgMiss = intersect(find(isnan(shell(:,i))),find(validity(:,i)));
            
            if ~isempty(rmgMiss)
                goodVals = find(~isnan(shell(:,i)));
                disp('nan gaps found, currently no unit tests in getPricesAndValidity done here, please verify')
                for z = 1:numel(rmgMiss)
                    pvsGood = find(goodVals<rmgMiss(z));
                    shell(rmgMiss(z),i) = shell(pvsGood(end),i);
                end
            end
        end
    end
end

tso = shell;
close(c)


