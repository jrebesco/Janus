function indexCell = getBroadSectorIndices(data)

uniSect = unique(data.tickers(5,:));

%% map blanks onto misc
blanks = find(strcmp(data.tickers(5,:),''));
for i = 1:numel(blanks)
    data.tickers{5,blanks(i)} = 'Miscellaneous';
end

blanks = find(strcmp(data.tickers(5,:),'Emerging Markets Bond'));
for i = 1:numel(blanks)
    data.tickers{5,blanks(i)} = 'Non-eq';
end

blanks = find(strcmp(data.tickers(5,:),'Intermediate-Term Bond'));
for i = 1:numel(blanks)
    data.tickers{5,blanks(i)} = 'Non-eq';
end

blanks = find(strcmp(data.tickers(5,:),'Trading-Leveraged Debt'));
for i = 1:numel(blanks)
    data.tickers{5,blanks(i)} = 'Non-eq';
end

%% map Finance onto Financial
fin = find(strcmp(data.tickers(5,:),'Finance'));
for i = 1:numel(fin)
data.tickers{5,fin(i)} = 'Financial';
end
clear fin i blanks
%% map application software onto technology

ap = find(strcmp(data.tickers(5,:),'Application Software'));
for i = 1:numel(ap)
data.tickers{5,ap(i)} = 'Technology';
end

clear ap

%% map Healthcare onto Health Care
ap = find(strcmp(data.tickers(5,:),'Healthcare'));
for i = 1:numel(ap)
data.tickers{5,ap(i)} = 'Health Care';
end

%% Basic Materials onto Industr Goods
ap = find(strcmp(data.tickers(5,:),'Basic Materials'));
for i = 1:numel(ap)
data.tickers{5,ap(i)} = 'Industrial Goods';
end

%% BioTech onto Tech
ap = find(strcmp(data.tickers(5,:),'Biotechnology'));
for i = 1:numel(ap)
data.tickers{5,ap(i)} = 'Technology';
end

%% Drug Mfg onto Tech
ap = find(strcmp(data.tickers(5,:),'Drug Manufacturers - Other'));
for i = 1:numel(ap)
data.tickers{5,ap(i)} = 'Technology';
end

%% Consumer goods onto Consumer non-durables
ap = find(strcmp(data.tickers(5,:),'Consumer Goods'));
for i = 1:numel(ap)
data.tickers{5,ap(i)} = 'Consumer Non-Durables';
end

%% Mfg onto industrial goods
ap = find(strcmp(data.tickers(5,:),'Manufacturing'));
for i = 1:numel(ap)
data.tickers{5,ap(i)} = 'Capital Goods';
end

ap = find(strcmp(data.tickers(5,:),'Industrial Goods'));
for i = 1:numel(ap)
data.tickers{5,ap(i)} = 'Capital Goods';
end
%% utilities onto public utilities
ap = find(strcmp(data.tickers(5,:),'Utilities'));
for i = 1:numel(ap)
data.tickers{5,ap(i)} = 'Public Utilities';
end


%% Services onto consumer services
ap = find(strcmp(data.tickers(5,:),'Services'));
for i = 1:numel(ap)
data.tickers{5,ap(i)} = 'Consumer Services';
end
%% end manual cleanup
uniSect = unique(data.tickers(5,:));

for i = 1:numel(uniSect)
    indexCell{i} = find(strcmp(data.tickers(5,:),uniSect{i}));
end

% % % % disp('done')