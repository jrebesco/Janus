function valMat = getAssets(nameFilename)

load(nameFilename)


% newField = 'TRAIL_12M_GROSS_PROFIT';
newField = 'BS_TOT_ASSET';

c = blp([],[],10000);
bblgTickers = data.tickers(3,:);
startDate = data.dates{1}
endDate =  data.dates{end}
for z = 1:numel(bblgTickers)
[d{z} sec] = history(c,bblgTickers(z),newField,startDate,endDate,'daily');
end

clear valMat i j z dimatch matchValue
numEntries = numel(data.dates);
dateNums = datenum(data.dates);
dateThresh = dateNums(1);
for i = 1:numel(d)
    i;
    if ~isempty(d{i})
        if size(d{i}(:,2),1)==numEntries
            valMat(:,i) = d{i}(:,2);
        else
            for j = 1:numel(dateNums)
                z = 0;
                dimatch = [];
                while isempty(dimatch)
                    if d{i}(1,1)>dateNums(j)
                        dimatch = 1;
                        matchValue = d{i}(dimatch,2);
                    elseif dateNums(j)-z >= dateThresh
                        dimatch = find(d{i}(:,1)==(dateNums(j)-z));
                        matchValue = d{i}(dimatch,2);
                        z = z + 1;
                        
                    else
                        dimatch = 1;
                        matchValue = 0;
                    end
                end
                valMat(j,i) = matchValue;
            end
        end
    else
        valMat(:,i) = zeros(numEntries,1);
    end
    
end