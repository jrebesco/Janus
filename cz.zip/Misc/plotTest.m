ccc 

load tmpRes
load(options.global.file)


%% evaluate MN correspondence
plotMultiNetPerformance(filt,finalTestFilter,perfAll,15,'')

%% evaluate model consistency
figure;
subplot(2,2,1)
plot([ones(1,numel(halfSharpe));2*ones(1,numel(halfSharpe))],[halfSharpe;backSharpe],'k','LineWidth',3)
hold on
plot(ones(numel(halfSharpe)),halfSharpe,'b.','MarkerSize',40)
plot(2*ones(numel(backSharpe)),backSharpe,'b.','MarkerSize',40)
set(gca,'XLim',[0.9 2.1])
set(gca,'XTick',[1 2])
set(gca,'XTickLabel',{'front','back'})
ylabel('\mu / \sigma','FontSize',16)

%% sector expo
sect = unique(data.tickers(5,finalTestFilter));

for i = 1:numel(sect); 
    longE(i) = numel(find(strcmp(data.tickers(5,finalTestFilter(1:options.test.numPerSide)),sect{i})));
    shortE(i) = numel(find(strcmp(data.tickers(5,finalTestFilter(options.test.numPerSide+1:end)),sect{i})));
end
figure;
ax = gca;
bar([longE;shortE]')
legend('L','S')
for i = 1:numel(sect); if isempty(sect{i}); sect{i} = 'N/Listed'; end; end;
set(gca,'XTick',1:1:numel(sect));
set(gca,'XTickLabel',sect);
ax.XTickLabelRotation = 45;

%% Betas  WHAT ARE UNITs ON BETA?
betas = data.beta(end,finalTestFilter);
figure;
% plotyy(1:1:numel(betas),betas,1:1:numel(betas),NNTestWeights,@bar)
bar([betas;NNTestWeights./500]')

%% historical prices
hisPx = data.prices(end-40:end,finalTestFilter);

%% hypothetical port perf ag SPY
hisNL = hisPx*NNTestWeights';
hisPerf = hisNL-hisNL(1);
inl = hisPx(1,:)*abs(NNTestWeights)';
hisPerf = hisPerf./inl;

spyP = (data.spy(end-40:end)-data.spy(end-40))./data.spy(end-40);
figure;
hold on
plot(hisPerf)
plot(spyP)
corr(spyP,hisPerf)