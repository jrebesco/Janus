function [outMat] = getTotLiab(tickers,dateVect)

% ref paper http://papers.ssrn.com/sol3/papers.cfm?abstract_id=2670839
% from http://web.utk.edu/~prdaves/Computerhelp/COMPUSTAT/Compustat_manuals/user_05r.pdf

c = blp([],[],10000);

startDate = datestr(dateVect(1),'mm/dd/yyyy');
endDate = datestr(dateVect(end),'mm/dd/yyyy');


[outCell sec] = history(c,tickers,'BS_TOT_LIAB2',startDate,endDate,'daily');  

outMat = standardizeBblgOutToDateVect(dateVect,outCell);

close(c)


