function [finalWeights,eligLongs, eligShorts] = genFinalOutputStructuredModel_v2(options,data,fund,dateVect,pdiffStr)

%% find equivalent date
dataIndex  = numel(data.dates);
[eligLongs eligShorts] = getEligibleIndicesFromStructMod(data,dataIndex,dateVect,fund,options,pdiffStr);

%% doublecheck validity
eligLongs = eligLongs(find(data.validity(end,eligLongs)));
eligShorts = eligShorts(find(data.validity(end,eligShorts)));

finalWeights = [];
if ~isempty(eligShorts)
    if ~isempty(eligLongs)
        %% weights
        finalWeights = genPortWeights(data,[eligLongs eligShorts],eligLongs,eligShorts,dataIndex,'uniformCapBeta',100);
        if options.finalBetaAdj==1
            finalWeights(find(finalWeights>0))= options.finalBetaAdjCoef.*finalWeights(find(finalWeights>0));
        end
           
    end
   
end
