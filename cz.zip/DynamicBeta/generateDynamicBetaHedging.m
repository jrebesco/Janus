function [finSharpe,garchSharpe,finModel,garchOut] = generateDynamicBetaHedging(data,options,modelArray)

% GENERATEDYNAMICBETAHEDGING generates a beta-driven macro scaling factor
% to the portfolio as described in <PAPER>
% Inputs:
% data - datastruct.  The required fields are data.marketRealizedVol and
% data.bearIndicator.
% options - optionstruct.  Passthrough to generateDailyReturn.
% modelArray - cell array, 1xoptions.test.testDates, of model output
% structures.  Passed to generateDailyReturn 
% Outputs:
% finSharpe - uses the linear regression of getModelRegressionAgPerf
% garchSharpe - uses the GARCH regression model
% finModel - the linear regression
% garchModel - the GARCH model
% %%%%%
% Version history
% 03 Mar 2017 - v1.2 - reintroduced perf calculation
% 02 Mar 2017 - v1.1 - Added documentation, exposed linear and garch models.
% 13 Jan 2017 - v1.0 - Wrote function

garchOut = [];
dailyReturn = generateDailyReturn(modelArray,options);
[regressCoef, alignIndices] = getModelRegressionAgPerf(data,options,modelArray);
finModel = regressCoef;
for mi = 1:numel(modelArray); perf(mi)= modelArray{mi}.finalPnl./modelArray{mi}.initialNetLiq; end
%% scale returns
%%% mu_hat
for mi = 1:numel(modelArray)
    startIndex  = modelArray{mi}.timeIndex(1);
    valMat = [1;data.bearIndicator(startIndex);data.marketRealizedVol(startIndex).^2;data.bearIndicator(startIndex).*data.marketRealizedVol(startIndex)];
    muHat(mi) = valMat'*regressCoef;
end

%%%% GARCH
size(dailyReturn)
if sum(dailyReturn)==0
    disp('all DR is 0')
elseif ~sum(isnan(dailyReturn))==0
    disp('DR has nan val')
end
% save dailyReturn dailyReturn

%%%% trailing vol
try
    varGARCH = estimate(gjr(1,1),dailyReturn');
    goodGarch=1;
catch
    goodGarch=0;
end

for sigInd = 1:options.dynamicBeta.marketRealVolLookback
    sigmMat(sigInd,:) = dailyReturn(sigInd:end+sigInd-options.dynamicBeta.marketRealVolLookback);
end
sigMat = std(sigmMat);

% allARSigma =
%%% sigma_hat
for si = 1:numel(modelArray)
    startIndex = modelArray{si}.timeIndex(1);
    dailyRetInd = find(startIndex==alignIndices);
    
    if numel(dailyRetInd)>1
        warning('dailyRetInd must be scalar')
        dailyRetInd = dailyRetInd(end);
    end
    
    if dailyRetInd < options.dynamicBeta.marketRealVolLookback
        sigRet(si) = std(dailyReturn);
    else
        %         dailyRetInd;
        %         options.dynamicBeta.marketRealVolLookback;
        sigRet(si) = std(dailyReturn(dailyRetInd-options.dynamicBeta.marketRealVolLookback:dailyRetInd-1));
    end
    
    if goodGarch==1
        if dailyRetInd > 2
            garchEst = forecast(varGARCH,1,'Y0',dailyReturn(dailyRetInd-1));
        else
            garchEst = forecast(varGARCH,1,'Y0',dailyReturn(1));
        end
        garchSigEst(si) = garchEst(1);
        garchOut = varGARCH;
    end
end
sigRet(find(sigRet==0))=mean(sigRet);
%         %%%%% regress GARCH and trailing
sigmaHat = sigRet;
% % weight
portfolioWeight = muHat./(sigmaHat.^2);

if goodGarch==1
    garchWeight = muHat./(garchSigEst.^2);
else
    garchWeight = ones(size(portfolioWeight));
end

portfolioWeight(portfolioWeight<0)=0;
garchWeight(garchWeight<0)=0;
if sum(portfolioWeight)==0||sum(portfolioWeight.*perf)==0
    finSharpe = 0;
else
    finSharpe = mean(perf.*portfolioWeight)./std(perf.*portfolioWeight);
end
if isnan(finSharpe)&&~isnan((mean(perf)./std(perf)))
    error('finWeight busted')
end
if sum(garchWeight)==0||sum(garchWeight.*perf)==0
    garchSharpe = 0;
else
    garchSharpe = mean(perf.*garchWeight)./std(perf.*garchWeight);
end