function [datam,result,okInd] = assembleData(data,fieldsToAssemble,startVect,testLength,isEvaluation,pctileGranularity,useZscore,makeDiscrete,makeNormalized,preloadOkInd)
% if nargin <= 4;
% pctileGranularity = 10;
% end
% fieldsToAssemble is a nx3 cell array, containing field name,timeDelta, and
% usePct.  timeDelta of 0 defaults to snapshot, negative timeDelta looks
% backward, positive delta for eval only but supported.  usePct valid only
% if timeDelta ~=0,

if ~exist('preloadOkInd','var')
    preloadOkInd = 0;
end

if preloadOkInd == 1
    [datam,result,okInd] = assembleDataPreComputeOkInd(data,fieldsToAssemble,startVect,testLength,isEvaluation,pctileGranularity,useZscore,makeDiscrete,makeNormalized);
    
else
    datam = [];
    for i = 1:size(fieldsToAssemble,1)
        i
        field = fieldsToAssemble(i,:);
        [dmtmp, okInd] = processSingleElementForDataM(data,field,startVect,pctileGranularity,useZscore,makeDiscrete,makeNormalized);
        datam(i,:) = dmtmp;
    end
    
    if isEvaluation
        result = [];
    else
        resultC{1} = 'prices';
        resultC{2} = testLength;
        resultC{3} = 1;
        
        [result, okResult] = processSingleElementForDataM(data,resultC,startVect,100,0,0,0);
        
        if ~isequal(okResult,okInd)
            error('Index mismatch')
        end
    end
end