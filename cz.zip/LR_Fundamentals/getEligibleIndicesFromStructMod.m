function [eligLongs, eligShorts] = getEligibleIndicesFromStructMod(data,dateIndex,dateVect,fund,options,pdiffStr)

fundaIndex = find(datenum(data.dates{dateIndex})==dateVect);
screen = genStructuredScreenWStruct(data,dateIndex,fund,fundaIndex,options,pdiffStr);

% % % if numel(pdiffCell)==0
% % %     screen = genStructuredScreen(data,dateIndex,fund,fundaIndex,options);
% % % elseif numel(pdiffCell)==1
% % %     screen = genStructuredScreenWSQB(data,dateIndex,fund,fundaIndex,options,pdiffCell{1});
% % % elseif numel(pdiffCell)==2
% % %     screen = genStructuredScreenWSQBWANN(data,dateIndex,fund,fundaIndex,options,pdiffCell{1},pdiffCell{2});
% % % elseif numel(pdiffCell)==3
% % %     screen = genStructuredScreenWSQBWRBCWANN(data,dateIndex,fund,fundaIndex,options,pdiffCell{1},pdiffCell{2},pdiffCell{3});
% % % end


eligLongs = 1:1:size(data.tickers,2);
eligShorts = 1:1:size(data.tickers,2);
for i = 1:numel(screen.long.index)
    eligLongs = intersect(eligLongs,screen.long.index{i});
    eligShorts = intersect(eligShorts,screen.short.index{i});
end