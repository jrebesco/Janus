function data = addEPR(data,fund);

fd = fund.dates;
dd = datenum(data.dates);
for i = 1:numel(dd)
    tmpInd = find(dd(i)==fd);
    if ~isempty(tmpInd)
    dataIndex(i) = tmpInd;
    else
        dataIndex(i) = nan;
    end
end

for i = 1:numel(dd)
    if ~isnan(dataIndex(i))
        ebit = fund.ebitda(dataIndex(i),:);
        naneb = find(isnan(ebit));
        ebit(naneb) = fund.incCSEAdj(dataIndex(i),naneb);
        em(i,:) = ebit./fund.mktCap(dataIndex(i),:);
    else
        em(i,:) = em(i-1,:);
    end
end
data.ebitaMcRat = em;
clear fd dd i tmpInd dataIndex em