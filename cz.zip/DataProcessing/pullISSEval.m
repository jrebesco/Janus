function shellMat = pullISSEval(dateVect,startDate,endDate,tickerList,field)
today = datevec(now);
today(4:6) = 0;
today = datenum(datestr(today));
c = blp([],[],10000);

[d sec] = history(c,tickerList,field,startDate,endDate,'daily');
shellMat = zeros(numel(dateVect),numel(d));
for i = 1:numel(d)
    baseArray = d{i};
    i
    if i==48
        disp('2830')
    end
    if ~isempty(baseArray)
        
        anyNan = find(isnan(baseArray(:,2)));
        if ~isempty(anyNan)
            
            for nanIndex = 1:numel(anyNan)
                if anyNan(nanIndex)==1
                    baseArray(anyNan(nanIndex),2)= baseArray(anyNan(nanIndex)+1,2);
                else
                    baseArray(anyNan(nanIndex),2)= baseArray(anyNan(nanIndex)-1,2);
                end
            end
        end
        baseArray(end,1) = today;
        
        allDraw = baseArray(:,1);
        repeats = [find(diff(allDraw)~=0);numel(allDraw)];
        
        baseArray = [baseArray(repeats,1) baseArray(repeats,2)];
       
        dates = find(ismember(dateVect,baseArray(:,1)));
        
        if numel(dates) < numel(baseArray(:,1))
            misses = find(ismember(baseArray(:,1),dateVect)==0);
            for q = 1:numel(misses)
                dist = abs(dateVect-baseArray(misses(q),1));
                [~,minVal] = min(dist);
                baseArray(misses(q),1) = dateVect(minVal(end));
            end
            dates = find(ismember(dateVect,baseArray(:,1)));
        end
        allDraw = baseArray(:,1);
        repeats = [find(diff(allDraw)~=0);numel(allDraw)];
        baseArray = [baseArray(repeats,1) baseArray(repeats,2)];
        
          shellMat(dates,i)=baseArray(:,2);
      
        for z = 1:numel(baseArray(:,2))
            if z==1
                shellMat(1:dates(z),i) = baseArray(z,2);
            elseif z==numel(baseArray(:,2))
%                 shellMat(dates(z):end,i) = baseArray(z,2);
                shellMat(dates(z-1):dates(z)-1,i)= baseArray(z,2);
            else
                shellMat(dates(z-1):dates(z)-1,i) = baseArray(z-1,2);
            end
            
        end
        
    end
end