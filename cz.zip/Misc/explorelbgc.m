ccc
load('filt_dataVI_v5')

gllagV = [30];
spydelV = [30];
for g = 1:numel(gllagV)
    for s = 1:numel(spydelV)
        gll = gllagV(g);
        spyDel = spydelV(s);
        
        lbdel = (data.lb(gll+1:end) - data.lb(1:end-gll))./data.lb(1:end-gll);
        gcdel = (data.gc(gll+1:end) - data.gc(1:end-gll))./data.gc(1:end-gll);
        lbgc = lbdel-gcdel;
        
        lbgcInd = gll+1:numel(data.lb);
        
        spy = (data.spy(spyDel+1:end) - data.spy(1:end-spyDel))./data.spy(1:end-spyDel);
        spyInd = 1:numel(data.spy)-spyDel;
        
        indices2Use = intersect(lbgcInd,spyInd);
        
        for t = 1:numel(indices2Use)
            dm(t,1) = lbgc(find(indices2Use(t)==lbgcInd));
            dm(t,2) = spy(find(indices2Use(t)==spyInd));
        end
        cm(g,s) = corr(dm(:,1),dm(:,2));
    end
end


