function data = dataPreProcessingForSQB(data,options)

data.bookval(data.bookval>options.bc.fit.bvCaps(2))=options.bc.fit.bvCaps(2);
data.bookval(data.bookval<options.bc.fit.bvCaps(1))=options.bc.fit.bvCaps(1);

if isfield(data,'roa')
    data.roa(data.roa>options.bc.fit.roaCaps(2))=options.bc.fit.roaCaps(2);
    data.roa(data.roa<options.bc.fit.roaCaps(1))=options.bc.fit.roaCaps(1);
end
if isfield(data,'gpoa')
    data.gpoa(data.gpoa>options.bc.fit.gpoaCaps(2))=options.bc.fit.gpoaCaps(2);
    data.gpoa(data.gpoa<options.bc.fit.gpoaCaps(1))=options.bc.fit.gpoaCaps(1);
end
if isfield(data,'cfoa')
    data.cfoa(data.cfoa>options.bc.fit.cfoaCaps(2))=options.bc.fit.cfoaCaps(2);
    data.cfoa(data.cfoa<options.bc.fit.cfoaCaps(1))=options.bc.fit.cfoaCaps(1);
end

if isfield(data,'fcfPS')
    data.fcfPS(data.fcfPS>options.bc.fit.fcfPSCaps(2))=options.bc.fit.fcfPSCaps(2);
    data.fcfPS(data.fcfPS<options.bc.fit.fcfPSCaps(1))=options.bc.fit.fcfPSCaps(1);
end

data.fcfPS(find(isinf(data.fcfPS(:))))=0;
data.cfoa(find(isinf(data.cfoa(:))))=0;
data.gpoa(find(isinf(data.gpoa(:))))=0;
data.roa(find(isinf(data.roa(:))))=0;


q = data.prices>options.test.minValidPrice;
data.validity = data.validity.*q;

for i = 1:size(data.volume,2);
    td = data.volume(:,i);
    tdt = td(:);
ftv = filter(ones(41,1)/41,1,[tdt; zeros(20,1)]);
fom(:,i) = ftv(21:end);
end
q = fom>options.test.minValidVol;
data.validity = data.validity.*q;
%% check for two-day null prices and amend

data = cleanPriceGaps(data);
data = cleanBVGaps(data);
data = cleanBetaGaps(data);
data = cleanMCGaps(data);
data = cleanBadTickers(data);
