%buildFullHistoricalModelDataSets populate the data structures for MC
% INPUTS:
% startDate mm/dd/yyyy
% endDate mm/dd/yyyy
% tickersAll - a cell array of ticker names for BBLG lookup, looks for file
% 'tickersAll' to populate
% OUTPUTS: 
% 'data' struct
% 'fund' struct
%%%%%%%%%%%%%%%%%%%%%%%%%% Revision history %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% 1-Dec-2016, v1.0- scripted.
%%% 3-Jan-2017, v1.1- commented out calls to full the unused (atm) datafields
% of netSalesTurnover, PhysPlantEquipment, NoncurrentAssets, and
% OtherAssets.
%%% 10-Jan-2017, v.1.2 - added data calls to openPrices, vwapPrices,
%%% highPrices, and lowPrices.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load tickersAll
% tickersAll = data.tickers;
% clear data
data.tickers = tickersAll;
tickerList = tickersAll(3,:);
junkList = [];
suspectList = [];
tickerList = tickerList(setdiff(1:1:numel(tickerList),junkList));

dateVect = getAllTradeDateVect(startDate,endDate);

1
fund.incCSEAdj = getIncomeBeforeXoAdjCStockEquiv(tickerList,dateVect);
[i j] = find(isnan(fund.incCSEAdj)); suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
2
fund.incBFXoAfC = getIncomeBeforeXoAvailForComm(tickerList,dateVect);
[i j] = find(isnan(fund.incBFXoAfC));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
3
fund.incBfXoItems = getIncomeBeforeXoItems(tickerList,dateVect);
[i j] = find(isnan(fund.incBfXoItems));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
4
fund.assets = getTotalAssets(tickerList,dateVect);
[i j] = find(isnan(fund.assets));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
5
fund.divPaid = getDividends(tickerList,dateVect);
[i j] = find(isnan(fund.divPaid));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
6
fund.netIncome = getNetIncome(tickerList,dateVect);
[i j] = find(isnan(fund.netIncome));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
7
fund.stockHEq = getStockholdEq(tickerList,dateVect);
[i j] = find(isnan(fund.stockHEq));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
8
fund.totRev = getTotalRevenues(tickerList,dateVect);
[i j] = find(isnan(fund.totRev));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
9
% fund.salesTurn = getSalesTurnoverNet(tickerList,dateVect);
% [i j] = find(isnan(fund.salesTurn));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
10
% fund.ppe = getPropPlantEquip(tickerList,dateVect);
% [i j] = find(isnan(fund.ppe));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
11
fund.ltDebt = getLtDebt(tickerList,dateVect);
[i j] = find(isnan(fund.ltDebt));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
12
fund.disOps = getDisconOps(tickerList,dateVect);
[i j] = find(isnan(fund.disOps));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
13
fund.totLiab = getTotLiab(tickerList,dateVect);
[i j] = find(isnan(fund.totLiab));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
14
fund.curLiab = getCurLiab(tickerList,dateVect);
[i j] = find(isnan(fund.curLiab));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
15
fund.curAssets = getCurAsset(tickerList,dateVect);
[i j] = find(isnan(fund.curAssets));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
16
% fund.nonCurAssets = getNonCurAsset(tickerList,dateVect);
% [i j] = find(isnan(fund.nonCurAssets));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
17
fund.ptxIncome = getPretaxIncome(tickerList,dateVect);
[i j] = find(isnan(fund.ptxIncome));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
18
fund.incTax = getTotalIncomeTax(tickerList,dateVect);
[i j] = find(isnan(fund.incTax));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
19
fund.othAssetTot = getOtherAssetsTotal(tickerList,dateVect);
[i j] = find(isnan(fund.othAssetTot));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
20
fund.liabAndStockhEqt = getLiabilitiesAndStockholderEquity(tickerList,dateVect);
[i j] = find(isnan(fund.liabAndStockhEqt));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
21
fund.commOrdEqyTot = getCommonOrdEquityTot(tickerList,dateVect);
[i j] = find(isnan(fund.commOrdEqyTot));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
22
fund.prefStock = getPreferredStock(tickerList,dateVect);
[i j] = find(isnan(fund.prefStock));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
23
fund.xoItems = getXoItems(tickerList,dateVect);
[i j] = find(isnan(fund.xoItems));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
24
fund.othLiab = getOtherLiabs(tickerList,dateVect);
[i j] = find(isnan(fund.othLiab));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
25
fund.ebitda = getEbitda(tickerList,dateVect);
[i j] = find(isnan(fund.othLiab));suspectList = [suspectList unique(j)'];save('tmp.mat');clear i j
    suspectList = unique(suspectList);
    cleanList = setdiff(1:1:numel(tickerList),suspectList);
    %%
    fund.mktCap = getMarketCap(tickerList,dateVect);
    [fund.prices validity] = getPricesAndValidity(tickerList,dateVect);
    [fund.shares validSh] = getTSO(tickerList,dateVect);
    
    save tmpFund
%%
okInd = 1;


mna = [15,42,54,70,71,109,160,194,196,200,207,223,225,236,263,284,354,365,415,426,449,450,464,486,495,498,517,535,536,...
    540,580,619,640,643,663,664,668,753,764,783,824,839,848,900,981,1021,1029,1051,1095,1107,1110,1139,1147,1198,1239,...
    1252,1307,1371,1382,1397,1415,1435,1436,1444,1502,1505,1556,1620,1639,1726,1746,1752,1756,1773,1781,1788,1815,1833,...
    1836,1903,1923,1935,1948,1953,1979,1991,1998,2032,2038,2044,2054,2096,2110,2162,2247,2266,2294,2310,2325,2393,2435,...
    2443,2451,2471,2544,2557,2561,2573,2616,2625,2681,2817,74,190,215,510,1041,1519,1660,1716,1900,1932 2160 2418 2764,...
    27 40 47 127 159 682 1062 1112 1138 1204 1279 1383 1475 1851 1924 2034 2365 2615 2648 199 530 798 1053 1061 1215,...
    1277 1320 1829 1945 2198 2438 2460 2613 2797];
data.mnaOuts = mna;
%% get bblg connection
c = blp([],[],10000);
bblgTickers = data.tickers(3,:);

% startDate = data.dates{1}
% startDate = '12/29/2006';
% startDate = '02/01/2016';
globalStartDate = startDate;
% endDate = datestr(datenum(date)-3 ,'mm/dd/yyyy')


%% px
[d sec] = history(c,bblgTickers,'PX_LAST',globalStartDate,endDate,'daily');
for i = 1:numel(d{okInd}(:,1))
    dateAppend{i} = datestr(d{okInd}(i,1),'mm/dd/yyyy');
end
data.dates = dateAppend;
clear dateAppend
clear tickers

%%
[pxmat]  = valArrayBblgPull(d,okInd,data);
% pxmat = fixOneOffPxEvents(pxmat,bblgTickers,d);
data.prices = pxmat
suspTickers = find(sum(pxmat)==0);

%% BV next to clear px
[d sec] = history(c,bblgTickers,'BOOK_VAL_PER_SH',startDate,endDate,'daily');
[bvmat] = valArrayBblgPull(d,okInd,data);
bvpx = bvmat./pxmat;
bvpx(isnan(bvpx))=0;
data.bookval = bvpx
clear pxmat bvmat
%% MC
[d sec] = history(c,bblgTickers,'CUR_MKT_CAP',startDate,endDate,'daily');
[mcmat] = valArrayBblgPull(d,okInd,data);
data.mcap = mcmat
clear mcmat
%% beta
[d sec] = history(c,bblgTickers,'BETA_MINUS',startDate,endDate,'daily');
betamat = valArrayBblgPull(d,okInd,data);
data.beta = betamat
clear betamat
%%
[d sec] = history(c,bblgTickers,'CURR_ENTP_VAL',startDate,endDate,'daily');
enterprisemat = valArrayBblgPull(d,okInd,data);
data.ev2ebita = enterprisemat./fund.ebitda;
clear enterprisemat

%% add single entries
%% spy
[d sec] = history(c,'SPY US Equity','PX_LAST',startDate,endDate,'daily');
data.spy = d(:,2);
%% VIX
[d sec] = history(c,'VIX Index','PX_LAST',startDate,endDate,'daily');
data.vix = d(:,2);
%% gc
[d sec] = history(c,'GC1 Comdty','PX_LAST',startDate,endDate,'daily');
data.gc = d(:,2);
%% lb
[d sec] = history(c,'LB1 Comdty','PX_LAST',startDate,endDate,'daily');
data.lb = d(:,2);

clear d sec

%% vixContango
% [d sec] = history(c,'UX1 Index','PX_LAST',startDate,endDate,'daily');
% [d2 sec] = history(c,'UX5 Index','PX_LAST',startDate,endDate,'daily');
% data.vixCont = d2(:,2)-d(:,2);
clear d d2 sec

%% divy
save('tmp.mat','data')
clear bblgTickers bval bvmat bvupdate d endDate globalStartDate i mna numelD okI pxmat q sec startDate tickerInd tm tmp tmp2 tmp3
dy = appendNewField('tmp','DIVIDEND_YIELD');
data.divyld = dy;
clear dy
save('tmp.mat','data')

roa = appendNewField('tmp','ANN_RETURN_ON_ASSET');
data.roa = roa;
save('tmp.mat','data')
clear roa

tso = appendNewField('tmp','EQY_SH_OUT');
gp = appendNewField('tmp','TRAIL_12M_GROSS_PROFIT');
data.grossPPS = gp./tso
save('tmp.mat')

fcf = appendNewField('tmp','CF_FREE_CASH_FLOW');
data.fcfPS = fcf./tso
save('tmp.mat')
clear tso

bs_tot_assets=getAssets('tmp');
data.gpoa = gp./bs_tot_assets
data.cfoa = fcf./bs_tot_assets

clear gp fcf tso

data.fcfPS((isnan(data.fcfPS))) = 0;
data.roa((isnan(data.roa))) = 0;
data.cfoa((isnan(data.cfoa))) = 0;
data.gpoa((isnan(data.gpoa))) = 0;
data.roa((isnan(data.roa))) = 0;
data.grossPPS((isnan(data.grossPPS))) = 0;
data.ebitdaMcRat = fund.mktCap./fund.ebitda;

%% pe
save('tmp.mat')
data.pe = appendNewField('tmp.mat','PE_RATIO');
save('tmp.mat')
data.volume = appendNewField('tmp.mat','VOLUME');

%% additional price fields

data.openPrices = appendNewField('tmp.mat','PX_OPEN');
save('tmp.mat')
data.highPrices = appendNewField('tmp.mat','PX_HIGH');
save('tmp.mat')
data.lowPrices = appendNewField('tmp.mat','PX_LOW');
save('tmp.mat')
data.vwapPrices = appendNewField('tmp.mat','EQY_WEIGHTED_AVG_PX');
save('tmp.mat')
%% data validity

data = cleanPriceGaps(cleanPriceGaps(cleanPriceGaps(cleanPriceGaps(cleanPriceGaps(cleanPriceGaps(data))))));
data = dataValidity(data);
save('tmp.mat')

%% build external scores