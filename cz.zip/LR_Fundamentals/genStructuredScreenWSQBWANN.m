function screen = genStructuredScreenWSQBWANN(data,dataIndex,fund,fundaIndex,options,sqbPdiff,annPdiff)

screen.names{1} = 'fundReg';
[misPx okFunsIndex] = calcMispricing(fund,fundaIndex);
screen.long.index{1} = getFiltIndices(misPx,options.test.fundReg.longThresh,options.test.fundReg.longSign);
screen.long.value{1} = misPx(screen.long.index{1});

screen.short.index{1} = getFiltIndices(misPx,options.test.fundReg.shortThresh,options.test.fundReg.shortSign);
screen.short.value{1} = misPx(screen.short.index{1});

screen.names{end+1} = 'beta';
screen.long.index{end+1} = getFiltIndices(data.beta(dataIndex,:),options.test.beta.longThresh,options.test.beta.longSign);
screen.long.value{end+1} = data.beta(dataIndex,screen.long.index{end});

screen.short.index{end+1} = getFiltIndices(data.beta(dataIndex,:),options.test.beta.shortThresh,options.test.beta.shortSign);
screen.short.value{end+1} = data.beta(dataIndex,screen.short.index{end});

screen.names{end+1} = 'shortRevMom';
shortDelta = (data.prices(dataIndex,:)-data.prices(dataIndex-20,:))./data.prices(dataIndex-20,:);
screen.long.index{end+1} = getFiltIndices(shortDelta,options.test.pxmShort.longThresh,options.test.pxmShort.longSign);
screen.long.value{end+1} = shortDelta(screen.long.index{end});

screen.short.index{end+1} = getFiltIndices(shortDelta,options.test.pxmShort.shortThresh,options.test.pxmShort.shortSign);
screen.short.value{end+1} = shortDelta(screen.short.index{end});

screen.names{end+1} = 'longFollMom';
shortDelta = (data.prices(dataIndex,:)-data.prices(dataIndex-220,:))./data.prices(dataIndex-220,:);
screen.long.index{end+1} = getFiltIndices(shortDelta,options.test.pxmLong.longThresh,options.test.pxmLong.longSign);
screen.long.value{end+1} = shortDelta(screen.long.index{end});

screen.short.index{end+1} = getFiltIndices(shortDelta,options.test.pxmLong.shortThresh,options.test.pxmLong.shortSign);
screen.short.value{end+1} = shortDelta(screen.short.index{end});

screen.names{end+1} = 'BV/PX rat';
screen.long.index{end+1} = getFiltIndices(data.bookval(dataIndex,:),abs(options.test.bvpx.longThresh),options.test.bvpx.longSign);
screen.long.value{end+1} = data.bookval(dataIndex,screen.long.index{end});
screen.short.index{end+1} = getFiltIndices(data.bookval(dataIndex,:),abs(options.test.bvpx.shortThresh),options.test.bvpx.shortSign);
screen.short.value{end+1} = data.bookval(dataIndex,screen.short.index{end});

screen.names{end+1} = 'PE ratio';
screen.long.index{end+1} = getFiltIndices(data.pe(dataIndex,:),abs(options.test.per.longThresh),options.test.per.longSign);
screen.long.value{end+1} = data.pe(dataIndex,screen.long.index{end});
screen.short.index{end+1} = getFiltIndices(data.pe(dataIndex,:),abs(options.test.per.shortThresh),options.test.per.shortSign);
screen.short.value{end+1} = data.pe(dataIndex,screen.short.index{end});

screen.names{end+1} = 'PE ratio - sector';
screen.long.index{end+1} = getSectorFiltIndices(data,abs(options.test.perSect.longThresh),options.test.perSect.longSign,'broadSector',data.pe(dataIndex,:));
screen.long.value{end+1} = data.pe(dataIndex,screen.long.index{end});
screen.short.index{end+1} = getSectorFiltIndices(data,abs(options.test.perSect.shortThresh),options.test.perSect.shortSign,'broadSector',data.pe(dataIndex,:));
screen.short.value{end+1} = data.pe(dataIndex,screen.short.index{end});

screen.names{end+1} = 'mispx - sector';
screen.long.index{end+1} = getSectorFiltIndices(data,abs(options.test.mispxSect.longThresh),options.test.mispxSect.longSign,'broadSector',misPx);
screen.long.value{end+1} = misPx(screen.long.index{end});
screen.short.index{end+1} = getSectorFiltIndices(data,abs(options.test.mispxSect.shortThresh),options.test.mispxSect.shortSign,'broadSector',misPx);
screen.short.value{end+1} = misPx(screen.short.index{end});

screen.names{end+1} = 'sqb - pdiff';
if sum(sqbPdiff(dataIndex,:))==0
    dataIndex
    error('failed Pdiff eval')
end
screen.long.index{end+1} = getFiltIndices(sqbPdiff(dataIndex,:),abs(options.test.sqbPdiff.longThresh),options.test.sqbPdiff.longSign);
screen.long.value{end+1} = sqbPdiff(dataIndex,screen.long.index{end});
screen.short.index{end+1} = getFiltIndices(sqbPdiff(dataIndex,:),abs(options.test.sqbPdiff.shortThresh),options.test.sqbPdiff.shortSign);
screen.short.value{end+1} = sqbPdiff(dataIndex,screen.short.index{end});

screen.names{end+1} = 'ann - pdiff';
if sum(annPdiff(dataIndex,:))==0
    dataIndex
    error('failed Pdiff eval')
end
screen.long.index{end+1} = getFiltIndices(annPdiff(dataIndex,:),abs(options.test.annPdiff.longThresh),options.test.annPdiff.longSign);
screen.long.value{end+1} = annPdiff(dataIndex,screen.long.index{end});
screen.short.index{end+1} = getFiltIndices(annPdiff(dataIndex,:),abs(options.test.annPdiff.shortThresh),options.test.annPdiff.shortSign);
screen.short.value{end+1} = annPdiff(dataIndex,screen.short.index{end});


screen.names{end+1} = 'price Threshold';

screen.long.index{end+1} = getFiltIndices(data.prices(dataIndex,:),abs(options.test.minValidPrice),1);
screen.short.index{end+1} = getFiltIndices(data.prices(dataIndex,:),abs(options.test.minValidPrice),1);


