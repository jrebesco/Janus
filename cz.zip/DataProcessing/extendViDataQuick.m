% % extendViData
ccc
% load all_dataVI_2
load filt_dataVI_v132
tm = clock;
% mna = [15,22,46,134,215,253,277,343,466,621,663,726,807,824,1082,1216,1228,1342,1358];
mna = [47 190 462 1155 510 794 1035 1387 1851 1932 2160 2648 495 1836 2044 2247 2435 2443 ...
    71 196 365 536 643 900 1110 1435 1556 1998 2451 2561 2681 15 54 449 619 640 1773 1781 2616 ...
    70 109 160 194 200 207 223 225 236 354 415 426 450 464 498 517 535 580 663 764 824 1029 1095 1107 1139 1198 1239 1252 1307 1371 1382 1397 1415 ...
    1444 1502 1505 1620 1639 1746 1756 1788 1815 1903 1923 1935 1953 1979 2032 2038 2054 2110 2162 2266 2294 2310 2393 2471 2544 2573 ...
    42 486 668 783 981 1021 1436 1833 1948 1991 263 284 540 664 753 839 1051 1147 1726 1752 2096 2325 2557 2625 2817 ...
    74 215 1041 1519 1660 1716 1900 2418 2764 27 40 127 159 682 848 1138 1204 1383 1475 1924 2034 2365 2615 332 2708 ...
    199 798 1053 1061 1062 1112 1146 1277 1320 1829 2198 2438 2460 2613 2797 537 801 155 210 261 ...
    282 324 403 650 797 849 853 894 916 1006 1007 1011 1049 1230 1238 1278 1437 1449 1630 1653 1835 ...
    1899 1950 2078 2101 2102 2124 2140 2167 2185 2275 2332 2355 2356 2371 2555 2568 2737 467];

% mna = [2616];
okI = mna(1)-1;

okI = 5;
if datenum(date)==datenum(data.dates{end})
    disp('files current')
elseif (datenum(date)~= datenum(data.dates{end})+1) && (tm(4) < 2)
    disp('early in the day, skipping update')
else
    %% get bblg connection
    c = blp([],[],10000);
    bblgTickers = data.tickers(3,:);
    globalStartDate = data.dates{1};
    startDate = datestr(datenum(data.dates{end})+1,'mm/dd/yyyy')
    endDate = datestr(datenum(date),'mm/dd/yyyy')
    %     endDate = '03/30/2016'
    
    
    %% do px
    [d sec] = history(c,bblgTickers,'PX_LAST',startDate,endDate,'daily');
    
    for i = 1:numel(mna)
        tmp =  d{okI}(:,1);
        tmp2 = repmat(data.prices(end,mna(i)),size(d{okI}(:,2),1),size(d{okI}(:,2),2));
        %         d{mna(i)}(:,1) =  d{okI}(:,1);
        %         d{mna(i)}(:,2) = repmat(data.prices(end,mna(i)),size(d{okI}(:,2),1),size(d{okI}(:,2),2));
        tmp3 = [tmp tmp2];
        d{mna(i)} = tmp3;
    end
    
    for i = 1:numel(d)
        nDays(i) = size(d{i},1);
    end
    
    if sum(abs(diff(nDays)))==0
    else
        error('unequal px days')
    end
    
    for i = 1:numel(d{1}(:,1))
        dateAppend{i} = datestr(d{1}(i,1),'mm/dd/yyyy');
    end
    data.dates(end+1:end+numel(dateAppend)) = dateAppend;
    
    insertIndex = [];
    for i = 1:numel(d)
        insertIndex = [insertIndex find(strcmp(data.tickers(3,:),sec{i}))];
        pxmat(:,find(strcmp(data.tickers(3,:),sec{i}))) = d{i}(:,2);
    end
    data.prices(end+1:end+size(pxmat,1),insertIndex) = pxmat;
    clear nDays dateAppend i insertIndex
    %% do mc
    [d sec] = history(c,bblgTickers,'CUR_MKT_CAP',startDate,endDate,'daily');
    for i = 1:numel(mna)
        tmp =  d{okI}(:,1);
        tmp2 = repmat(data.prices(end,mna(i)),size(d{okI}(:,2),1),size(d{okI}(:,2),2));
        %         d{mna(i)}(:,1) =  d{okI}(:,1);
        %         d{mna(i)}(:,2) = repmat(data.prices(end,mna(i)),size(d{okI}(:,2),1),size(d{okI}(:,2),2));
        tmp3 = [tmp tmp2];
        d{mna(i)} = tmp3;
    end
    
    for i = 1:numel(d)
        nDays(i) = size(d{i},1);
    end
    
    if sum(abs(diff(nDays)))==0
    else
        error('unequal px days')
    end
    
    for i = 1:numel(d{1}(:,1))
        dateAppend{i} = datestr(d{1}(i,1),'mm/dd/yyyy');
    end
    
    %%% check dates
    for i = 1:numel(dateAppend)
        if ~isequal(data.dates{end-numel(dateAppend)+i},dateAppend{i});
            error('date mismatch')
        end
    end
    
    insertIndex = [];
    for i = 1:numel(d)
        insertIndex = [insertIndex find(strcmp(data.tickers(3,:),sec{i}))];
        mcmat(:,find(strcmp(data.tickers(3,:),sec{i}))) = d{i}(:,2);
    end
    data.mcap(end+1:end+size(pxmat,1),insertIndex) = mcmat;
    clear nDays dateAppend i insertIndex mcmat
    %% do BV/PX
    [d sec] = history(c,bblgTickers,'BOOK_VAL_PER_SH',startDate,endDate,'quarterly');
    for i = 1:numel(d)
        numelD(i) = numel(d{i});
    end
    
    if sum(numelD)==0
        nd = size(data.prices,1)-size(data.bookval,1);
        bvupdate = repmat(data.bookval(end,:),nd,1);
        bvupdate = bvupdate.*data.prices(end-nd+1:end,:);
    else
        okI = find(numelD>0);
        okI = okI(1);
        for i = 1:numel(mna)
            d{mna(i)}(:,1) =  d{okI}(:,1);
            d{mna(i)}(:,2) = repmat(data.bookval(end,mna(i)),size(d{okI}(:,2),1),size(d{okI}(:,2),2));
        end
        
        for i = 1:numel(bblgTickers)
            if ~isempty(d{i})
                %             insertInd{i} = d{1}(:,1);
                bval = d{i}(find(d{i}(:,1)==datenum(endDate)),2);
                
            else
                tickerInd = find(strcmp(data.tickers(3,:),bblgTickers{i}));
                bval = data.bookval(end,tickerInd)* data.prices(size(data.bookval,1),tickerInd);
            end
            bvupdate(:,i) = repmat(bval,size(pxmat,1),1);
        end
        
    end
    bvmat = bvupdate./pxmat;
    data.bookval = [data.bookval;bvmat];
    
    %% do all single-elements:
    %% spy
    [d sec] = history(c,'SPY US Equity','PX_LAST',startDate,endDate,'daily');
    %     data.spy = [data.spy;d(:,2)];
    data.spy = d(:,2);
    %% VIX
    [d sec] = history(c,'VIX Index','PX_LAST',startDate,endDate,'daily');
    %     data.vix = [data.vix;d(:,2)];
    data.vix = d(:,2);
    %% gc
    [d sec] = history(c,'GC1 Comdty','PX_LAST',startDate,endDate,'daily');
    %     data.gc = [data.gc;d(:,2)];
    data.gc = d(:,2);
    %% lb
    [d sec] = history(c,'LB1 Comdty','PX_LAST',startDate,endDate,'daily');
    %     data.lb = [data.lb;d(:,2)];
    data.lb = d(:,2);
    
    %% do beta
    [d sec] = history(c,data.tickers(3,:),'BETA_MINUS',startDate,endDate,'daily');
    
    for i = 1:numel(mna)
        tmp =  d{okI}(:,1);
        tmp2 = repmat(data.prices(end,mna(i)),size(d{okI}(:,2),1),size(d{okI}(:,2),2));
        %         d{mna(i)}(:,1) =  d{okI}(:,1);
        %         d{mna(i)}(:,2) = repmat(data.prices(end,mna(i)),size(d{okI}(:,2),1),size(d{okI}(:,2),2));
        tmp3 = [tmp tmp2];
        d{mna(i)} = tmp3;
    end
    
    for i = 1:numel(d)
        tmp(:,i) = d{i}(:,2);
    end
    %
    q = [data.beta;tmp];
    data.beta = q;
    %% PE ratio
    [d sec] = history(c,data.tickers(3,:),'PE_RATIO',startDate,endDate,'daily');
    
    for i = 1:numel(mna)
        tmp =  d{okI}(:,1);
        tmp2 = repmat(data.prices(end,mna(i)),size(d{okI}(:,2),1),size(d{okI}(:,2),2));
        %         d{mna(i)}(:,1) =  d{okI}(:,1);
        %         d{mna(i)}(:,2) = repmat(data.prices(end,mna(i)),size(d{okI}(:,2),1),size(d{okI}(:,2),2));
        tmp3 = [tmp tmp2];
        d{mna(i)} = tmp3;
    end
    
    for i = 1:numel(d)
        tmp(:,i) = d{i}(:,2);
    end
    %
    q = [data.pe;tmp];
    data.pe = q;
    %% vix contango
    [d sec] = history(c,'UX1 Index','PX_LAST',startDate,endDate,'daily');
    [d2 sec] = history(c,'UX6 Index','PX_LAST',startDate,endDate,'daily');
    data.vixCont = d2(:,2)-d(:,2);
    clear d d2 sec
    %% extend non-daily elements QUICK
    dy = repmat(data.divyld(end,:),size(data.dates,1)-size(data.divyld,1),1);
    data.divyld = [data.divyld;dy];
    
    fcf = repmat(data.fcfPS(end,:),size(data.dates,1)-size(data.fcfPS,1),1);
    data.fcfPS = [data.fcfPS;fcf];
    
    cfoa = repmat(data.cfoa(end,:),size(data.dates,1)-size(data.cfoa,1),1);
    data.cfoa = [data.cfoa;cfoa];
    
    roa = repmat(data.roa(end,:),size(data.dates,1)-size(data.roa,1),1);
    data.roa = [data.roa;roa];
    
    gpoa = repmat(data.gpoa(end,:),size(data.dates,1)-size(data.gpoa,1),1);
    data.gpoa = [data.gpoa;gpoa];
    
    grossPPS = repmat(data.grossPPS(end,:),size(data.dates,1)-size(data.grossPPS,1),1);
    data.grossPPS = [data.grossPPS;grossPPS];
    
    validity = repmat(data.validity(end,:),size(data.dates,1)-size(data.validity,1),1);
    data.validity = [data.validity;validity];
    
    close(c)
    clear ans b* c d e* i p* s* t* mna* okI num* q globalStartDate gp cfoa dy fcf gpoa roa validity grossPPS
    %% close connection
    
end

%