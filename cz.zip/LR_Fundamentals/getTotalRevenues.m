function [outMat] = getTotalRevenues(tickers,dateVect)

% ref paper http://papers.ssrn.com/sol3/papers.cfm?abstract_id=2670839
% from http://web.utk.edu/~prdaves/Computerhelp/COMPUSTAT/Compustat_manuals/user_05r.pdf

c = blp([],[],10000);

startDate = datestr(dateVect(1),'mm/dd/yyyy');
endDate = datestr(dateVect(end),'mm/dd/yyyy');

% [outCell sec] = history(c,tickers,'ARD_TOTAL_REVENUES',startDate,endDate,'daily');
[outCell sec] = history(c,tickers,'SALES_REV_TURN',startDate,endDate,'daily');  
%%Not this one atmso
outMat = standardizeBblgOutToDateVect(dateVect,outCell);

close(c)


