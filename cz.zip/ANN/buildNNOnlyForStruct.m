%% global runscript
function [netC,pctCorrect] = buildNNOnlyForStruct(data,fund,options)
%% global options / variables
numPortPerSide = options.test.numPerSide;
numMcmcIterations = 1;

%% load data
% load(options.global.file)

%% final preprocessing of data
% data = dataPreProcessingForNN(data,options);
%% 
for i = 1:numMcmcIterations
    [netC{i},pctCorrect(i)] = runCvtModelForStruct(data,fund,options);
    i
end

save(options.global.netFile)