function [SQBmodel,pdiffC,okIndV,pdiffXV,okIndXV,pqual] = runSQBForStruct(data,options)

%% load data
% load(options.global.file)

%% final preprocessing of data
data = dataPreProcessingForSQB(data,options)
[SQBmodel err] = buildSQBModel(data,options);

%% NBC
[pdiffC, okIndV, pqual] = runSQBModelWrapper(data,options,'options.test.testVect',SQBmodel);

%% XVal

[pdiffXV, okIndXV] = runSQBModelWrapper(data,options,'options.test.XVVect',SQBmodel);

