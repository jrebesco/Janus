ccc
load filt_dataVI_v81

q = data.prices>3;
data.validity = data.validity.*q;
%% search parameters
options.win.fit.pxmomLongT = [0.5 0.7 0.8 0.9];
options.win.fit.pxmomLongD = [0.1 0.2 0.3 0.4];

options.win.fit.pxmomShortT = [0  ];
options.win.fit.pxmomShortD = [0.25];

options.win.fit.bvToPxLongT = [0.5 0.75];
options.win.fit.bvToPxLongD = [0.1 0.25];

options.win.fit.bvToPxShortT = [0 ];
options.win.fit.bvToPxShortD = [0.3];

options.win.fit.mcapT = [0.0 0.1 0.2];
options.win.fit.mcapD = [0.1 0.2 ];

options.win.fit.betaLongT = [0.0 0.1 ];
options.win.fit.betaLongD = [0.1 0.4];

options.win.fit.betaShortT = [0.5 ];
options.win.fit.betaShortD = [0.1 ];

options.win.fit.lambda = 0.5;
options.win.fit.timeLength = 60;
options.win.fit.percentileGranularity = 5;

%% window data
options.win.data{1,1} = 'prices';options.win.data{1,2} = -options.win.fit.timeLength;options.win.data{1,3} = 1;
options.win.data{2,1} = 'mcap';options.win.data{2,2} = 0;options.win.data{2,3} = 1;
options.win.data{3,1} = 'bookval';options.win.data{3,2} = 0;options.nn.data{3,3} = 1;
options.win.data{4,1} = 'beta';options.win.data{4,2} = 0;options.nn.data{4,3} = 1;



%% to merge when merging
options.global.verbose = 0;
totalLongAmt = 100;
totalShortAmt = -100;
annualTrdDays = 250;
weightType = 'uniformCap';
options.win.fit.startVect = [100:100:300];
options.test.feedback.globalStopLoss.isEnabled = 1;
options.test.feedback.globalStopLoss.fractionalLoss = 0.02;
options.test.feedback.globalStopLoss.triggered = 0;
options.test.feedback.individualStopLoss.isEnabled = 0;
options.test.feedback.individualStopLoss.fractionalLoss = 0.5;
options.test.feedback.individualStopLoss.triggered = 0;
options.test.feedback.globalHWLoss.isEnabled = 1;
options.test.feedback.globalHWLoss.fractionalLoss = 0.11;
options.test.feedback.globalHWLoss.triggered = 0;
%% for loops
pnlArray = [];
pnlArrayI = [];
for i = 1:numel(options.win.fit.startVect)
    options.win.fit.startVect(i)
    [datam,result,okInd] = assembleData(data,options.win.data,options.win.fit.startVect(i),options.win.fit.timeLength,1,options.win.fit.percentileGranularity,0,1,1);
    for mclongMinI = 1:numel(options.win.fit.mcapT)
        for mclongDelI = 1:numel(options.win.fit.mcapD)
            
            for plongMinI = 1:numel(options.win.fit.pxmomLongT)
                for plongDelI = 1:numel(options.win.fit.pxmomLongD)
                    
                    for bvlongMinI = 1:numel(options.win.fit.bvToPxLongT)
                        for bvlongDelI = 1:numel(options.win.fit.bvToPxLongD)
                            
                            for betalongMinI = 1:numel(options.win.fit.betaLongT)
                                for betalongDelI = 1:numel(options.win.fit.betaLongD)
                                    
    for mcshortMinI = 1:numel(options.win.fit.mcapT)
        for mcshortDelI = 1:numel(options.win.fit.mcapD)
            
            for pshortMinI = 1:numel(options.win.fit.pxmomShortT)
                for pshortDelI = 1:numel(options.win.fit.pxmomShortD)
                    
                    for bvshortMinI = 1:numel(options.win.fit.bvToPxShortT)
                        for bvshortDelI = 1:numel(options.win.fit.bvToPxShortD)
                            
                            for betashortMinI = 1:numel(options.win.fit.betaShortT)
                                for betashortDelI = 1:numel(options.win.fit.betaShortD)
                                  
                                   model.finalPnl = 100*randn(1,1);
                                   
                                    pnlArrayI = [pnlArrayI; [model.finalPnl, i,mclongMinI,mclongDelI,plongMinI,plongDelI,bvlongMinI,bvlongDelI,betalongMinI,betalongDelI,mcshortMinI,mcshortDelI,pshortMinI,pshortDelI,bvshortMinI,bvshortDelI,betashortMinI,betashortDelI]];
                                    pnlArray = [pnlArray; [model.finalPnl, i,options.win.fit.mcapT(mclongMinI),options.win.fit.mcapD(mclongDelI),...
                                        options.win.fit.pxmomLongT(plongMinI),options.win.fit.pxmomLongD(plongDelI),...
                                        options.win.fit.bvToPxLongT(bvlongMinI),options.win.fit.bvToPxLongD(bvlongDelI),...
                                        options.win.fit.betaLongT(betalongMinI),options.win.fit.betaLongD(betalongDelI),...
                                        options.win.fit.mcapT(mcshortMinI),options.win.fit.mcapD(mcshortDelI),...
                                        options.win.fit.pxmomShortT(pshortMinI),options.win.fit.pxmomShortD(pshortDelI),...
                                        options.win.fit.bvToPxShortT(bvshortMinI),options.win.fit.bvToPxShortD(bvshortDelI),...
                                        options.win.fit.betaShortT(betashortMinI),options.win.fit.betaShortD(betashortDelI)]];
                                    

                                end
                            end
                        end
                    end
                end
            end
        end
    end
end
                                end
                            end
                        end
                    end
                end
            end
        end
    end

%% build kalmanster

for i = 1:numel(options.win.fit.startVect)
    tIndex = find(pnlArray(:,2)==i);
    [pnlMax pnlMaxSubInd] = max(pnlArray(tIndex,1));
    pnlMaxInd = tIndex(pnlMaxSubInd);
    pnlMaxConfig(i,:) = pnlArray(pnlMaxInd,3:end);
    
    if i > 1
        kalmanIndexConfig(i,:) = kalmanIndexConfig(i-1,:).*(1-options.win.fit.lambda) + options.win.fit.lambda.*pnlMaxConfig(i,:);
    else
       kalmanIndexConfig(i,:) = pnlMaxConfig(i,:);
    end
end