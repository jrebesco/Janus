function [ic] = getIncomeBeforeXoAdjCStockEquiv(tickers,dateVect)

% ref paper http://papers.ssrn.com/sol3/papers.cfm?abstract_id=2670839
% from http://web.utk.edu/~prdaves/Computerhelp/COMPUSTAT/Compustat_manuals/user_05r.pdf
% Income Before Extraordinary Items � Adjusted for Common Stock
% Equivalents � Dollar Savings
% Annual data item number 20
% Quarterly data item number 10
% Units (companies) Millions of dollars
% Annual data availability 1950
% Quarterly data availability First quarter, 1966
% Annual position number on Daily
% Fundamental File
% 80
% Quarterly position number on Daily
% Fundamental File
% 156
% This item represents net income after preferred dividend requirements and adjusted for any dollar
% savings due to common stock equivalents but before extraordinary items and discontinued operations
% as outlined in Accounting Principles Board Opinion No. 15.
% The adjustments for dollar savings due to common stock equivalents include:
% 1. Interest (after application of the tax rate) saved from retirement of debt or earned from
% investments made with the proceeds from conversion of options and warrants identified as
% common stock equivalents
% 2. Interest expense (after application of the tax rate) paid on convertible debt identified as
% common stock equivalents
% 3. Preferred dividends on convertible preferred stock identified as common stock equivalents
%%%%%%%%%%%%%%%%%
% Quarterly This item, on a preliminary basis, may be obtained by multiplying per-share earnings as reported by
% the number of shares as reported (which may be average shares).
%%%%%%%%%%%%%%%%%
% Annual footnote code
% BZ Includes effect of conversion of preferred stock and/or convertible
% debt
% Quarterly footnote code
% BZ Includes effect of conversion of preferred stock and/or convertible
% debt

c = blp([],[],10000);

startDate = datestr(dateVect(1),'mm/dd/yyyy');
endDate = datestr(dateVect(end),'mm/dd/yyyy');

[earn sec] = history(c,tickers,'IS_EPS',startDate,endDate,'daily');
earnMat = standardizeBblgOutToDateVect(dateVect,earn);


[totShares sec] = history(c,tickers,'EQY_SH_OUT',startDate,endDate,'daily');
tsoMat =  standardizeBblgOutToDateVect(dateVect,totShares);

close(c)
ic = earnMat.*tsoMat;