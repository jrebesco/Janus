%%
ccc
if ~exist('allRegDataZ.mat','file')
    load filt_dataVI_v135
    tickersAll = data.tickers;
    clear data
    %% gen fun data
    tickerList = tickersAll(3,:);
    junkList = [];
    suspectList = [];
    % junkList = [4 12 15 19 22 42];
    tickerList = tickerList(setdiff(1:1:numel(tickerList),junkList));
    startDate = '12/29/2015';
    endDate = '12/31/2016';
    dateVect = getAllTradeDateVect(startDate,endDate);
    load tmpgf
    
    1
    fund.incCSEAdj = getIncomeBeforeXoAdjCStockEquiv(tickerList,dateVect);
    [i j] = find(isnan(incCSEAdj));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    2
    fund.incBFXoAfC = getIncomeBeforeXoAvailForComm(tickerList,dateVect);
    [i j] = find(isnan(incBFXoAfC));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    3
    fund.incBfXoItems = getIncomeBeforeXoItems(tickerList,dateVect);
    [i j] = find(isnan(incBfXoItems));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    4
    fund.assets = getTotalAssets(tickerList,dateVect);
    [i j] = find(isnan(assets));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    5
    fund.divPaid = getDividends(tickerList,dateVect);
    [i j] = find(isnan(divPaid));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    6
    fund.netIncome = getNetIncome(tickerList,dateVect);
    [i j] = find(isnan(netIncome));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    7
    fund.stockHEq = getStockholdEq(tickerList,dateVect);
    [i j] = find(isnan(stockHEq));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    8
    fund.totRev = getTotalRevenues(tickerList,dateVect);
    [i j] = find(isnan(totRev));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    9
    fund.salesTurn = getSalesTurnoverNet(tickerList,dateVect);
    [i j] = find(isnan(salesTurn));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    10
    fund.ppe = getPropPlantEquip(tickerList,dateVect);
    [i j] = find(isnan(ppe));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    11
    fund.ltDebt = getLtDebt(tickerList,dateVect);
    [i j] = find(isnan(ltDebt));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    12
    fund.disOps = getDisconOps(tickerList,dateVect);
    [i j] = find(isnan(disOps));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    13
    fund.totLiab = getTotLiab(tickerList,dateVect);
    [i j] = find(isnan(totLiab));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    14
    fund.curLiab = getCurLiab(tickerList,dateVect);
    [i j] = find(isnan(curLiab));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    15
    fund.curAssets = getCurAsset(tickerList,dateVect);
    [i j] = find(isnan(curAssets));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    16
    fund.nonCurAssets = getNonCurAsset(tickerList,dateVect);
    [i j] = find(isnan(nonCurAssets));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    17
    fund.ptxIncome = getPretaxIncome(tickerList,dateVect);
    [i j] = find(isnan(ptxIncome));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    18
    fund.incTax = getTotalIncomeTax(tickerList,dateVect);
    [i j] = find(isnan(incTax));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    
    19
    fund.othAssetTot = getOtherAssetsTotal(tickerList,dateVect);
    [i j] = find(isnan(othAssetTot));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    
    20
    fund.liabAndStockhEqt = getLiabilitiesAndStockholderEquity(tickerList,dateVect);
    [i j] = find(isnan(liabAndStockhEqt));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    
    21
    fund.commOrdEqyTot = getCommonOrdEquityTot(tickerList,dateVect);
    [i j] = find(isnan(commOrdEqyTot));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    
    22
    fund.prefStock = getPreferredStock(tickerList,dateVect);
    [i j] = find(isnan(prefStock));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    
    23
%     nonOpInc = getNonOperInc(tickerList,dateVect);
%     [i j] = find(isnan(nonOpInc));
%     suspectList = [suspectList unique(j)'];
%     save tmpgf
    
    24
    fund.xoItems = getXoItems(tickerList,dateVect);
    [i j] = find(isnan(xoItems));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    
    25
    fund.othLiab = getOtherLiabs(tickerList,dateVect);
    [i j] = find(isnan(othLiab));
    suspectList = [suspectList unique(j)'];
    save tmpgf
    
    suspectList = unique(suspectList);
    cleanList = setdiff(1:1:numel(tickerList),suspectList);
    %%
    fund.mktCap = getMarketCap(tickerList,dateVect);
%     [fund.prices validity] = getPricesAndValidity(tickerList(cleanList),dateVect);
%     [fund.shares validSh] = getTSO(tickerList(cleanList),dateVect);
else
    load allRegData
end

% % % %% windsorize!
% % % %% regress!
% % % for t= 1:size(mktCap,1)
% % %     tickerFitMat = [incCSEAdj(t,cleanList);incBFXoAfC(t,cleanList);incBfXoItems(t,cleanList);assets(t,cleanList); ...
% % %         divPaid(t,cleanList); netIncome(t,cleanList); stockHEq(t,cleanList); totRev(t,cleanList); salesTurn(t,cleanList); ...
% % %         ltDebt(t,cleanList); disOps(t,cleanList); totLiab(t,cleanList); curLiab(t,cleanList); curAssets(t,cleanList); ...
% % %         ptxIncome(t,cleanList); incTax(t,cleanList); liabAndStockhEqt(t,cleanList); commOrdEqyTot(t,cleanList); ...
% % %         prefStock(t,cleanList); xoItems(t,cleanList); othLiab(t,cleanList)];
% % %     
% % %     
% % %     normWrtAssets = tickerFitMat./repmat(assets(t,cleanList),size(tickerFitMat,1),1);
% % %     bounds = prctile(normWrtAssets,[5 95],2);
% % %     
% % %     for z = 1:size(bounds,1)
% % %         if ((bounds(z,1)==1) && (bounds(z,2)==1))
% % %         else
% % %             normWrtAssets(z,find(normWrtAssets(z,:)<bounds(z,1))) = bounds(z,1);
% % %             normWrtAssets(z,find(normWrtAssets(z,:)>bounds(z,2))) = bounds(z,2);
% % %         end
% % %     end
% % %     tickerFitWin = normWrtAssets.*repmat(assets(t,cleanList),size(tickerFitMat,1),1);
% % %     
% % %     
% % %     
% % %     mcapMat = mktCap(t,cleanList);
% % %     fitMat = [tickerFitWin;ones(1,size(tickerFitWin,2))];
% % %     [b bint r rint stats] = regress(mcapMat',fitMat');
% % %     regCoef(:,t) = b;
% % %     regResid(:,t) = r;
% % %     regResidFrac(:,t) = regResid(:,t)./mcapMat';
% % %     regR(t) = stats(1);
% % %     
% % % end
% % % 
% % % for t = 1:size(mktCap,1)-20
% % %     pxd(:,t) = (prices(t+20,:)-prices(t,:))./prices(t,:);
% % %     pxd(find(isnan(pxd)))=0;
% % %     ct(t) = corr(regResidFrac(:,t),pxd(:,t));
% % %     % wuartiles
% % %     qtiles = prctile(regResidFrac(:,t),[20 80]);
% % %     b = find(regResidFrac(:,t)<qtiles(1));
% % %     pnlBC{:,t} =  (prices(t+20,b)-prices(t,b))./prices(t,b);
% % %     pnlBC{:,t}(find(isnan(pnlBC{:,t}))) = 0;
% % %     tp = find(regResidFrac(:,t)>qtiles(2));
% % %     pnlTC{:,t} =  (prices(t+20,tp)-prices(t,tp))./prices(t,tp);
% % %     pnlTC{:,t}(find(isnan(pnlTC{:,t}))) = 0;
% % %     netPnLB(t) = sum(pnlBC{:,t});
% % %     netPnLT(t) = -sum(pnlTC{:,t});
% % %     netPnlA(t) = netPnLB(t) +   netPnLT(t);
% % % end

