function  [fill, okInd] = baseEvalSingleElementForDataMWOkInd(data,dataField,delta,usePct,startVect,okInd,pctileGranularity,useZscore,makeDiscrete,makeNormalized,useAC,useDeltaTick,useDMA)
% if delta==-90
%     disp('dbg')
% end
% if strcmp(dataField,'fcfPS')
%    disp('pause') 
% end

if ~exist('useDMA','var')
    useDMA=0;
end
fill = [];
% okInd = find(data.validity(startVect(1),:));

if delta ~=0
%     okInd2 = find(data.validity(startVect(1)+delta,:));
%     okInd = intersect(okInd,okInd2);
end
if size(eval(['data.' dataField]),2)==1
    uniVar=1;
else
    uniVar=0;
end

if useDeltaTick
    for i = 1:numel(startVect)
%         okInd = find(data.validity(startVect(i),:));
        
        init = eval(['data.' dataField '(startVect(i)+delta:startVect(i),okInd)']);
        disDiff = diff(init)>0;
        iFill = sum(disDiff)./size(disDiff,1);
        fill = [fill iFill];
    end
    if makeDiscrete
        [~,fillT] = histc(fill,0:pctileGranularity./100:1);
        fillT2 = fillT./(max(floor(100./pctileGranularity),max(fillT)));
        fill = fillT2;
    end
    
else
    if useZscore+makeDiscrete
        if useAC
            final = eval(['data.' dataField '(1-delta:end,okInd)']);
            init = eval(['data.' dataField '(1:end+delta,okInd)']);
            tmpM = (final - init) ./ init;
            tmpM = tmpM(1:-delta:size(tmpM,1),:);
            for z = 1:size(tmpM,2)
                allFill(z) = acf(tmpM(:,z),1);
            end
            allFill = [allFill(:);min(allFill(:))*5.3;max(allFill(:))*5.3];
        elseif delta == 0
            allFill = eval(['data.' dataField '(:);']);
        elseif useDMA
            %             wts = [-1/delta/2;repmat(-1/delta,-delta-1,1);-1/delta/2];
            final = eval(['data.' dataField '(1:end,okInd)']);
            init = movmean(final,[-delta,0]);
            tmpM = (final - init) ./ init;
            allFill = tmpM(:);
        elseif uniVar
            final = eval(['data.' dataField '(1-delta:end)']);
            init = eval(['data.' dataField '(1:end+delta)']);
            tmpM = (final - init) ./ init;
            allFill = tmpM(:);
        else
            dataField
            delta
            final = eval(['data.' dataField '(1-delta:end,okInd)']);
            init = eval(['data.' dataField '(1:end+delta,okInd)']);
            tmpM = (final - init) ./ init;
            if strcmp(dataField,'insOwn')
                tmpM(find(isnan(tmpM)))=0;
            end
            allFill = tmpM(:);
        end
    end
    
    if useZscore+makeDiscrete
        if useZscore
            pct.useZscore = 1;
            [foo zscore.mu zscore.sigma] = zscore(allFill);
        else
            pct.useZscore = 0;
            pctField =  prctile(allFill,[0:pctileGranularity:100]);
        end
    end
    
    for i = 1:numel(startVect)
%         okInd = find(data.validity(startVect(i),:));
        if delta ~=0
            % okInd2 = find(data.validity(startVect(i)+delta,:));
            % okInd =intersect(okInd,okInd2);
        end
        
        if useAC
            init = eval(['data.' dataField '(startVect(i)-200:-delta:startVect(i)+delta,okInd)']);
            final = eval(['data.' dataField '(startVect(i)-200-delta:-delta:startVect(i),okInd)']);
            df = (final-init)./init;
            for z = 1:size(df,2);
                sf(z) = acf(df(:,z),1);
                if isnan(sf(z))
                    sf(z) = 0;
                end
            end
            fill = [fill sf];
            clear sf init final df z
            
        else
            if size(eval(['data.' dataField]),2)==1
                fill = [fill repmat(eval(['data.' dataField '(startVect(i)+delta)']),1,numel(okInd))];
            else
                
                if delta == 0
                    if strcmp(dataField,'fcfPS') 
                        if i == 20
                        i
                        end
                    end
                    fill = [fill eval(['data.' dataField '(startVect(i),okInd)'])];
                else
                    if delta<0
                        final = eval(['data.' dataField '(startVect(i),okInd)']);
                        if useDMA
                            init = mean(eval(['data.' dataField '(startVect(i)+delta:startVect(i)-1,okInd)']));
                        else
                            init = eval(['data.' dataField '(startVect(i)+delta,okInd)']);
                        end
                    else
                        final = eval(['data.' dataField '(startVect(i)+delta,okInd)']);
                        init = eval(['data.' dataField '(startVect(i),okInd)']);
                    end
                    if usePct
                        tizzemp = (final-init)./init;
                        if numel(find(isnan(tizzemp)))>0
                            warning('nans here stop')
                        end
                        if numel(find(isinf(tizzemp)))>0
                            warning('infs here stop')
                        end
                        fill = [fill (final-init)./init];
                        
                        
                    else
                        fill = [fill (final-init)];
                    end
                    if strcmp(dataField,'insOwn')
                        fill(find(isnan(fill)))=0;
                    end
                end
            end
        end
        if ~isempty(find(isnan(fill)))
            disp(['stop here for nan evaluating ' dataField ' in baseEvalSingleElementForDataMWOkInd'])
        end
    end
    
    %% package scores
    if size(eval(['data.' dataField]),2)~=1
        if useZscore
            fill = (fill-zscore.mu)./ zscore.sigma;
        else
            if makeDiscrete
                dataField
               if  delta == -90
                   disp('-90')
               end
                fill = (discretize(fill,pctField));
            end
            
            if makeNormalized
                fill = (fill - min(fill))./(max(fill)-min(fill));
                
            end
        end
    end
end
if ~isempty(find(isnan(fill)))
      disp(['Warning! NaN values found evaluating ' dataField ' in baseEvalSingleElementForDataMWOkInd'])
end