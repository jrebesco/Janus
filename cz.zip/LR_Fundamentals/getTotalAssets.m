function assets = getTotalAssets(tickers,dateVect)


% ref paper http://papers.ssrn.com/sol3/papers.cfm?abstract_id=2670839
% from http://web.utk.edu/~prdaves/Computerhelp/COMPUSTAT/Compustat_manuals/user_05r.pdf
% Identifiable/Total Assets (COMPUSTAT Business Information Files)
% Variable data item (Business
% Information � Segment Item Value
% File)
% AT
% Units Code
% Position number for Business
% Information � Segment Item Value File
% 14
% This item represents the total assets/liabilities of a company at a point in time. If the company does
% not report a useable amount, this data item will be left blank.
%%%%%%% Implemented as the BBLG field 'BS_TOT_ASSET'




c = blp([],[],10000);

startDate = datestr(dateVect(1),'mm/dd/yyyy');
endDate = datestr(dateVect(end),'mm/dd/yyyy');

for z = 1:numel(tickers)
[bsta{z} sec] = history(c,tickers(z),'BS_TOT_ASSET',startDate,endDate,'daily');
end

assets = standardizeBblgOutToDateVect(dateVect,bsta);