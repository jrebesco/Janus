function indices = getFiltIndices(data,percentile,greaterThanFlag)
if isempty(percentile)
disp('pause')
end
if  ~isvector(percentile) || numel(percentile) == 0 || any(percentile < 0 | percentile > 100) || ~isreal(percentile)
    disp('pause')
end

qtiles = prctile(data,[percentile]);
if greaterThanFlag == 1
    indices = find(data>=qtiles(1));
else
    indices = find(data<=qtiles(1));
end