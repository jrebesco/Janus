function rv = getMarketRealizedDailyVol(data,lookback)
rv = [];
c = blp([],[],10000);

startDate = datestr(datenum(data.dates(1)) - round(lookback/220*365) - 30,'mm/dd/yyyy');
endDate = data.dates(end);

[d sec] = history(c,'SPXT Index','PX_LAST',startDate,endDate,'daily');

startInd = find(d(:,1)==datenum(data.dates(1)));

if ~isempty(startInd)
    for i = 1:numel(data.dates)
        index = find(d(:,1)==datenum(data.dates(i)));
        mseg = d(index-lookback+1:index,2);
        diffM = diff(mseg)./mseg(1:end-1);
        rv = [rv std(diffM)];
    end
    %     for i = startInd:size(d,1);
    %         mseg = d(i-lookback+1:i,2);
    %         diffM = diff(mseg)./mseg(1:end-1);
    %         rv = [rv std(diffM)];
    %     end
    
else
    error('bear indicator and datastructure dates are not aligned on start')
end
rv = rv';