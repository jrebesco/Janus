% tmp clean
ccc
load all_dataVI_v6

badInd = [2028];
goodInd = setdiff(1:1:2831,badInd);


data.tickers=data.tickers(:,goodInd);
data.prices=data.prices(:,goodInd);
data.mcap=data.mcap(:,goodInd);
data.beta=data.beta(:,goodInd);
data.bookval=data.bookval(:,goodInd);
data.grossPPS=data.grossPPS(:,goodInd);
data.divyld=data.divyld(:,goodInd);