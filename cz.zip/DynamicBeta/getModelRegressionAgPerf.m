function [regressCoef, alignIndices] = getModelRegressionAgPerf(data,options,modelArray)
% GETMODELREGRESSIONAGPERF regresses model performance (daily return)
% against the bear market and volatility indicators described in <PAPER>.
% Inputs:
% data - datastruct.  The required fields are data.marketRealizedVol and
% data.bearIndicator.
% options - optionstruct.  Passthrough to generateDailyReturn.
% modelArray - cell array, 1xoptions.test.testDates, of model output
% structures.  Passed to generateDailyReturn 
% Outputs:
% regressCoef - 1x4 set of regression coefficents ag.
%%%%%%
% Version History
% 03 Mar 2017 - v1.1 - Exposed alignIndices
% 02 Mar 2017 - v1.0 - seperated into distinct function.


dailyReturn = generateDailyReturn(modelArray,options);
alignIndices = [];

% for mi = 1:numel(modelArray); perf(mi)= modelArray{mi}.finalPnl./modelArray{mi}.initialNetLiq; end
for mi = 1:numel(modelArray);alignIndices = [alignIndices modelArray{mi}.timeIndex];end
alignVol = data.marketRealizedVol(alignIndices);
alignBear = data.bearIndicator(alignIndices);
regressM = [ones(size(alignBear)) alignBear alignVol.^2 alignBear.*alignVol];
regressCoef = regress(dailyReturn',regressM);