%% buildPartialDataForPortfolioLoading
ccc

startDate = '10/01/2015';
endDate = '02/31/2018';

%%
buildFullDataForStrMod;

clear ans bs_tot_assets bvpx c cleanlist junkList okInd suspectList ticker* valid*

save newRunData

%% get fitted model
load simAnnealOptFilt13.mat
% load xxx
% load run_01012017 
%% reclean JIC
data = cleanPriceGaps(data);
data = cleanBetaGaps(data);
data = cleanBVGaps(data);
data = cleanEbGaps(data);

%% generate misPxing
fund.dates = data.dates;
for t = 1:numel(fund.dates)
   [msxP(t,:),gnX] = calcMispricing(fund,t);
end
msxP(find(isnan(msxP)))=0;
data.misPx = msxP;

%% run through SQB
options.finalOutputIndex = numel(data.dates);
[sqbPC, okIndV] = runSQBModelWrapper(data,options,'options.finalOutputIndex',SQBmodel,1);
sqbPdiff = zeros(1,size(data.tickers,2));
sqbPdiff(okIndV{1})=sqbPC{1};
options.global.buildNets = 0;
options.global.netFile = 'annTmp.mat';
netC = annModel;
save('annTmp.mat','netC')
options.test.testVect = options.finalOutputIndex;
[netC,pctCorrect,pdiffANN,pdiffANNXV,pscore] = runANNForStruct(data,fund,options,1,netC);
annPdiff = pdiffANN{1};

% [rbcPdiff] = evaluateRBCforStructTrade(data,options,rbcModel);

pdmat = zeros(numel(data.dates),numel(annPdiff));
pdmat(end,:) = sqbPdiff;
pdiffStr.data{1} = pdmat;
pdiffStr.label{1} = 'SQB';
pdmat = zeros(numel(data.dates),numel(annPdiff));
pdmat(end,:) = annPdiff;
pdiffStr.data{2} = pdmat;
pdiffStr.label{2} = 'ANN';
bfitOptions.finalBetaAdj = 0;
[finalWeights,eligLongs,eligShorts] = genFinalOutputStructuredModel_v2(bfitOptions,data,fund,dateVect,pdiffStr);
finalInd = [eligLongs eligShorts];
prepForTrade(data,finalWeights,finalInd,bfitOptions)