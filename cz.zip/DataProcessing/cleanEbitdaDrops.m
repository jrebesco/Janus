%% cleanEBITDAdrops

function [data,fund] = cleanEbitdaDrops(data,fund,inValidate)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%FUNCTION cleanEbitdaDrops
%   Inputs
%   data
%   inValidate = if true, data.ebitdaMcRat nans will set data.validity to 0
% Outputs
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Changelog
% v1.0 - 2 Feb 2017 - Wrote function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% open bllg
c = blp([],[],10000);
%% find nans in ebitdamcrat
nanIndex = find(isnan(data.ebitdaMcRat));
areValidIndex = find(data.validity);
suspIndices = intersect(nanIndex,areValidIndex);

if inValidate
    data.validity(suspIndices)=0;
else
    disp('complete clean not presently supported in cleanEbitdaDrops!!!!!!!')
    
    
    [suspDates suspTicks] = ind2sub(size(data.validity),suspIndices);
    
    initTickers = unique(suspTicks);
    
    for i = 1:numel(initTickers)
        dates4Ticker = suspDates(find(suspTicks==initTickers(i)));
        [outCell sec] = history(c,data.tickers(3,initTickers(i)),'EBITDA',data.dates{dates4Ticker(1)},data.dates{dates4Ticker(end)},'daily');
        if isempty(outCell)
        else
            qwz= 4;
        end
    end
end
% unique(suspDates)
