% reestablish data validity
% ccc
% load filt_dataVI_v8
function data = dataValidity(data)

for i = 1:size(data.prices,2)
    dp = diff(data.prices(:,i));
    dpind = find(dp);
    if isempty(dpind)
        data.validity(:,i) = zeros(size(data.prices(:,1)));
    else
        first = dpind(1);
        valFact = ones(size(data.prices(:,i)));
        if first > 2
            valFact(1:first) = 0;
        end
        endV = dpind(end)+1;
        
        if endV < numel(valFact)
           valFact(endV:end) = 0; 
        end
        data.validity(:,i) = valFact;
    end
end
% tso = appendNewField('filt_dataVI_v8','EQY_SH_OUT');
%
c = blp([],[],10000);

bblgTickers = data.tickers(3,:);
d = getbulkdata(c,bblgTickers,'EQY_INIT_PO_DT');
%
dp = d.EQY_INIT_PO_DT;
dn = datenum(data.dates);
for i = 1:numel(dp)
    if isnan(dp(i))
        dp(i)=1;
    end
    preipo = find(dn<dp(i));
    if ~isempty(preipo);
        lastpre = preipo(end);
        data.validity(1:lastpre,i)=0;
    end
end
close(c)
clear preipo lastpre i dn dp d bblg* ans c dp* first i val*

% for i = 1:size(data.tickers,2)
%
% end
