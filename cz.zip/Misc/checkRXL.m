ccc;
load run20160530_sector
load filt_dataVI_v81
[rx rxs] = importRX('C:\Users\jrebesco\Desktop\MixtureOfExperts\rx_list.csv')
for i = 1:numel(finalTestFilter)
    name = data.tickers(1,finalTestFilter(i))
%     strcmp
end