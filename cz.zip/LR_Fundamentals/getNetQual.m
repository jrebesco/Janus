function netQual = getNetQual(pscore)

for i = 1:numel(pscore)
    netQual(i) = mean(pscore{i});
end