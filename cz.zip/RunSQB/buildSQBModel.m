function [model, err] = buildSQBModel(data,options)


%% build data for model fitting
%%% for rec. bayes hacky version (equalizing data in all groups)
[datamSQB,resultSQB,okInd] = assembleData(data,options.bc.dataSQB,options.bc.fit.startVect,options.bc.fit.timeLength,0,options.bc.fit.percentileGranularity,options.bc.fit.useZscore,options.bc.fit.discrete,options.bc.fit.normalize,1);
[datamSQB, resultSQB, resultLabelSQB] = processResultForRNBC(datamSQB,resultSQB,options.bc.fit.pxDeltaBinThresh,0);
resultLabelSQB = sign(resultLabelSQB);

% nSamp = size(datamSQB,2)
% nTrain = round(nSamp*3/4)
trainX = datamSQB(:,1:2:end)';
% trainY = resultLabelSQB(1:2:end)';
trainY = resultSQB(1:2:end)';
testX = datamSQB(:,2:2:end)';
% testY = resultLabelSQB(2:2:end)';
testY = resultSQB(2:2:end)';


opts = [];
opts.loss = 'logloss'; % can be logloss or exploss
% opts.loss = 'squaredloss'; % can be logloss or exploss
% gradient boost options
opts.shrinkageFactor = 0.05;
opts.subsamplingFactor = 0.5;
opts.maxTreeDepth = uint32(8);  % this was the default before customization
opts.randSeed = uint32(rand()*1000);

numIters = 1600;
tic;
model = SQBMatrixTrain(single(trainX), trainY, uint32(numIters), opts);
toc

pred = SQBMatrixPredict( model, single(testX) );

err = sum( (pred > 0) ~= (testY > 0))/length(pred)
