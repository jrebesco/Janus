function data = cleanEbGaps(data)
%
tic;
for i = 1:size(data.tickers,2)
    
    bv = data.ebitdaMcRat(:,i);
    nanBV = find(isnan(bv));
    zeroBV = find(bv==0);
    infBV = find(isinf(bv));
    fixers = unique(union(union(nanBV,zeroBV),infBV));
    
    if ~isempty(fixers)
        for j = 1:numel(fixers)
            fixInd = fixers(j);
            if fixInd == 1
                goodAnchor = min(setdiff(2:1:size(data.ebitdaMcRat,1),fixers));
            elseif fixInd == size(data.ebitdaMcRat,1)
                goodAnchor = max(setdiff(1:1:fixInd-1,fixers));
            else
                goodAnchor = max(setdiff(1:1:fixInd-1,fixers));
            end
%             [i goodAnchor fixInd]
            if isempty(goodAnchor)
                data.validity(:,i) = 0;
                j = numel(fixers);
            else
                ebitdaMcRatToUse = bv(goodAnchor);
                data.ebitdaMcRat(fixInd,i) = ebitdaMcRatToUse;
            end
        end
    end
end
toc;


%% check for 7-day
px1 = data.ebitdaMcRat(2:end-8,:);
px2 = data.ebitdaMcRat(3:end-7,:);
px3 = data.ebitdaMcRat(4:end-6,:);
px4 = data.ebitdaMcRat(5:end-5,:);
px5 = data.ebitdaMcRat(6:end-4,:);
px6 = data.ebitdaMcRat(7:end-3,:);
px7 = data.ebitdaMcRat(8:end-2,:);

lead = data.ebitdaMcRat(1:end-9,:);

zZs = intersect(intersect(find(px1==0),find(px2==0)),intersect(find(px3==0),find(px4==0)));
zZ2 = intersect(intersect(find(px5==0),find(px6==0)),find(px7==0));
zZs = intersect(zZs,zZ2);

zeroM = zeros(size(px1,1),size(px1,2));
zeroM(zZs) = 1;
replacePx = zeroM.*lead;
data.ebitdaMcRat(2:end-8,:) = data.ebitdaMcRat(2:end-8,:) + replacePx;

%% check for 6-day
px1 = data.ebitdaMcRat(2:end-7,:);
px2 = data.ebitdaMcRat(3:end-6,:);
px3 = data.ebitdaMcRat(4:end-5,:);
px4 = data.ebitdaMcRat(5:end-4,:);
px5 = data.ebitdaMcRat(6:end-3,:);
px6 = data.ebitdaMcRat(7:end-2,:);

lead = data.ebitdaMcRat(1:end-8,:);

zZs = intersect(intersect(find(px1==0),find(px2==0)),intersect(find(px3==0),find(px4==0)));
zZ2 = intersect(find(px5==0),find(px6==0));
zZs = intersect(zZs,zZ2);

zeroM = zeros(size(px1,1),size(px1,2));
zeroM(zZs) = 1;
replacePx = zeroM.*lead;
data.ebitdaMcRat(2:end-7,:) = data.ebitdaMcRat(2:end-7,:) + replacePx;


%% check for 5-day null ebitdaMcRat and amend
px1 = data.ebitdaMcRat(2:end-6,:);
px2 = data.ebitdaMcRat(3:end-5,:);
px3 = data.ebitdaMcRat(4:end-4,:);
px4 = data.ebitdaMcRat(5:end-3,:);
px5 = data.ebitdaMcRat(6:end-2,:);
lead = data.ebitdaMcRat(1:end-7,:);

zZs = intersect(intersect(find(px1==0),find(px2==0)),intersect(find(px3==0),find(px4==0)));
zZs = intersect(zZs,find(px5==0));

zeroM = zeros(size(px1,1),size(px1,2));
zeroM(zZs) = 1;
replacePx = zeroM.*lead;
data.ebitdaMcRat(2:end-6,:) = data.ebitdaMcRat(2:end-6,:) + replacePx;


%% check for 4-day null ebitdaMcRat and amend

px1 = data.ebitdaMcRat(2:end-5,:);
px2 = data.ebitdaMcRat(3:end-4,:);
px3 = data.ebitdaMcRat(4:end-3,:);
px4 = data.ebitdaMcRat(5:end-2,:);
lead = data.ebitdaMcRat(1:end-6,:);

zZs = intersect(intersect(find(px1==0),find(px2==0)),intersect(find(px3==0),find(px4==0)));
zeroM = zeros(size(px1,1),size(px1,2));
zeroM(zZs) = 1;
replacePx = zeroM.*lead;
data.ebitdaMcRat(2:end-5,:) = data.ebitdaMcRat(2:end-5,:) + replacePx;


%% check for three-day null ebitdaMcRat and amend

px1 = data.ebitdaMcRat(2:end-4,:);
px2 = data.ebitdaMcRat(3:end-3,:);
px3 = data.ebitdaMcRat(4:end-2,:);
lead = data.ebitdaMcRat(1:end-5,:);

zZs = intersect(intersect(find(px1==0),find(px2==0)),find(px3==0));
zeroM = zeros(size(px1,1),size(px1,2));
zeroM(zZs) = 1;
replacePx = zeroM.*lead;
data.ebitdaMcRat(2:end-4,:) = data.ebitdaMcRat(2:end-4,:) + replacePx;

%% check for two-day null ebitdaMcRat and amend

px1  = data.ebitdaMcRat(2:end-2,:);
px2 = data.ebitdaMcRat(3:end-1,:);

lead = data.ebitdaMcRat(4:end,:);
lag = data.ebitdaMcRat(1:end-3,:);

zeroZZ = intersect(find(px1==0),find(px2==0));
leadAtZ = lead(zeroZZ);
lagAtZ = lag(zeroZZ);
brackets = find(leadAtZ.*lagAtZ);
px1(zeroZZ(brackets))=lag(zeroZZ(brackets));

data.ebitdaMcRat(2:end-2,:)=px1;

%% check for one-day null ebitdaMcRat and amend; should catch by induction two day gaps

px = data.ebitdaMcRat(2:end-1,:);
lead = data.ebitdaMcRat(3:end,:);
lag = data.ebitdaMcRat(1:end-2,:);
zeroZZ = find(px==0);
leadAtZ = lead(zeroZZ);
lagAtZ = lag(zeroZZ);
brackets = find(leadAtZ.*lagAtZ);
px(zeroZZ(brackets))=lag(zeroZZ(brackets));

data.ebitdaMcRat(2:end-1,:) = px;
clear px lead lag zeros leadAtZ lagAtZ brackets
%%
for i = 1:size(data.tickers,2)
    printI = 1;
    px = data.ebitdaMcRat(:,i);
    zp = find(px==0);
    nzp = find(px~=0);
    if ~isempty(zp)
        for j = 1:numel(zp)
            front = nzp(find(nzp<zp(j)));
            back = nzp(find(nzp>zp(j)));
            
            if ~isempty(front)
                if ~isempty(back)
                    if printI
                        %                         i
                        printI=0;
                    end
                    px(zp(j)) = px(front(end));
                end
            end
        end
        data.ebitdaMcRat(:,i) = px;
    end
end