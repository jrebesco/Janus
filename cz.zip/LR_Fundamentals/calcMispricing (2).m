function [misPx goodNames] = calcMispricing(fund,t)

% load(file)
options.fundVal.useANN = 0;
options.fundVal.numNeurons = 20;

tickerFitMat = [fund.incCSEAdj(t,:);fund.incBFXoAfC(t,:);fund.incBfXoItems(t,:);fund.assets(t,:); ...
    fund.divPaid(t,:); fund.netIncome(t,:); fund.stockHEq(t,:); fund.totRev(t,:); fund.salesTurn(t,:); ...
    fund.ltDebt(t,:); fund.disOps(t,:);fund.ptxIncome(t,:); fund.incTax(t,:); ...
    fund.liabAndStockhEqt(t,:); fund.commOrdEqyTot(t,:); fund.prefStock(t,:);
    fund.xoItems(t,:); fund.totLiab(t,:); fund.curLiab(t,:); fund.curAssets(t,:); ...
    ];

[value,naNames] = find(isnan(tickerFitMat));

naNames = unique(naNames);
explicitBadFit = [1198;1788;1935;2107;2479;2548;2564;2692];
naNames = unique([naNames;explicitBadFit]);
goodNames = setdiff(1:1:size(tickerFitMat,2),naNames);
normWrtAssets = tickerFitMat(:,goodNames)./repmat(fund.assets(t,goodNames),size(tickerFitMat,1),1);
bounds = prctile(normWrtAssets,[5 95],2);

for z = 1:size(bounds,1)
    if ((bounds(z,1)==1) && (bounds(z,2)==1))
    else
        normWrtAssets(z,find(normWrtAssets(z,:)<bounds(z,1))) = bounds(z,1);
        normWrtAssets(z,find(normWrtAssets(z,:)>bounds(z,2))) = bounds(z,2);
    end
end
tickerFitWin = normWrtAssets.*repmat(fund.assets(t,goodNames),size(tickerFitMat,1),1);

mcapMat = fund.mktCap(t,goodNames);
fitMat = [tickerFitWin;ones(1,size(tickerFitWin,2))];

if options.fundVal.useANN == 0
    warning off all
    [b bint r rint stats] = regress(mcapMat',fitMat');
    warning on all
%     regCoef = b;
%     regResid = r;
    regResidFrac = r./mcapMat';
%     regR = stats(1);
    
else
    net = fitnet(20);
    [net,tr] = train(net,fitMat,mcapMat);
    nout = net(fitMat);
    regResidFrac2 = (mcapMat-nout)./mcapMat;
end

misPx(goodNames) = regResidFrac;
misPx(naNames) = 0;
if ~isempty(find(abs(misPx)>1000))
    disp(['large mispx:' num2str(find(abs(misPx)>1000))])
end
misPx(find(abs(misPx)>1000)) = 0;