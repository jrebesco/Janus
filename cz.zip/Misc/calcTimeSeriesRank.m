function fullRankBox = calcTimeSeriesRank(data,history,dim)

fullRankBox = zeros(size(data));


for i = 1:size(data,dim)
    if dim == 1
        if i < history
            rankbox = sortRank(data(1:i,:),dim);
        else
            rankbox = sortRank(data(i-history+1:i,:),dim);
        end
        fullRankBox(i,:) = rankbox(end,:);
    else
        if i < history
            rankbox = sortRank(data(:,1:i),dim);
        else
            rankbox = sortRank(data(:,i-history+1:i),dim);
        end
        fullRankBox(:,i) = rankbox(end,:);
    end
end