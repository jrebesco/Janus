function [allAreOK, securityCheck] = checkRestricted(data,finalTestFilter,options,beVerbose)

%FUNCTION checkRestricted
% inputs:
% data: standard VI data format.  Must contain field 'tickers' of
% which the first row are security names (not BBLG format).
% finalTestFilter: list of indices into the columns of data.tickers to be
% evaluated.
% options: standard VI options file
% beVerbose: flag to gate command line text status outputs.  Optional,
% default is true.
%
% outputs:
% allAreOK: boolean, 1 if all securities passed restrictedCheck
% securityCheck: boolean, same dim as finalTestFilter, indicating trade
% status of each security.

if nargin < 4
    beVerbose = 1;
end
load(options.global.restricted)
for z = 1:numel(finalTestFilter)
    ticker = data.tickers{1,finalTestFilter(z)};
    wholePass(z,1) = numel(find(strcmp(ticker,restr(:,1))));
    
    for y = 1:6
        shortTicker  = ticker(1:min(y,numel(ticker)));
        wholePass(z,y+1) = numel(find(strcmp(shortTicker,restr(:,1))));
    end
end

matches = sum(wholePass,2);

if sum(matches)==0
    allAreOK = 1;
else
    allAreOK = 0;
end

securityCheck = -sign(matches)+1;
if beVerbose
    for z = 1:numel(matches)
        if matches(z)==0
            disp([data.tickers{1,finalTestFilter(z)} ' is OK to trade'])
        else
            disp(['WARNING!!! ' data.tickers{1,finalTestFilter(z)} ' is NOT OK to trade'])
        end
    end
end