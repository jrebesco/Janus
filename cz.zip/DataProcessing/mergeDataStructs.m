fnz = fieldnames(d1);

for i = 1:numel(fnz)
    if strcmp(fnz{i},'tickers')
        eval(['dAll.' fnz{i} ' = d1.' fnz{i} ' ;' ]);
    elseif strcmp(fnz{i},'mnaOuts')
        eval(['dAll.' fnz{i} ' = d1.' fnz{i} ' ;' ]);
    elseif strcmp(fnz{i},'dates')
        eval(['dAll.' fnz{i} ' = [d1.' fnz{i} ' d2.' fnz{i} ' d3.' fnz{i} ' ];' ]);
    else
        eval(['dAll.' fnz{i} ' = [d1.' fnz{i} '; d2.' fnz{i} '; d3.' fnz{i} ' ];' ]);
    end
end

fnz = fieldnames(f1);

for i = 1:numel(fnz)
    if strcmp(fnz{i},'dates')
        eval(['fAll.' fnz{i} ' = [f1.' fnz{i} ' f2.' fnz{i} ' f3.' fnz{i} ' ];' ]);
    else
        eval(['fAll.' fnz{i} ' = [f1.' fnz{i} '; f2.' fnz{i} '; f3.' fnz{i} ' ];' ]);
    end
end