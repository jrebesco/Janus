function data = dataPreProcessingForNN(data,options)

data.bookval(data.bookval>options.nn.fit.bvCaps(end))=options.nn.fit.bvCaps(end);
data.bookval(data.bookval<options.nn.fit.bvCaps(1))=options.nn.fit.bvCaps(1);

data.roa(data.roa>options.nn.fit.roaCaps(2))=options.nn.fit.roaCaps(2);
data.roa(data.roa<options.nn.fit.roaCaps(1))=options.nn.fit.roaCaps(1);

data.gpoa(data.gpoa>options.nn.fit.gpoaCaps(2))=options.nn.fit.gpoaCaps(2);
data.gpoa(data.gpoa<options.nn.fit.gpoaCaps(1))=options.nn.fit.gpoaCaps(1);

data.cfoa(data.cfoa>options.nn.fit.cfoaCaps(2))=options.nn.fit.cfoaCaps(2);
data.cfoa(data.cfoa<options.nn.fit.cfoaCaps(1))=options.nn.fit.cfoaCaps(1);

q = data.prices>options.test.minValidPrice;
data.validity = data.validity.*q;

data = cleanPriceGaps(data);
data = cleanBadTickers(data);