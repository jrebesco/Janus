function rank = sortRank(x,dim)

%sortRank takes a 2-dim matrix and returns the rank order
%returns, sorted from low to high, along dimension dim
% INPUTS:
% x - a 2D matrix
% dim - OPTIONAL - dimension along which sortRank should operate.  Default
% value is 1.
% OUTPUTS: 
% rank - the sorted serial rank along dimension dim
% Example:
% x =
%      1     3     2     4     0     7
%      3     0     4     5     1     0
%      3     1     1     1     1     1
% 
% sortRank(x,1)
% ans =
%      1     3     2     2     1     3
%      2     1     3     3     2     1
%      3     2     1     1     3     2
% 
% sortRank(x,2)
% ans =
%      2     4     3     5     1     6
%      4     1     5     6     3     2
%      6     1     2     3     4     5
%%%%%%%%%%%%%%%%%%%%%%%%%% Revision history %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% 6-Jan-2017, v1.0- documentation written.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if ~exist('dim','var')
dim = 1;    
end

if ndims(x) > 2
    error('sortRank does not support N-dim matrices')
end

if dim==1
x = x';    
end

[s i]=sort(x,2);
[J I]=ndgrid(1:size(i,1),1:size(i,2));
i(sub2ind(size(i),J,i))=I;

if dim==1
    rank = i';
elseif dim==2
    rank = i;
end

