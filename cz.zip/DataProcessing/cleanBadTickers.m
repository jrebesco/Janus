function data = cleanBadTickers(data)

badTickerList = [237,261,663,665,2489,2558,2564,2672];

data.validity(:,badTickerList) = 0;