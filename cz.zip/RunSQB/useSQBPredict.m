function pdiff = useSQBPredict(model,data)

 pdiff = SQBMatrixPredict( model, single(data) );