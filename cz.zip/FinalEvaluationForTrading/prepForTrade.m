function prepForTrade(data,finalWeights,finalInd,options)

[allAreOK, securityCheck] = checkRestricted(data,finalInd,options,1);

if allAreOK==1
    
    weights = finalWeights';
    dates = repmat(datenum(now),1,numel(finalWeights))';
    tickers = data.tickers(1,finalInd)';
    indicPx = data.prices(end,finalInd)';
    
    outTable = dataset(weights,dates,tickers,indicPx);
    export(outTable,'file','tmp.csv','Delimiter',',')
    
else
    disp('eliminating not OK names')
    notOk = find(securityCheck==0);
    Ok = find(securityCheck==1);
    notOkWeights = finalWeights(notOk);
    
    notOkLong = finalInd(notOk(find(notOkWeights>0)));
    notOkShort = finalInd(notOk(find(notOkWeights<0)));
            
    notOkLongWeights = notOkWeights(notOkWeights>0);
    notOkShortWeights = notOkWeights(notOkWeights<0);
    
    nokLongMC = data.prices(end,notOkLong).*notOkLongWeights;
    nokShortMC = data.prices(end,notOkShort).*notOkShortWeights;
    
    allLong = finalWeights(find(finalWeights>0)).*data.prices(end,finalInd(find(finalWeights>0)));
    allShort = finalWeights(find(finalWeights<0)).*data.prices(end,finalInd(find(finalWeights<0)));
    
    scaleFracLong = sum(nokLongMC)./sum(allLong);
    scaleFracShort = sum(nokShortMC)./sum(allShort);
    
    finalWeights = finalWeights(Ok);
    finalInd = finalInd(Ok);
    
    finalWeights(finalWeights>0) = finalWeights(finalWeights>0).*(1+scaleFracLong);
    finalWeights(finalWeights<0) = finalWeights(finalWeights<0).*(1+scaleFracShort);
    
     weights = finalWeights';
    dates = repmat(datenum(now),1,numel(finalWeights))';
    tickers = data.tickers(1,finalInd)';
    indicPx = data.prices(end,finalInd)';
    
    outTable = dataset(weights,dates,tickers,indicPx);
    export(outTable,'file','tmp.csv','Delimiter',',')
end

% figure;
% % plotMultiNetPerformance(filt,finalInd,modelPerfOOS,options.test.portfolio.numPerSide,'MR')
% if isfield(options.test,'numPerSide')
% numEntries = options.test.numPerSide;
% else
%     numEntries = sum(finalWeights>0);
% end
% longInd = finalInd(1:numEntries);
% shortInd = finalInd(numEntries+1:end);
% %%
% % NEED TO PACKAGE INTO FUNCTION
% offset = 0.75;
% xlmm = [1-offset numEntries+offset];
% figure
% %
% lpx30 = data.prices(end,longInd) - data.prices(end-30,longInd);
% spx30 = data.prices(end,shortInd) - data.prices(end-30,shortInd);
% %
% lpx60 = data.prices(end,longInd) - data.prices(end-60,longInd);
% spx60 = data.prices(end,shortInd) - data.prices(end-60,shortInd);
% %
% lpx90 = data.prices(end,longInd) - data.prices(end-90,longInd);
% spx90 = data.prices(end,shortInd) - data.prices(end-90,shortInd);
% 
% subplot(2,3,1)
% bar([lpx30;lpx60;lpx90]')
% set(gca,'XLim',xlmm);
% %
% subplot(2,3,4)
% bar([spx30;spx60;spx90]')
% set(gca,'XLim',xlmm);
% %
% 
% subplot(2,3,2)
% bar(log([data.mcap(end,longInd);data.mcap(end,shortInd)]'))
% hold on
% mmc = log(mean(data.mcap(end,:)));
% xl = get(gca,'XLim');
% plot(xl,[mmc mmc],'k--','LineWidth',3)
% set(gca,'XLim',xlmm);
% 
% subplot(2,3,3)
% bar([data.bookval(end,longInd);data.bookval(end,shortInd)]')
% hold on
% mmc = (mean(data.bookval(end,:)));
% xl = get(gca,'XLim');
% plot(xl,[mmc mmc],'k--','LineWidth',3)
% set(gca,'XLim',xlmm)
% 
% subplot(2,3,5)
% bar([data.beta(end,longInd);data.beta(end,shortInd)]')
% hold on
% mmc = (mean(data.beta(end,:)));
% xl = get(gca,'XLim');
% plot(xl,[mmc mmc],'k--','LineWidth',3)
% ylim([0 5])
% set(gca,'XLim',xlmm)
% 
% figure;
% %% sector expo
% subplot(2,2,1)
% sect = unique(data.tickers(5,finalInd));
% 
% for i = 1:numel(sect);
%     longE(i) = numel(find(strcmp(data.tickers(5,longInd),sect{i})));
%     shortE(i) = numel(find(strcmp(data.tickers(5,shortInd),sect{i})));
% end
% ax = gca;
% bar([longE;shortE]')
% legend('L','S')
% for i = 1:numel(sect); if isempty(sect{i}); sect{i} = 'N/Listed'; end; end;
% set(gca,'XTick',1:1:numel(sect));
% set(gca,'XTickLabel',sect);
% ax.XTickLabelRotation = 45;
% 
% %% $ expo
% expo = data.beta(end,finalInd)./100.*data.prices(end,finalInd).*finalWeights;
% subplot(2,2,2)
% bar(expo)
% xlim([0.7 numel(expo)+.3])
% set(gca,'XTick',1:1:numel(expo))
% set(gca,'XTickLabel',data.tickers(1,finalInd)')
% se = num2str(sum(expo));
% title(['net: ' se(1:4)])
% ax = gca;
% ax.XTickLabelRotation = 45;
% 
% subplot(2,2,3)
% pold = data.prices(end-40:end,finalInd);
% netlq = (pold.*repmat(finalWeights,size(pold,1),1));
% pnl = sum(netlq);
% pnl = pnl-pnl(1);
% plot(pnl,'LineWidth',2)