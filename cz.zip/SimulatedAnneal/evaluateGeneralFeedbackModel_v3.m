function [ model ] = evaluateGeneralFeedbackModel_v3(data,finalTestFilter, finalTestWeights,options,startIndex,testLength)
% finalTestFilter = finalTestFilter(4:5)
% finalTestWeights = finalTestWeights(4:5)
% v3 adds relever and delever configs
totalLongAmt = sum(data.prices(startIndex+1,finalTestFilter) .* abs(finalTestWeights));
weights(:,1) = finalTestWeights';
updatedWeights = 0;
if ~isempty(finalTestWeights)
    for i = 1:testLength
        
        time = startIndex + i;
        timeV(i) = time;
        prices(:,i) = data.prices(time,finalTestFilter);
        if i > 1
            pnl(:,i) = pnl(:,i-1) + (prices(:,i) - prices(:,i-1)).*weights(:,i);
            ffPnl(:,i) = ffPnl(:,i-1) + (prices(:,i) - prices(:,i-1)).*weights(:,1);
        elseif i==1
            pnl(:,i) = (prices(:,i) - prices(:,i)).*weights(:,i);
            ffPnl(:,i) = (prices(:,i) - prices(:,i)).*weights(:,i);
        end
        netLiq(i) = abs(totalLongAmt) + sum(pnl(:,i));
        secNetLiq(:,i) = abs(weights(:,1).*prices(:,1)) + pnl(:,i);
        
        if options.test.feedback.globalStopLoss.isEnabled == 1
            if sum(pnl(:,i)) <= (-options.test.feedback.globalStopLoss.fractionalLoss).*totalLongAmt
                if options.test.feedback.globalStopLoss.triggered == 0;
                    if options.global.verbose == 1;
                        disp(['global stoploss on date: ' data.dates{time}])
                    end
                end
                
                weights(:,i+1) = zeros(size(weights(:,i)));
                updatedWeights = 1;
                options.test.feedback.globalStopLoss.triggered = 1;
            end
        end
        
        if options.test.feedback.globalHWLoss.isEnabled == 1
            if (sum(pnl(:,i))-max(sum(pnl))) <= -options.test.feedback.globalHWLoss.fractionalLoss.*netLiq(1)
                if options.test.feedback.globalHWLoss.triggered == 0;
                    if options.global.verbose == 1;
                        disp(['global HW stop on date: ' data.dates{time}])
                    end
                end
                weights(:,i+1) = zeros(size(weights(:,i)));
                updatedWeights = 1;
                options.test.feedback.globalHWLoss.triggered = 1;
            end
        end
        
        if options.test.feedback.posRelever.isEnabled == 1
            if options.test.feedback.globalHWLoss.triggered ~= 1;
                if options.test.feedback.globalStopLoss.triggered ~= 1;
                    if options.test.feedback.posRelever.triggered == 0;
                        if (netLiq(i)-netLiq(1)) >= options.test.feedback.posRelever.threshold.*netLiq(1)
                            weights(:,i+1) = weights(:,i).*options.test.feedback.posRelever.multiple;
                            options.test.feedback.posRelever.triggered = 1;
                            updatedWeights = 1;
                        end 
                    end
                end
            end
        end
        
         if options.test.feedback.posDelever.isEnabled == 1
            if options.test.feedback.globalHWLoss.triggered ~= 1;
                if options.test.feedback.globalStopLoss.triggered ~= 1;
                    if options.test.feedback.posDelever.triggered == 0;
                        if (netLiq(i)-netLiq(1)) >= options.test.feedback.posDelever.threshold.*netLiq(1)
                            weights(:,i+1) = weights(:,i).*options.test.feedback.posDelever.multiple;
                            options.test.feedback.posRelever.triggered = 1;
                            updatedWeights = 1;
                        end 
                    end
                end
            end
        end
        
        if size(weights,2)~=(i+1) % check that global stops haven't been hit
            if options.test.feedback.individualStopLoss.isEnabled == 1
                triggeredSecIndices = find(secNetLiq(:,i) <= (1-options.test.feedback.individualStopLoss.fractionalLoss).*secNetLiq(:,1));
                
                if ~isempty(triggeredSecIndices)
                    weights(:,i+1) = weights(:,i);
                    weights(triggeredSecIndices,i+1) = zeros(size(triggeredSecIndices));
                    updatedWeights = 1;
                    %            options.individualStopLoss.triggered
                end
            end
            
            
        end
        
        
        if updatedWeights == 0;
            weights(:,i+1) = weights(:,i);
        else
            updatedWeights = 0;
        end
        
    end
    
    %     model.raw.marketCapThresh = marketCapThresh;
    %     model.raw.marketCapDelta = marketCapDelta;
    %     model.raw.momMin = momMin;
    %     model.raw.momMax = momMax;
    %     model.raw.bvMin = bvMin;
    %     model.raw.bvMax = bvMax;
    %     model.raw.mcaps = data.mcap(startIndex,finalTestFilter);
    %     model.raw.pxMom = testMo(finalTestFilter);
    %     model.raw.BV = data.bookval(startIndex,finalTestFilter);
    model.pnl = pnl;
    model.finalPnl = sum(pnl(:,end));
    model.initialNetLiq = totalLongAmt;

else
    %     model.raw.marketCapThresh = NaN;
    %     model.raw.marketCapDelta = NaN;
    %     model.raw.momMin = NaN;
    %     model.raw.momMax = NaN;
    %     model.raw.bvMin = NaN;
    %     model.raw.bvMax = NaN;
    %     model.raw.mcaps = data.mcap(startIndex,finalTestFilter);
    %     model.raw.pxMom = testMo(finalTestFilter);
    %     model.raw.BV = data.bookval(startIndex,finalTestFilter);
    model.pnl = 0;
    model.finalPnl = 0;
    
end
model.timeIndex = timeV;