function [result_bin,result_binM] = binResult(result,pxThresh)

result_bin = sign(result);
result_bin(find(result==0))=1;
result_bin(find(result>pxThresh))=2;
result_bin(find(result<-pxThresh))=-2;
result_binM=[result_bin==-2;result_bin==-1;result_bin==1;result_bin==2];