function dailyReturn = generateDailyReturn(model,options)

dailyReturn = [];
% if numel(model)>1

for i = 1:numel(model)
    
    if strcmp(model{i}.tickers,'XXX')
        daily = zeros(1,options.test.runLength);
    else
        daily = [0  diff(sum(model{i}.pnl)./model{i}.initialNetLiq)];
    end
    dailyReturn = [dailyReturn daily];
end
% else
%     daily = [0  diff(sum(model{i}.pnl)./model{i}.initialNetLiq)];