function tsCorrDelta(ts1,delta1,ts2,delta2,normalizeDeltas)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION TSCORRDELTA(ts1,delta1,ts2,delta2)
% takes two time series and computes the correlation 
%between the 
% INPUTS
% ts1: first time series
% delta1: first time series delta (assumed backward looking)
% ts2: second time series
% delta2: second time series delta (assumed forward looking)
%  So for all t, tsCorrDelta computes the correlation of ts1(t) -
%  ts1(t-delta1) ag ts2(t+delta2)-ts2(t)


tmp1 = ts1(1:end-delta1)