function beta = calcBetas(ticker,startDate,endDate,proxy,isVerbose,data)

if nargin <= 5
    data = [];
end
if nargin <= 4
    isVerbose = 0;
end
if nargin <= 3
    proxy = 'SPY';
end
startInd = find(strcmp(data.dates,startDate));
slide = 0;
while isempty(startInd)
    slide = slide+1;
    startInd = find(strcmp(data.dates,datestr(datenum(startDate)-slide,'mm/dd/yyyy')));
end

endInd = find(strcmp(data.dates,endDate));
slide = 0;
while isempty(endInd)
    slide = slide+1;
    endInd = find(strcmp(data.dates,datestr(datenum(endDate)-slide,'mm/dd/yyyy')));
end


if isempty(data)
    [data, dividends] = getGoogleDailyData({ticker;proxy}, startDate, endDate,'mm/dd/yyyy');
    eval(['px1 = data.' ticker '.AdjClose;'])
    eval(['px2 = data.' proxy '.AdjClose;'])
else
    %     startInd = find(strcmp(data.dates,startDate));
    %     endInd = find(strcmp(data.dates,endDate));
    tickerInd = find(strcmp(data.tickers(1,:),ticker));
    px1 = data.prices(startInd:endInd,tickerInd);
    px2 = data.spy(startInd:endInd);
end

px1 = diff(px1);
px2 = diff(px2);

x = [px2 ones(size(px2))];
y = px1;

[b,bint,r,rint,stats] = regress(y,x);

if isVerbose==1
    if sign(bint(2,1))==sign(bint(2,2))
        disp('alpha outside 0')
    end
end

beta = b(1);