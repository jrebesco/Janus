function dateVect = getAllTradeDateVect(startDate,endDate,timeRange)

if ~exist('timeRange','var')
    timeRange = 'daily';
end

c = blp([],[],10000);
[d sec] = history(c,'SPY US Equity','PX_LAST',startDate,endDate,'daily');
dateVect = d(:,1);
close(c)