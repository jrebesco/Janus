function data = scratchCoreHistoricalDataForStructMod(bootstrapFileName,startDate,endDate)
load(bootstrapFileName) 
clear a ans b c
tickers = data.tickers;
clear data
okInd = 1;
data.tickers = tickers;

mna = [15,42,54,70,71,109,160,194,196,200,207,223,225,236,263,284,354,365,415,426,449,450,464,486,495,498,517,535,536,...
    540,580,619,640,643,663,664,668,753,764,783,824,839,848,900,981,1021,1029,1051,1095,1107,1110,1139,1147,1198,1239,...
    1252,1307,1371,1382,1397,1415,1435,1436,1444,1502,1505,1556,1620,1639,1726,1746,1752,1756,1773,1781,1788,1815,1833,...
    1836,1903,1923,1935,1948,1953,1979,1991,1998,2032,2038,2044,2054,2096,2110,2162,2247,2266,2294,2310,2325,2393,2435,...
    2443,2451,2471,2544,2557,2561,2573,2616,2625,2681,2817,74,190,215,510,1041,1519,1660,1716,1900,1932 2160 2418 2764,...
    27 40 47 127 159 682 1062 1112 1138 1204 1279 1383 1475 1851 1924 2034 2365 2615 2648 199 530 798 1053 1061 1215,...
    1277 1320 1829 1945 2198 2438 2460 2613 2797];
data.mnaOuts = mna;
%% get bblg connection
c = blp([],[],10000);
bblgTickers = tickers(3,:);

% startDate = data.dates{1}
% startDate = '12/29/2006';
% startDate = '02/01/2016';
globalStartDate = startDate;
% endDate = datestr(datenum(date)-3 ,'mm/dd/yyyy')


%% px
[d sec] = history(c,bblgTickers,'PX_LAST',globalStartDate,endDate,'daily');
for i = 1:numel(d{okInd}(:,1))
    dateAppend{i} = datestr(d{okInd}(i,1),'mm/dd/yyyy');
end
data.dates = dateAppend;
clear dateAppend
clear tickers

%%
[pxmat]  = valArrayBblgPull(d,okInd,data);
pxmat = fixOneOffPxEvents(pxmat,bblgTickers,d);
data.prices = pxmat
suspTickers = find(sum(pxmat)==0);

%% BV next to clear px
[d sec] = history(c,bblgTickers,'BOOK_VAL_PER_SH',startDate,endDate,'daily');
[bvmat] = valArrayBblgPull(d,okInd,data);
bvpx = bvmat./pxmat;
bvpx(isnan(bvpx))=0;
data.bookval = bvpx
clear pxmat bvmat
%% MC
[d sec] = history(c,bblgTickers,'CUR_MKT_CAP',startDate,endDate,'daily');
[mcmat] = valArrayBblgPull(d,okInd,data);
data.mcap = mcmat
clear mcmat
%% beta
[d sec] = history(c,bblgTickers,'BETA_MINUS',startDate,endDate,'daily');
betamat = valArrayBblgPull(d,okInd,data);
data.beta = betamat
clear betamat
%%
%% add single entries
%% spy
[d sec] = history(c,'SPY US Equity','PX_LAST',startDate,endDate,'daily');
data.spy = d(:,2);
%% VIX
[d sec] = history(c,'VIX Index','PX_LAST',startDate,endDate,'daily');
data.vix = d(:,2);
%% gc
[d sec] = history(c,'GC1 Comdty','PX_LAST',startDate,endDate,'daily');
data.gc = d(:,2);
%% lb
[d sec] = history(c,'LB1 Comdty','PX_LAST',startDate,endDate,'daily');
data.lb = d(:,2);

clear d sec

%% vixContango
[d sec] = history(c,'UX1 Index','PX_LAST',startDate,endDate,'daily');
[d2 sec] = history(c,'UX5 Index','PX_LAST',startDate,endDate,'daily');
data.vixCont = d2(:,2)-d(:,2);
clear d d2 sec

%% divy
save('tmp.mat','data')
clear bblgTickers bval bvmat bvupdate d endDate globalStartDate i mna numelD okI pxmat q sec startDate tickerInd tm tmp tmp2 tmp3
dy = appendNewField('tmp','DIVIDEND_YIELD');
data.divyld = dy;
clear dy
save('tmp.mat','data')

roa = appendNewField('tmp','ANN_RETURN_ON_ASSET');
data.roa = roa;
save('tmp.mat','data')
clear roa

tso = appendNewField('tmp','EQY_SH_OUT');
gp = appendNewField('tmp','TRAIL_12M_GROSS_PROFIT');
data.grossPPS = gp./tso
save('tmp.mat')

fcf = appendNewField('tmp','CF_FREE_CASH_FLOW');
data.fcfPS = fcf./tso
save('tmp.mat')
clear tso

bs_tot_assets=getAssets('tmp');
data.gpoa = gp./bs_tot_assets
data.cfoa = fcf./bs_tot_assets

clear gp fcf tso

data.fcfPS((isnan(data.fcfPS))) = 0;
data.roa((isnan(data.roa))) = 0;
data.cfoa((isnan(data.cfoa))) = 0;
data.gpoa((isnan(data.gpoa))) = 0;
data.roa((isnan(data.roa))) = 0;
data.grossPPS((isnan(data.grossPPS))) = 0;


%% pe
save('tmp.mat')
data.pe = appendNewField('tmp.mat','PE_RATIO')
save('tmp.mat')
data.volume = appendNewField('tmp.mat','VOLUME')
%% data validity

data = cleanPriceGaps(cleanPriceGaps(cleanPriceGaps(cleanPriceGaps(cleanPriceGaps(cleanPriceGaps(data))))));
data = dataValidity(data);