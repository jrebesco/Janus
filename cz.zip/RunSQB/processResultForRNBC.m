function [datam, result, result_bin] = processResultForRNBC(datam,result,pxThresh,isForRBC)

[result_bin,result_binM] = binResult(result,pxThresh);

if isForRBC
    
    minOfSamples = min(sum(result_binM'));
    for i = 1:size(result_binM,1)
        sampleIndices(:,i) = sort(randsample(find(result_binM(i,:)),minOfSamples));
    end
    allSampIndices = sampleIndices(:);
    datam = datam(:,allSampIndices);
    result = result(allSampIndices);
    result_bin = result_bin(allSampIndices);
    result_binM = result_binM(allSampIndices);
end