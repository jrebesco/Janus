function indices = getSectorFiltIndices(data,percentile,greaterThanFlag,sectorString,dataArray)
if size(dataArray,1)~=1
    error('getSectorFiltIndices assumes single column vector')
end


if strcmp(sectorString,'broadSector')
    sectCell = getBroadSectorIndices(data);
    indices = [];
    for i = 1:numel(sectCell)
        subDataArray = dataArray(sectCell{i});
        if ~isvector(percentile) || numel(percentile) == 0 || any(percentile < 0 | percentile > 100) || ~isreal(percentile)
            disp('break')
        end
        qtiles = prctile(subDataArray,[percentile]);
        if greaterThanFlag == 1
            indices = [indices sectCell{i}(find(subDataArray>=qtiles(1)))];
        elseif greaterThanFlag == -1
            indices = [indices sectCell{i}(find(subDataArray<=qtiles(1)))];
        end
        
    end
    
elseif strcmp(sectorString,'narrowSector')
    
elseif strcmp(sectorString,'closestComps')
    
    
end

