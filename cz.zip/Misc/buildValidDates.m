ccc
load issue_dt
load filt_dataVI_v2p3

anchor = size(data.prices,1)+1;
for i = 1:size(data.prices,2)
    
    foundStart = 0;
    searchIndex = anchor;
    qI = [diff(data.prices(:,i));0];
    testArray = zeros(1,anchor);
    testArray(find(qI==0)) = 1;
    
    while foundStart == 0
        searchIndex = searchIndex -1;
        if qI(searchIndex)==0;
            foundStart = searchIndex;
        end
           validEnd(i) = foundStart; 
    end
    
end

validMatrix = zeros(size(data.prices));


for i = 1:numel(d)
    if i==1928
        disp('stop')
    end
   findVS = find(d(i)==datenum(data.dates));
   if isempty(findVS)
       findVS = 1;
   end
   validStart(i) = findVS;
end
for i = 1:size(data.prices,2);
   validMatrix(validStart(i):validEnd(i),i)=1; 
end

data.isValid = validMatrix;