%% buildPartialDataForPortfolioLoading
ccc

startDate = '06/29/2015';
endDate = '12/31/2016';

%%
buildFullDataForStrMod;

clear ans bs_tot_assets bvpx c cleanlist junkList okInd suspectList ticker* valid*

save newRunData

%% 