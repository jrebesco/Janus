%vix curve
% ccc
%
c = blp([],[],10000);
startDate = data.dates{1};
endDate = data.dates{end};
for i = 1:7
nameC{i} = ['UX' num2str(i) ' Index'];
end
[d, s] = history(c,nameC,'PX_LAST',startDate,endDate,'daily');
% [spy sec] = history(c,'SPY US Equity','PX_LAST',startDate,endDate,'daily');
close(c)
%
for i = 1:numel(d)
    ni(i) = numel(d{i});
end

if sum(abs(diff(ni)))==0
    disp('ok')
else
end

for i = 1:5
    vixC(:,i) = d{i}(:,2);
end
% spy = spy(:,2);
% clear c d i nameC ni s sec
%%
ccc
load vixTemp

plvixCrv = diff(vixC')';

tlv = [5:5:300];
contv = [2:1:size(vixC,2)];

for i = 1:numel(tlv)
    for j = 1:numel(contv)
        totCont = vixC(:,1)-vixC(:,contv(j));
        timeLag = tlv(i);
        dSpy = spy(timeLag+1:end)- spy(1:end-timeLag);
        cv(i,j) = corr(totCont(1:numel(dSpy)),dSpy);
    end
end
