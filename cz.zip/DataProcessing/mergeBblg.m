function out = mergeBblg(d1,d2,data)

assert(numel(d1)==numel(d2))

datez = datenum(data.dates);

for i = 1:numel(d1)
    
    for d = 1:numel(datez)
      i
      d
      
        a1 = find(datez(d)==d1{i}(:,1));
        a2 = find(datez(d)==d2{i}(:,1));
        if ~isempty(a1)
            out(d,i) = d1{i}(a1,2);
        elseif ~isempty(a2)
            out(d,i) = d2{i}(a2,2);
        elseif d>1
            out(d,i) = out(d-1,i);
        else
            out(d,i) = 0;
        end
        
        
    end
    
    %     for j = 1:size(d1,1)
    %         insertInd(j) = find(d1{i}(j,1)==datez);
    %     end
    %
    %     for k = 1:size(d2,1)
    %         insertInd2(k) = find(d2{i}(k,1)==datez);
    %     end
    
    
end