function [misPx goodNames] = calcMispricing(fund,t)

%% bespoke fixering incBfXoItems
dateThreshold = 1255;

xoFix = fund.incBfXoItems(1:dateThreshold,:);
xoReplace = fund.incBFXoAfC(1:dateThreshold,:);
ind2Replace = find(isnan(xoFix));
xoFix(ind2Replace)=xoReplace(ind2Replace);
fund.incBfXoItems(1:dateThreshold,:) = xoFix;

%% assume NaN for discontinued ops = 0;
fund.disOps(find(isnan(fund.disOps)))=0;
fund.xoItems(find(isnan(fund.xoItems)))=0;
%%
tickerFitMat = [fund.incCSEAdj(t,:);fund.incBFXoAfC(t,:);fund.incBfXoItems(t,:);fund.assets(t,:); ...
    fund.divPaid(t,:); fund.netIncome(t,:); fund.stockHEq(t,:); fund.totRev(t,:); ...
    fund.salesTurn(t,:); fund.ltDebt(t,:); fund.disOps(t,:);fund.ptxIncome(t,:);...
    fund.incTax(t,:); fund.commOrdEqyTot(t,:); fund.prefStock(t,:); ...
    fund.totLiab(t,:); fund.curLiab(t,:); fund.curAssets(t,:); ...
    ];

[~,naNames] = find(isnan(tickerFitMat));
naNames = unique(naNames);
explicitBadFit = [2107];
naNames = unique([naNames;explicitBadFit]);
goodNames = setdiff(1:1:size(tickerFitMat,2),naNames);
normWrtAssets = tickerFitMat(:,goodNames)./repmat(fund.assets(t,goodNames),size(tickerFitMat,1),1);
bounds = prctile(normWrtAssets,[5 95],2);

for z = 1:size(bounds,1)
    if ((bounds(z,1)==1) && (bounds(z,2)==1))
    else
        normWrtAssets(z,find(normWrtAssets(z,:)<bounds(z,1))) = bounds(z,1);
        normWrtAssets(z,find(normWrtAssets(z,:)>bounds(z,2))) = bounds(z,2);
    end
end
tickerFitWin = normWrtAssets.*repmat(fund.assets(t,goodNames),size(tickerFitMat,1),1);
tickerFitWin(4,:) = fund.assets(t,goodNames);

mcapMat = fund.mcap(t,goodNames);
fitMat = [tickerFitWin;ones(1,size(tickerFitWin,2))];
[b bint r rint stats] = regress(mcapMat',fitMat');
regCoef = b;
regResid = r;
regResidFrac = regResid./mcapMat';
regR = stats(1);

misPx(goodNames) = regResidFrac; 
misPx(naNames) = 0;

misPx(find(abs(misPx)>1000)) = 0;